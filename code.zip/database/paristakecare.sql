-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 03 juin 2024 à 14:09
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `paristakecare`
--

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_bailleur`
--

CREATE TABLE `paristakecare_bailleur` (
  `id` int(11) DEFAULT NULL,
  `contact_times` int(11) DEFAULT NULL,
  `personnal` int(11) DEFAULT 0,
  `entreprise` int(11) DEFAULT 0,
  `phoneWork` char(10) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paristakecare_bailleur`
--

INSERT INTO `paristakecare_bailleur` (`id`, `contact_times`, `personnal`, `entreprise`, `phoneWork`, `token`) VALUES
(3, NULL, 1, 0, '0635461597', NULL),
(4, NULL, 1, 0, '0635461597', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_bien`
--

CREATE TABLE `paristakecare_bien` (
  `id` int(11) NOT NULL,
  `id_bailleur` int(11) DEFAULT NULL,
  `is_validated` int(11) DEFAULT NULL,
  `subscription_paid` int(11) DEFAULT NULL,
  `subscription_date` date NOT NULL DEFAULT current_timestamp(),
  `land` varchar(10) DEFAULT NULL,
  `bien_type` varchar(60) DEFAULT NULL,
  `location_type` varchar(60) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `chambers_nb` int(11) DEFAULT NULL,
  `occupants_nb` int(11) DEFAULT NULL,
  `price` int(70) NOT NULL,
  `id_docs` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paristakecare_bien`
--

INSERT INTO `paristakecare_bien` (`id`, `id_bailleur`, `is_validated`, `subscription_paid`, `subscription_date`, `land`, `bien_type`, `location_type`, `address`, `chambers_nb`, `occupants_nb`, `price`, `id_docs`) VALUES
(1, 4, 1, 1, '2024-04-30', 'FR', 'appartement', 'yeld', '20 test 1', 2, 8, 70, 1),
(9, 4, 1, 1, '2024-04-30', 'FR', 'appartement', 'yeld', '20 test', 1, 1, 70, 4),
(10, 3, 1, 0, '2024-05-12', 'FR', 'appartement', 'yeld', '20 test', 1, 5, 67, 3),
(11, 3, 0, 0, '2024-05-17', 'FR', 'appartement', NULL, '20 test ', 1, 4, 67, 3);

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_consulte`
--

CREATE TABLE `paristakecare_consulte` (
  `id_bailleur` int(11) DEFAULT NULL,
  `id_voyageur` int(11) DEFAULT NULL,
  `id_bien` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_disponibility`
--

CREATE TABLE `paristakecare_disponibility` (
  `id` int(11) NOT NULL,
  `id_prestataire` int(11) DEFAULT NULL,
  `disponibility` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paristakecare_disponibility`
--

INSERT INTO `paristakecare_disponibility` (`id`, `id_prestataire`, `disponibility`) VALUES
(1, 5, '2024-05-18');

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_effectue`
--

CREATE TABLE `paristakecare_effectue` (
  `id_prestation` int(11) DEFAULT NULL,
  `id_prestataire` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_facture`
--

CREATE TABLE `paristakecare_facture` (
  `id` int(11) NOT NULL,
  `id_prestation` int(11) DEFAULT NULL,
  `id_prestataire` int(11) DEFAULT NULL,
  `id_bailleur` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `is_paid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_fais_facture`
--

CREATE TABLE `paristakecare_fais_facture` (
  `id_facture` int(11) DEFAULT NULL,
  `id_prestation` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_possède`
--

CREATE TABLE `paristakecare_possède` (
  `id_bailleur` int(11) DEFAULT NULL,
  `id_bien` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_prestataire`
--

CREATE TABLE `paristakecare_prestataire` (
  `id` int(11) DEFAULT NULL,
  `type_prestation` varchar(255) DEFAULT NULL,
  `is_validated` int(11) DEFAULT -1,
  `price` int(11) NOT NULL,
  `duration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paristakecare_prestataire`
--

INSERT INTO `paristakecare_prestataire` (`id`, `type_prestation`, `is_validated`, `price`, `duration`) VALUES
(1, 'plombier', 5, 0, 0),
(5, 'plombier', 1, 234, 12);

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_prestation`
--

CREATE TABLE `paristakecare_prestation` (
  `id` int(11) NOT NULL,
  `id_prestataire` int(11) DEFAULT NULL,
  `id_bien` int(11) DEFAULT NULL,
  `type` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `evaluation` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_reserve`
--

CREATE TABLE `paristakecare_reserve` (
  `id` int(11) NOT NULL,
  `id_voyageur` int(11) DEFAULT NULL,
  `nb_personnes` int(11) DEFAULT NULL,
  `id_bien` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_validated` int(11) DEFAULT NULL,
  `price` int(11) NOT NULL,
  `is_paid` int(11) DEFAULT NULL,
  `note` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paristakecare_reserve`
--

INSERT INTO `paristakecare_reserve` (`id`, `id_voyageur`, `nb_personnes`, `id_bien`, `start_date`, `end_date`, `is_validated`, `price`, `is_paid`, `note`) VALUES
(7, 2, 5, 9, '2024-05-22', '2024-05-23', 1, 70, 1, 2),
(8, 2, 8, 11, '2024-05-21', '2024-05-23', 1, 67, 1, 0),
(14, 2, 3, 1, '2024-05-30', '2024-06-01', 1, 70, 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_réserve_presta`
--

CREATE TABLE `paristakecare_réserve_presta` (
  `id_taker` int(11) DEFAULT NULL,
  `ask_taker` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paristakecare_réserve_presta`
--

INSERT INTO `paristakecare_réserve_presta` (`id_taker`, `ask_taker`) VALUES
(4, 'testbailleur'),
(3, 'bonjour j\'ai un souci de plomberie ');

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_réserve_presta_bailleur`
--

CREATE TABLE `paristakecare_réserve_presta_bailleur` (
  `id_prestation` int(11) DEFAULT NULL,
  `id_bailleur` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_réserve_presta_voyageur`
--

CREATE TABLE `paristakecare_réserve_presta_voyageur` (
  `id_prestation` int(11) DEFAULT NULL,
  `id_voyageur` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_tickets`
--

CREATE TABLE `paristakecare_tickets` (
  `id` int(11) NOT NULL,
  `title` varchar(60) NOT NULL,
  `content` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `category` varchar(30) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `administrator_id` int(11) DEFAULT NULL,
  `status` tinyint(11) NOT NULL DEFAULT 0,
  `level` tinyint(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_type_presta`
--

CREATE TABLE `paristakecare_type_presta` (
  `id` int(11) NOT NULL,
  `type_prestation` varchar(255) DEFAULT NULL,
  `all_id` text DEFAULT '0:0.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_user`
--

CREATE TABLE `paristakecare_user` (
  `id` int(11) NOT NULL,
  `role` int(11) DEFAULT NULL,
  `lastname` varchar(60) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phone` char(10) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paristakecare_user`
--

INSERT INTO `paristakecare_user` (`id`, `role`, `lastname`, `firstname`, `address`, `phone`, `email`, `password`, `token`) VALUES
(1, NULL, 'test1', 'test1', '20 test', '0781286552', 'julienmans@yahoo.fr', '$2b$10$XepA6jeKazetlm8xJEesAuzeGgQpSa/lIbqqJWHdhTZgiBpQ9NbDq', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiZW1haWwiOiJqdWxpZW5tYW5zQHlhaG9vLmZyIiwicm9sZSI6bnVsbCwiaW50ZXJmYWNlIjoicHJlc3RhdGFpcmUiLCJpYXQiOjE3MTU2OTAxMDUsImV4cCI6MTcxNTY5MzcwNX0.oA43y9FsLK4GcT5vBf9UVpbQ320LhazLbOc9f2iThro'),
(2, NULL, 'test1', 'test1', '20 test', '0781286552', 'test1@gmail.com', '$2b$10$X.o2xCznmJe9QVho8u6E6.tWdlYtKvxXFOzZndudaRv1LRvs2iAeS', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwiZW1haWwiOiJ0ZXN0MUBnbWFpbC5jb20iLCJyb2xlIjpudWxsLCJpbnRlcmZhY2UiOiJ2b3lhZ2V1ciIsImlhdCI6MTcxNjgyOTg5OSwiZXhwIjoxNzE2ODMzNDk5fQ.IRT8TznS6Khaa4q2KRtmJcwW5i_smvuTjlMDZisVZtQ'),
(3, NULL, 'test3', 'test3', '20 test', '0781286552', 'test3@gmail.com', '$2b$10$IRbwyMY8dI8QhPC0ytIxw./Fy4/8M8mV7rjfIhQLgZZgFBH7xmO9S', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MywiZW1haWwiOiJ0ZXN0M0BnbWFpbC5jb20iLCJyb2xlIjpudWxsLCJpbnRlcmZhY2UiOiJiYWlsbGV1ciIsImlhdCI6MTcxNTk1NDc4NiwiZXhwIjoxNzE1OTU4Mzg2fQ.Nk-h6SLB1ntILOn3AQ-0-YYhHFTLTC9JcpzJG-AVJZU'),
(4, NULL, 'test6', 'test6', '20 test', '08126789', 'test6@gmail.com', '$2b$10$8pyssT2gv8jP/pm3mGNiVep7.QtGifvGroJ7MqEKB6Rh6BP9fnVJS', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NCwiZW1haWwiOiJ0ZXN0NkBnbWFpbC5jb20iLCJyb2xlIjpudWxsLCJpbnRlcmZhY2UiOiJiYWlsbGV1ciIsImlhdCI6MTcxNTY5MzY3MCwiZXhwIjoxNzE1Njk3MjcwfQ.5JOmY4y0zwHRJCNJ10dQBZfoty5pbN18NfmBdq4miIo'),
(5, 1, 'test9', 'test9', '20 test', '0781286552', 'test9@gmail.com', '$2b$10$cnJi24LcjRT9ealcKRm3jOaoJDKGmO/S5H7OLt5RNcY95mplFeRPu', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NSwiZW1haWwiOiJ0ZXN0OUBnbWFpbC5jb20iLCJyb2xlIjoxLCJpbnRlcmZhY2UiOiJwcmVzdGF0YWlyZSIsImlhdCI6MTcxNjAzMjkxNCwiZXhwIjoxNzE2MDM2NTE0fQ.Y9ppuJf56NUBOI3Gte0XQfZqOK-_LLxttQ-Wojq53HE');

-- --------------------------------------------------------

--
-- Structure de la table `paristakecare_voyageur`
--

CREATE TABLE `paristakecare_voyageur` (
  `id` int(11) DEFAULT NULL,
  `is_vip` int(11) DEFAULT NULL,
  `is_vip_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `paristakecare_voyageur`
--

INSERT INTO `paristakecare_voyageur` (`id`, `is_vip`, `is_vip_date`) VALUES
(2, 1, '2023-03-10');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `paristakecare_bailleur`
--
ALTER TABLE `paristakecare_bailleur`
  ADD KEY `id` (`id`);

--
-- Index pour la table `paristakecare_bien`
--
ALTER TABLE `paristakecare_bien`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_bailleur` (`id_bailleur`);

--
-- Index pour la table `paristakecare_consulte`
--
ALTER TABLE `paristakecare_consulte`
  ADD KEY `id_bailleur` (`id_bailleur`),
  ADD KEY `id_voyageur` (`id_voyageur`),
  ADD KEY `id_bien` (`id_bien`);

--
-- Index pour la table `paristakecare_disponibility`
--
ALTER TABLE `paristakecare_disponibility`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_prestataire` (`id_prestataire`);

--
-- Index pour la table `paristakecare_effectue`
--
ALTER TABLE `paristakecare_effectue`
  ADD KEY `id_prestation` (`id_prestation`),
  ADD KEY `id_prestataire` (`id_prestataire`);

--
-- Index pour la table `paristakecare_facture`
--
ALTER TABLE `paristakecare_facture`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_bailleur` (`id_bailleur`),
  ADD KEY `id_prestataire` (`id_prestataire`),
  ADD KEY `id_prestation` (`id_prestation`);

--
-- Index pour la table `paristakecare_fais_facture`
--
ALTER TABLE `paristakecare_fais_facture`
  ADD KEY `id_facture` (`id_facture`),
  ADD KEY `id_prestation` (`id_prestation`);

--
-- Index pour la table `paristakecare_possède`
--
ALTER TABLE `paristakecare_possède`
  ADD KEY `id_bailleur` (`id_bailleur`),
  ADD KEY `id_bien` (`id_bien`);

--
-- Index pour la table `paristakecare_prestataire`
--
ALTER TABLE `paristakecare_prestataire`
  ADD KEY `id` (`id`);

--
-- Index pour la table `paristakecare_prestation`
--
ALTER TABLE `paristakecare_prestation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_bien` (`id_bien`),
  ADD KEY `id_prestataire` (`id_prestataire`);

--
-- Index pour la table `paristakecare_reserve`
--
ALTER TABLE `paristakecare_reserve`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_voyageur` (`id_voyageur`),
  ADD KEY `id_bien` (`id_bien`);

--
-- Index pour la table `paristakecare_réserve_presta`
--
ALTER TABLE `paristakecare_réserve_presta`
  ADD KEY `id_taker` (`id_taker`);

--
-- Index pour la table `paristakecare_réserve_presta_bailleur`
--
ALTER TABLE `paristakecare_réserve_presta_bailleur`
  ADD KEY `id_prestation` (`id_prestation`),
  ADD KEY `id_bailleur` (`id_bailleur`);

--
-- Index pour la table `paristakecare_réserve_presta_voyageur`
--
ALTER TABLE `paristakecare_réserve_presta_voyageur`
  ADD KEY `id_prestation` (`id_prestation`),
  ADD KEY `id_voyageur` (`id_voyageur`);

--
-- Index pour la table `paristakecare_tickets`
--
ALTER TABLE `paristakecare_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paristakecare_type_presta`
--
ALTER TABLE `paristakecare_type_presta`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paristakecare_user`
--
ALTER TABLE `paristakecare_user`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `paristakecare_voyageur`
--
ALTER TABLE `paristakecare_voyageur`
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `paristakecare_bien`
--
ALTER TABLE `paristakecare_bien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `paristakecare_disponibility`
--
ALTER TABLE `paristakecare_disponibility`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `paristakecare_facture`
--
ALTER TABLE `paristakecare_facture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `paristakecare_prestation`
--
ALTER TABLE `paristakecare_prestation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `paristakecare_reserve`
--
ALTER TABLE `paristakecare_reserve`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `paristakecare_tickets`
--
ALTER TABLE `paristakecare_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `paristakecare_type_presta`
--
ALTER TABLE `paristakecare_type_presta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `paristakecare_user`
--
ALTER TABLE `paristakecare_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `paristakecare_bailleur`
--
ALTER TABLE `paristakecare_bailleur`
  ADD CONSTRAINT `paristakecare_bailleur_ibfk_1` FOREIGN KEY (`id`) REFERENCES `paristakecare_user` (`id`);

--
-- Contraintes pour la table `paristakecare_bien`
--
ALTER TABLE `paristakecare_bien`
  ADD CONSTRAINT `paristakecare_bien_ibfk_1` FOREIGN KEY (`id_bailleur`) REFERENCES `paristakecare_bailleur` (`id`);

--
-- Contraintes pour la table `paristakecare_consulte`
--
ALTER TABLE `paristakecare_consulte`
  ADD CONSTRAINT `paristakecare_consulte_ibfk_1` FOREIGN KEY (`id_bailleur`) REFERENCES `paristakecare_bailleur` (`id`),
  ADD CONSTRAINT `paristakecare_consulte_ibfk_2` FOREIGN KEY (`id_voyageur`) REFERENCES `paristakecare_voyageur` (`id`),
  ADD CONSTRAINT `paristakecare_consulte_ibfk_3` FOREIGN KEY (`id_bien`) REFERENCES `paristakecare_bien` (`id`);

--
-- Contraintes pour la table `paristakecare_disponibility`
--
ALTER TABLE `paristakecare_disponibility`
  ADD CONSTRAINT `paristakecare_disponibility_ibfk_1` FOREIGN KEY (`id_prestataire`) REFERENCES `paristakecare_prestataire` (`id`);

--
-- Contraintes pour la table `paristakecare_effectue`
--
ALTER TABLE `paristakecare_effectue`
  ADD CONSTRAINT `paristakecare_effectue_ibfk_1` FOREIGN KEY (`id_prestation`) REFERENCES `paristakecare_prestation` (`id`),
  ADD CONSTRAINT `paristakecare_effectue_ibfk_2` FOREIGN KEY (`id_prestataire`) REFERENCES `paristakecare_prestataire` (`id`);

--
-- Contraintes pour la table `paristakecare_facture`
--
ALTER TABLE `paristakecare_facture`
  ADD CONSTRAINT `paristakecare_facture_ibfk_1` FOREIGN KEY (`id_bailleur`) REFERENCES `paristakecare_bailleur` (`id`),
  ADD CONSTRAINT `paristakecare_facture_ibfk_2` FOREIGN KEY (`id_prestataire`) REFERENCES `paristakecare_prestataire` (`id`),
  ADD CONSTRAINT `paristakecare_facture_ibfk_3` FOREIGN KEY (`id_prestation`) REFERENCES `paristakecare_prestation` (`id`);

--
-- Contraintes pour la table `paristakecare_fais_facture`
--
ALTER TABLE `paristakecare_fais_facture`
  ADD CONSTRAINT `paristakecare_fais_facture_ibfk_1` FOREIGN KEY (`id_facture`) REFERENCES `paristakecare_facture` (`id`),
  ADD CONSTRAINT `paristakecare_fais_facture_ibfk_2` FOREIGN KEY (`id_prestation`) REFERENCES `paristakecare_prestataire` (`id`);

--
-- Contraintes pour la table `paristakecare_possède`
--
ALTER TABLE `paristakecare_possède`
  ADD CONSTRAINT `paristakecare_possède_ibfk_1` FOREIGN KEY (`id_bailleur`) REFERENCES `paristakecare_bailleur` (`id`),
  ADD CONSTRAINT `paristakecare_possède_ibfk_2` FOREIGN KEY (`id_bien`) REFERENCES `paristakecare_bien` (`id`);

--
-- Contraintes pour la table `paristakecare_prestataire`
--
ALTER TABLE `paristakecare_prestataire`
  ADD CONSTRAINT `paristakecare_prestataire_ibfk_1` FOREIGN KEY (`id`) REFERENCES `paristakecare_user` (`id`);

--
-- Contraintes pour la table `paristakecare_prestation`
--
ALTER TABLE `paristakecare_prestation`
  ADD CONSTRAINT `paristakecare_prestation_ibfk_1` FOREIGN KEY (`id_bien`) REFERENCES `paristakecare_bien` (`id`),
  ADD CONSTRAINT `paristakecare_prestation_ibfk_2` FOREIGN KEY (`id_prestataire`) REFERENCES `paristakecare_prestataire` (`id`);

--
-- Contraintes pour la table `paristakecare_reserve`
--
ALTER TABLE `paristakecare_reserve`
  ADD CONSTRAINT `paristakecare_reserve_ibfk_1` FOREIGN KEY (`id_voyageur`) REFERENCES `paristakecare_voyageur` (`id`),
  ADD CONSTRAINT `paristakecare_reserve_ibfk_2` FOREIGN KEY (`id_bien`) REFERENCES `paristakecare_bien` (`id`);

--
-- Contraintes pour la table `paristakecare_réserve_presta`
--
ALTER TABLE `paristakecare_réserve_presta`
  ADD CONSTRAINT `paristakecare_réserve_presta_ibfk_1` FOREIGN KEY (`id_taker`) REFERENCES `paristakecare_user` (`id`);

--
-- Contraintes pour la table `paristakecare_réserve_presta_bailleur`
--
ALTER TABLE `paristakecare_réserve_presta_bailleur`
  ADD CONSTRAINT `paristakecare_réserve_presta_bailleur_ibfk_1` FOREIGN KEY (`id_prestation`) REFERENCES `paristakecare_prestation` (`id`),
  ADD CONSTRAINT `paristakecare_réserve_presta_bailleur_ibfk_2` FOREIGN KEY (`id_bailleur`) REFERENCES `paristakecare_bailleur` (`id`);

--
-- Contraintes pour la table `paristakecare_réserve_presta_voyageur`
--
ALTER TABLE `paristakecare_réserve_presta_voyageur`
  ADD CONSTRAINT `paristakecare_réserve_presta_voyageur_ibfk_1` FOREIGN KEY (`id_prestation`) REFERENCES `paristakecare_prestation` (`id`),
  ADD CONSTRAINT `paristakecare_réserve_presta_voyageur_ibfk_2` FOREIGN KEY (`id_voyageur`) REFERENCES `paristakecare_voyageur` (`id`);

--
-- Contraintes pour la table `paristakecare_voyageur`
--
ALTER TABLE `paristakecare_voyageur`
  ADD CONSTRAINT `paristakecare_voyageur_ibfk_1` FOREIGN KEY (`id`) REFERENCES `paristakecare_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
