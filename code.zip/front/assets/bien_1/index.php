<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lien vers les documents</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 5rem;
        }
        .container {
            max-width: 960px;
        }
        .list-group-item {
            background-color: #fff;
            border-color: #dee2e6;
        }
        .list-group-item:hover {
            background-color: #e9ecef;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Lien vers les documents</h1>
        <div class="list-group mt-3"><a href="photo1_bien_1.jpg" class="list-group-item">photo1_bien_1.jpg</a><a href="photo2_bien_1.jpg" class="list-group-item">photo2_bien_1.jpg</a></div>
    </div>
    <button class="btn btn-primary fixed-bottom m-3" onclick="window.history.back()">Retour</button>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>