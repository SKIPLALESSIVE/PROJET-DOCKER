<?php
// logout.php
setcookie("token", "", time() - 3600, "/");
header("Location: index.php"); // Rediriger vers la page de connexion après la déconnexion
exit;
