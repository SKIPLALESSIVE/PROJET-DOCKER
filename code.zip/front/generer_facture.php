<?php
require_once('tcpdf/tcpdf.php');


    // Création d'une nouvelle instance TCPDF
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Paramètres du document
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Nom de l\'auteur');
    $pdf->SetTitle('Facture');
    $pdf->SetSubject('Facture');
    $pdf->SetKeywords('Facture, PDF');

    // En-tête et pied de page
    $pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, 'Facture', 'Nom de l\'auteur');
    $pdf->setFooterData(array(0,64,0), array(0,64,128));

    // Paramètres de la police
    $pdf->SetFont('helvetica', '', 12);

    // Ajout d'une page
    $pdf->AddPage();

    // Contenu de la facture
    $pdf->Cell(0, 10, 'Facture', 0, 1, 'C');
    $pdf->Cell(0, 10, 'Numéro de la facture: 001', 0, 1);
    $pdf->Cell(0, 10, 'Date: ' . date('Y-m-d'), 0, 1);

    // Nom du fichier PDF
    $filename = 'facture.pdf';

    // Sortie du PDF vers le navigateur
    $pdf->Output($filename, 'I');

    // Fermeture du PDF
    $pdf->close();
?>
