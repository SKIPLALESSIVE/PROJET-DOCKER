<?php 
require_once __DIR__ .  '/../database/connection.php';
$error = [];

if(count($_POST) < 8 || !isset($_POST['lastname']) || !isset($_POST['firstname']) || !isset($_POST['email']) || !isset($_POST['address']) || !isset($_POST['phone']) || !isset($_POST['phoneWork']) || !isset($_POST['password']) || !isset($_POST['passwordVerify']) || !isset($_POST['g-recaptcha-response'])) {
    $error[] = "Tous les champs n'ont pas été remplis";
    $_SESSION['registerErrors'] = $error;
    header('Location: ../register.php');
    die();
}

$lastnameCleaned = strtoupper(trim($_POST['lastname']));
$firstnameCleaned = ucfirst(strtolower(trim($_POST['firstname'])));
$emailCleaned = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
$addressCleaned = strtolower(trim($_POST['address']));
$phoneCleaned = trim($_POST['phone']);
$passwordCleaned = trim($_POST['password']);
$passwordVerifyCleaned = trim($_POST['passwordVerify']);
$recaptchaResponse = $_POST['g-recaptcha-response'];

if(strlen($lastnameCleaned) < 2 || strlen($lastnameCleaned) > 50) {
    $error[] = "Le nom doit contenir entre 2 et 50 caractères";
} else {
    if (!preg_match("/^[a-zA-Z-'À-ÿ ]*$/u", $lastnameCleaned)) {
        $error[] = "Seuls les lettres, les espaces et les accents sont autorisés pour le nom";
    }
}

if(strlen($firstnameCleaned) < 2 || strlen($firstnameCleaned) > 50) {
    $error[] = "Le prénom doit contenir entre 2 et 50 caractères";
} else {
    if (!preg_match("/^[a-zA-Z-'À-ÿ ]*$/u", $firstnameCleaned)) {
        $error[] = "Seuls les lettres, les espaces et les accents sont autorisés pour le prénom";
    }
}

if(!filter_var($emailCleaned, FILTER_VALIDATE_EMAIL)) {
    $error[] = "L'email n'est pas valide";
}

if(strlen($addressCleaned) < 2 || strlen($addressCleaned) > 100) {
    $error[] = "L'adresse doit contenir entre 2 et 100 caractères";
} else {
    if (!preg_match("/^[0-9] [a-zA-Z0-9]*$/", $addressCleaned)) {
        $error[] = "L'adresse doit être composée uniquement de chiffres et de lettres. Elle doit commencer par un chiffre et ne contenir que des chiffres et des lettres.";
    }
}

if(strlen($phoneCleaned) < 10 || strlen($phoneCleaned) > 10) {
    $error[] = "Le téléphone doit contenir 10 chiffres";
} else {
    if (!preg_match("/^[0-9]*$/", $phoneCleaned)) {
        $error[] = "Seuls les chiffres sont autorisés pour le téléphone";
    }
}


if(strlen($passwordCleaned) < 8 || strlen($passwordCleaned) > 50) {
    $error[] = "Le mot de passe doit contenir entre 8 et 50 caractères";
}

if($passwordCleaned !== $passwordVerifyCleaned) {
    $error[] = "Les mots de passe ne correspondent pas";
}

if(!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,50}$/", $passwordCleaned)) {
    $error[] = "Le mot de passe doit contenir au moins une lettre minuscule, une lettre majuscule, un chiffre et un caractère spécial";
}

if(empty($recaptchaResponse)) {
    $error[] = "Veuillez vérifier que vous n'êtes pas un robot";
}

if(count($error)!=0){
    foreach($error as $e){
        $_SESSION['registerErrors'][] = $e;
    }
    unset($_SESSION['registerData']);
    unset($_POST['password']);
    unset($_POST['passwordVerify']);
    $_SESSION['registerData'] = $_POST;
    header('Location: ../register.php');
} else {
    $data = [
        'lastname' => $lastnameCleaned,
        'firstname' => $firstnameCleaned,
        'email' => $emailCleaned,
        'address' => $addressCleaned,
        'phone' => $phoneCleaned,
        'password' => $passwordCleaned,
    ];
$database = getDatabaseConnection(); 
    if ($data === null) {
        http_response_code(400);
        echo "Invalid JSON data received.";
        exit;
    }
    $database = getDatabaseConnection();
    $statement = $database->prepare("INSERT INTO " . DB_PREFIX . "prestataire (lastname, firstname, address, phone, email, password) VALUES (:lastname, :firstname, :address, :phone, :email, :password)");
    $statement-> execute([
        'lastname' => $data['lastname'],
        'firstname' => $data['firstname'],
        'address' => $data['address'],
        'phone' => $data['phone'],
        'email' => $data['email'],
        'password' => password_hash($data['password'], PASSWORD_BCRYPT),
    ]);
    return true;
}
