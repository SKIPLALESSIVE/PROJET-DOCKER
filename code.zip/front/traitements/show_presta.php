<?php
require_once __DIR__ .  '/../database/connection.php';
$id = $_POST['id'];
$databaseConnection = getDatabaseConnection();
$statement = $databaseConnection->prepare('SELECT * FROM ' . DB_PREFIX . 'type_presta');
$statement->execute();
$prestations = [];
while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
  $all_id = explode('.', $row['all_id']);
  foreach ($all_id as $bloc_id) {
    if ($bloc_id == $id) {
      $prestations[] = $row;
      break;
    }
  }
}

echo json_encode($prestations);
