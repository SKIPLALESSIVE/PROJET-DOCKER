<?php 
require_once __DIR__ .  '/../database/connection.php';
session_start();
$id = $_SESSION['id'];
    $databaseConnection = getDatabaseConnection();
$statement = $databaseConnection->prepare('SELECT * FROM ' . DB_PREFIX . 'type_presta WHERE type_prestation = :type_prestation ');
$statement->execute([
    ':type_prestation' => $type,
]);
$statement = $statement->fetch(PDO::FETCH_ASSOC);
$user_id = $statement['all_id'];


if ($user_id == null) {
    $push = $id;
} else { 
$all_id = explode('.', $user_id);

if (in_array($id, $all_id)) {
    return false;
}
array_push($all_id, $id);
print_r($all_id);
$push = implode('.', $all_id);
}
    $query = $databaseConnection->prepare('UPDATE' . DB_PREFIX . 'type_presta (type_prestation, all_id) VALUES (:type_prestation, :all_id)');
    $query->execute([
        ':type_prestation' => $type,
        'all_id' => $push
    ]);
    return true;
