<?php
// Récupérer l'ID du prestataire
$userId = $_POST['userId'];

// Vérifier si le dossier de destination existe, sinon le créer
$uploadDir = "../assets/presta_$userId";
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true); // Créer le dossier et ses parents
}

// Boucler sur les fichiers téléchargés
foreach ($_FILES as $fileInput => $fileData) {
    // Récupérer les informations du fichier
    $fileName = $fileData['name'];
    $fileTmpName = $fileData['tmp_name'];
    $fileType = $_POST['fileType'];

    // Définir le nouveau nom de fichier
    $newFileName = $fileType . '_presta_' . $userId . '-' . time() . '.' . pathinfo($fileName, PATHINFO_EXTENSION);
    $existingFile = $uploadDir . '/' . $newFileName;
    if (file_exists($existingFile)) {
        unlink($existingFile);
    }

    $allowedExtensions = array('jpg', 'jpeg', 'png', 'pdf');
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    if (!in_array($fileExtension, $allowedExtensions)) {
        $response = array(
            'error' => 'L\'extension du fichier n\'est pas valide. Veuillez télécharger une photo au format JPG, JPEG ou PNG.'
        );
        header('Content-Type: application/json');
        echo json_encode($response);
        return false; 
    }
    // Déplacer le fichier vers le dossier de destination avec le nouveau nom
    $destination = "$uploadDir/$newFileName";
    if (move_uploaded_file($fileTmpName, $destination)) {
        // Envoyer la réponse au format JSON
        $response = array(
            'message' => 'Fichiers téléchargés avec succès.'
        );
        header('Content-Type: application/json');
        echo json_encode($response);

        // Créer le fichier index.php s'il n'existe pas ou mettre à jour les liens des documents
        $indexFile = "$uploadDir/index.php";
        $indexContent = '<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lien vers les documents</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles -->
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 5rem;
        }
        .container {
            max-width: 960px;
        }
        .list-group-item {
            background-color: #fff;
            border-color: #dee2e6;
        }
        .list-group-item:hover {
            background-color: #e9ecef;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Lien vers les documents</h1>
        <div class="list-group mt-3">';

        // Scanner le dossier pour obtenir la liste des fichiers
        $files = scandir($uploadDir);
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..' && $file !== 'index.php') {
                // Ajouter un lien pour chaque fichier dans le dossier (sauf index.php)
                $indexContent .= '<a href="' . $file . '" class="list-group-item">' . $file . '</a>';
            }
        }

        $indexContent .= '</div>
    </div>
    <button class="btn btn-primary fixed-bottom m-3" onclick="window.history.back()">Retour</button>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>';
        file_put_contents($indexFile, $indexContent);
    } else {
        // Gérer l'erreur si le déplacement du fichier a échoué
        $response = array(
            'error' => 'Erreur lors du téléchargement du fichier.'
        );
        header('Content-Type: application/json');
        echo json_encode($response);
    }
}
