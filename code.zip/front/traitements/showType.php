<?php 
require_once __DIR__ .  '/../database/connection.php';

function showAllType() {
    $databaseConnection = getDatabaseConnection();
    $statement = $databaseConnection->prepare("SELECT type_prestation FROM " . DB_PREFIX . "type_presta");
    $statement->execute();
    $types = $statement->fetchAll(PDO::FETCH_ASSOC);
    return json_encode($types);
}