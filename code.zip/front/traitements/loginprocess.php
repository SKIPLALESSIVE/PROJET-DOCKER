<?php
require_once __DIR__ . '/../database/connection.php';
print_r($_POST); 
$databaseConnection = getDatabaseConnection();
  
$email = $_POST['email'];  
$password = $_POST['password'];
$auth = $databaseConnection->prepare("SELECT id, password FROM " . DB_PREFIX . "prestataire WHERE email = :email ");
$auth->execute(array(
    ':email' => $email
));
$auth = $auth->fetch();
if (password_verify($password, $auth['password'])) {
    echo "Vous êtes connecté";
    session_start();
    $_SESSION['id'] = $auth['id'];
} else {
    echo "Mauvais identifiants";
}


