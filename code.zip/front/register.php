<?php include __DIR__ . '/template/header.php'; ?>

<?php
if (isset($_GET['message'])) {
    $message = $_GET['message'];
    echo "<script>window.alert(\"$message\");</script>";
}
?>

<title>Paris CareTaker Service - Prestataire Login</title>
</head>

<body>
    <?php include 'template/nav.php'; ?>

    <!-- Inscription -->
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="lunarWhiteText mt-0">Inscription</h2>
                    <hr class="divider duckBlueDarkBg" />
                    <form action="https://ela-dev.fr:3000/add_user" method="post" id="formulaireRegister"
                        class="needs-validation" novalidate>
                        <div class="row gx-3 mb-3">
                            <div class="col">
                                <div class="form-floating">
                                    <input class="form-control" name="lastname" type="text" id="lastname"
                                        placeholder="Votre Nom" required="required" />
                                    <label for="lastname">Nom</label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-floating">
                                    <input class="form-control" name="firstname" type="text" id="firstname"
                                        placeholder="Votre Prénom" required="required" />
                                    <label for="firstname">Prénom</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="email" type="email" id="email"
                                placeholder="name@example.com" required="required" />
                            <label for="email">Email</label>
                        </div>
                        <div class="row gx-3 mb-3">
                            <div class="col">
                                <div class="form-floating">
                                    <input class="form-control" name="password" type="password" id="password"
                                        placeholder="Votre Mot De Passe" required="required" />
                                    <label for="password">Mot De Passe</label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-floating">
                                    <input class="form-control" name="passwordVerify" type="password"
                                        id="passwordVerify" placeholder="Confirmer Votre Mot De Passe"
                                        required="required" />
                                    <label for="passwordVerify">Confirmer Mot De Passe</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="address" type="text" id="address"
                                placeholder="Votre Adresse" required="required" />
                            <label for="address">Adresse</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="phone" type="text" id="phone"
                                placeholder="Votre Numéro de Téléphone" required="required" />
                            <label for="phone">Numéro de Téléphone</label>
                        </div>
                        <hr class="divider duckBlueDarkBg" />
                        <div>
                            <select class="form-select" name="interface" id="interface" required>
                                <option value="" disabled selected>Sélectionner une interface</option>
                                <option value="bailleur">Bailleur</option>
                                <option value="prestataire">Prestataire</option>
                                <option value="voyageur">Voyageur</option>
                            </select>
                        </div>
                        <hr class="divider duckBlueDarkBg" />
                        <!-- Champs hidden et bouton S'inscrire pour voyageur -->
                        <div id="voyageurFields" style="display: none;">
                            <div class="form-floating mb-3">
                                <input type="hidden" name="interface_voyageur" value="voyageur">
                                <input type="hidden" id="donneesJson_voyageur" name="donneesJson_voyageur">
                                <button class="btn btn-light btn-xl duckBlueDarkBg textLunarWhite"
                                    type="submit">S'inscrire</button>
                            </div>
                        </div>
                        <!-- Champs hidden et bouton S'inscrire pour prestataire -->

                        <div id="prestataireFields" style="display: none;">
                            <div class="form-floating mb-3">
                                <input class="form-control" name="type_presta" type="text" id="type_presta"
                                    placeholder="Rentrez votre talent" required="required" />
                                <label for="type_presta">Type de prestation</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input class="form-control" name="price" type="text" id="price" placeholder="Prix"
                                    required="required" />
                                <label for="price">Prix</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input class="form-control" name="duration" type="text" id="duration"
                                    placeholder="Durée" required="required" />
                                <label for="duration">Durée</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="hidden" name="interface_prestataire" value="prestataire">
                                <input type="hidden" id="donneesJson_prestataire" name="donneesJson_prestataire">
                                <button class="btn btn-light btn-xl duckBlueDarkBg textLunarWhite"
                                    type="submit">S'inscrire</button>
                            </div>
                        </div>

                </div>
                <!-- Champs hidden et bouton S'inscrire pour bailleur -->
                <div id="bailleurFields" style="display: none;">
                    <div class="form-floating mb-3">
                        <input type="hidden" name="interface_bailleur" value="bailleur">
                        <input class="form-control" name="phoneWork" type="text" id="phoneWork"
                            placeholder="Téléphone du travail" />
                        <label for="phoneWork">Téléphone de travail</label>
                    </div>
                    <div class="form-floating mb-3">
                        <!-- Vos autres champs pour bailleur -->
                    </div>
                    <button class="btn btn-light btn-xl duckBlueDarkBg textLunarWhite" type="submit">S'inscrire</button>
                </div>
                </form>
            </div>
        </div>
        </div>
    </section>

    <script>
        document.getElementById('interface').addEventListener('change', function () {
            if (this.value === 'bailleur') {
                document.getElementById('bailleurFields').style.display = 'block';
                document.getElementById('prestataireFields').style.display = 'none';
                document.getElementById('voyageurFields').style.display = 'none';
            } else if (this.value === 'prestataire') {
                document.getElementById('prestataireFields').style.display = 'block';
                document.getElementById('bailleurFields').style.display = 'none';
                document.getElementById('voyageurFields').style.display = 'none';
            } else if (this.value === 'voyageur') {
                document.getElementById('voyageurFields').style.display = 'block';
                document.getElementById('bailleurFields').style.display = 'none';
                document.getElementById('prestataireFields').style.display = 'none';
            } else {
                document.getElementById('bailleurFields').style.display = 'none';
                document.getElementById('prestataireFields').style.display = 'none';
                document.getElementById('voyageurFields').style.display = 'none';
            }

            // Mise à jour des données JSON pour l'interface sélectionnée
            const formData = new FormData(document.getElementById('formulaireRegister'));
            const data = {};
            for (const [cle, valeur] of formData.entries()) {
                data[cle] = valeur;
            }
            const donneesJson = JSON.stringify(data);
            if (this.value === 'bailleur') {
                document.getElementById('donneesJson_bailleur').value = donneesJson;
            } else if (this.value === 'prestataire') {
                document.getElementById('donneesJson_prestataire').value = donneesJson;
            } else if (this.value === 'voyageur') {
                document.getElementById('donneesJson_voyageur').value = donneesJson;
            }
        });
    </script>