<?php
require_once __DIR__ . '/traitements/showType.php';

if (!isset($_GET['token'])) {
    if(isset($_COOKIE['token'])){
        $token = $_COOKIE['token'];
    }else{
        header('Location: /2A3-EJH-PA/login.php');
        exit;
    }
} else {
    $token = $_GET['token'];
}

setcookie('token', $token, time() + 3600, '/', null, false, true);

$types = showAllType();
$types = json_decode($types, true);

include __DIR__ . '/template/header.php';
include __DIR__ . '/template/startSession.php';
include __DIR__ . '/template/nav.php';

$_SESSION['interface'] = 'prestataire';

?>
<script>
    var userId;
    var token = "<?php echo $token ?>";
    <?php require_once __DIR__ . '/js/recup_token.js'; ?>
</script>

<body id="page-top">

    <section id="dashboard" class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5 lunarWhiteText text-center">
            <hr class="divider">
            <h2>Espace prestataire</h2>
            <hr class="divider">
            <form action="javascript:void(0);" method="post">
                <input type="hidden" name="id" value="" id="userId">
                <button type="submit" onclick="afficherPrestations()" class="btn btn-primary">Voir mes prestations</button>
            </form>

            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 col-xl-6 text-center">
                    <div id="liste-prestations"></div>
                    <hr class="divider">
                    <a href="calendrier_presta.php"><button class="btn btn-primary">Voir mon calendrier</button></a>
                </div>
            </div>
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 col-xl-6 text-center">
                    <div id="liste-prestations"></div>
                    <hr class="divider">
                    <a href="generer_facture.php"><button class="btn btn-primary">Facture PDF </button></a>
                    <hr class="divider">
                </div>
            </div>
        </div>
    </section>
</body>
<?php include 'template/footer.php';  ?>
<script>
    function showForm() {
        document.getElementById("form").style.display = toggleElementVisibility();
    }

    function toggleElementVisibility() {
        const element = document.getElementById("form");
        const currentDisplay = element.style.display;
        return currentDisplay === "none" ? "block" : "none";
    }

    document.getElementById("form").addEventListener("submit", afficherPrestations);

    token = "<?php echo $token ?>";
    UserInfo = recup_token(token);
    recup_token(token)
        .then(UserInfo => {
            userId = UserInfo.id;
            const is_validated = UserInfo.is_validated;
            if (is_validated == -1) {
                window.location.href = "/2A3-EJH-PA/not_validated/add_docs_presta.php?message=Votre compte n'est pas encore validé, veuillez ajouter des documents";
            } else if (is_validated != 1) {
                sessionStorage.setItem('is_validated', '1', );
                sessionStorage.setItem('userId', userId);
            }
            if (is_validated == 5) {
                sessionStorage.setItem('is_admin', '1');
                window.location.href = "admin/dashboard_admin_presta.php";
            }

            document.getElementById('userId').value = userId;
        })
        .catch(error => {
            console.error("Error:", error);
        });

    function afficherPrestations() {
        fetch('https://ela-dev.fr:3000/show_type_prestation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: parseInt(userId)
                }) // Convertir userId en entier
            })
            .then(response => response.json())
            .then(prestations => {
                const listePrestations = document.getElementById("liste-prestations");
                listePrestations.innerHTML = "";

                prestations.forEach(prestation => {
                    const type_prestation = prestation.type_prestation;
                    const idPricePairs = prestation.all_id.split(".");
                    idPricePairs.forEach(pair => {
                        const [id, price] = pair.split(":");
                        if (parseInt(id) === parseInt(userId)) { // Comparaison des ID convertis en entier
                            const elementPrestation = document.createElement("div");
                            elementPrestation.textContent = `Type de prestation : ${type_prestation}, Prix : ${price}`;
                            listePrestations.appendChild(elementPrestation);
                        }
                    });
                });
            });
    }
</script>