<?php
if (!isset($_COOKIE['token'])) {
  header('Location: /2A3-EJH-PA/login.php');
}
?>