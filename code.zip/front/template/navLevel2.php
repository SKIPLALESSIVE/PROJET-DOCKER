<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
    <div class="container px-4 px-lg-5">
        <a class="navbar-brand" href="../index.php">Paris CareTaker Service</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ms-auto my-2 my-lg-0">
                <?php
                if (isset($_COOKIE["token"])) {
                    echo '<li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>';
                } else {
                    echo '<li class="nav-item"><a class="nav-link" href="../login.php">Login</a></li>';
                }
                ?>
            </ul>
        </div>
    </div>
</nav>

<script>
    // Effectuer une requête pour vérifier si l'utilisateur est administrateur
    fetch("https://ela-dev.fr:3000/is_admin_cookie_navbar", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + "<?php echo ($_COOKIE['token']) ?>" // Remplacer getToken() par votre méthode pour obtenir le token
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.isPcs) {
                // Ajouter l'icône d'administrateur à la barre de navigation
                const navBar = document.getElementById('mainNav');
                const adminIcon = document.createElement('li');
                adminIcon.className = 'nav-item';
                adminIcon.innerHTML = '<a class="nav-link" href="../gestion/index.php"><i class="bi bi-person-circle"></i> Gestion</a>';
                navBar.querySelector('.navbar-nav').appendChild(adminIcon);

                if (data.isAdmin) {
                    // Ajouter l'icône d'administrateur à la barre de navigation
                    const navBar = document.getElementById('mainNav');
                    const adminIcon = document.createElement('li');
                    adminIcon.className = 'nav-item';
                    adminIcon.innerHTML = '<a class="nav-link" href="../admin/index.php"><i class="bi bi-person-circle"></i> Admin</a>';
                    navBar.querySelector('.navbar-nav').appendChild(adminIcon);
                }
            }
        })
        .catch(error => {
            console.error('Erreur lors de la vérification de l\'administrateur:', error.message);
        });
</script>