<?php
define("DB_HOST", "172.19.0.3");
define("DB_NAME", "ParisTakeCare");
define("DB_USER", "root");
define("DB_PWD", "azerty");
define("DB_PORT", "3306");
define("DB_PREFIX", "paristakecare_");
