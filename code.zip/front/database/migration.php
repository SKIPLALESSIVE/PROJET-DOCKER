<?php

require_once __DIR__ .  '/connection.php';
require_once __DIR__ .  '/const.inc.php';

try {
    $databaseConnection = getDatabaseConnection();

    $createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    $databaseConnection->exec($createDatabaseQuery);

    echo "Database created successfully.";
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "etat_lieux");
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "fais_facture");
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "disponibility");
    $statement->execute();
    echo "Table fais_facture dropped successfully.";
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "consulte");
    echo "Table consulte dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "réserve_presta_bailleur");
    echo "Table réserve_presta_bailleur dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "réserve_presta");
    echo "Table réserve dropped successfully.";
    $statement->execute();

    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "réserve_presta_voyageur");
    echo "Table réserve_presta dropped successfully.";
    $statement->execute();


    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "effectue");
    echo "Table effectue dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "reserve");
    echo "Table reserve dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "facture");
    echo "Table facture dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "prestation");
    echo "Table prestation dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "prestataire");
    echo "Table prestataire dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "voyageur");
    echo "Table voyageur dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "possède");
    echo "Table possède dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "bien");
    echo "Table bien dropped successfully.";
    $statement->execute();
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "bailleur");
    $statement->execute();
    echo "Table bailleur dropped successfully.";
    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "type_presta");
    echo "Table type_presta dropped successfully.";
    $statement->execute();

    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "tickets");
    $statement->execute();

    $statement = $databaseConnection->prepare("DROP TABLE IF EXISTS " . DB_PREFIX . "user");
    $statement->execute();
    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "user (
        id INTEGER  AUTO_INCREMENT PRIMARY KEY,
        role INTEGER DEFAULT -1,
        lastname VARCHAR(60) NOT NULL,
        firstname VARCHAR(60) NOT NULL,
        address VARCHAR(200),
        phone CHAR(10),
        email VARCHAR(200),
        password VARCHAR(255),
        token VARCHAR(255)

    )");
    $createTable->execute();
    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "bailleur (
        id INTEGER,
        contact_times INTEGER,
        personnal INTEGER DEFAULT 0,
        entreprise INTEGER DEFAULT 0,
        phoneWork CHAR(10),
        token VARCHAR(255), 
        FOREIGN KEY (id) REFERENCES " . DB_PREFIX . "user(id)

    )");
    $createTable->execute();
    echo "Table bailleur succefully imported.";
    $createTable = $databaseConnection->prepare("
    CREATE TABLE " . DB_PREFIX . "bien (
        id INTEGER AUTO_INCREMENT PRIMARY KEY,
        id_bailleur INTEGER, 
        is_validated INTEGER,
        subscription_paid INTEGER,
        subscription_date DATE,
        land VARCHAR(10),
        bien_type VARCHAR(60),
        location_type VARCHAR(60),
        address VARCHAR(200),
        chambers_nb INTEGER,
        occupants_nb INTEGER,
        id_docs INTEGER,
        FOREIGN KEY (id_bailleur) REFERENCES " . DB_PREFIX . "bailleur(id)
    )
");
    $createTable->execute();
    echo "Table bien succefully imported.";
    $createTable = $databaseConnection->prepare("
    CREATE TABLE " . DB_PREFIX . "possède (
        id_bailleur INTEGER,
        id_bien INTEGER,
        FOREIGN KEY (id_bailleur) REFERENCES " . DB_PREFIX . "bailleur(id),
        FOREIGN KEY (id_bien) REFERENCES " . DB_PREFIX . "bien(id)
    )
");

    $createTable->execute();
    echo "Table possède succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "voyageur (
        id INTEGER,
        is_vip INTEGER, 
        is_vip_date DATE,
        FOREIGN KEY (id) REFERENCES " . DB_PREFIX . "user(id)
    )");


    $createTable->execute();
    echo "Table voyageur succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "prestataire (
        id INTEGER,
        type_prestation VARCHAR(255),
        is_validated INTEGER DEFAULT -1,
        FOREIGN KEY (id) REFERENCES " . DB_PREFIX . "user(id)
    )");

    $createTable->execute();
    echo "Table prestataire succefully imported.";


    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "prestation (
        id INTEGER AUTO_INCREMENT PRIMARY KEY,
        id_prestataire INTEGER,
        id_bien INTEGER,
        type VARCHAR(60),
        date DATE,
        time TIME,
        duration INTEGER,
        price INTEGER,
        evaluation INTEGER,
        FOREIGN KEY (id_bien) REFERENCES " . DB_PREFIX . "bien(id),
        FOREIGN KEY (id_prestataire) REFERENCES " . DB_PREFIX . "prestataire(id)

    )");
    $createTable->execute();
    echo "Table prestation succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "facture (
            id INTEGER AUTO_INCREMENT PRIMARY KEY,
            id_prestation INTEGER,
            id_prestataire INTEGER,
            id_bailleur INTEGER,
            date DATE,
            price INTEGER,
            is_paid INTEGER,
            FOREIGN KEY (id_bailleur) REFERENCES " . DB_PREFIX . "bailleur(id),
            FOREIGN KEY (id_prestataire) REFERENCES " . DB_PREFIX . "prestataire(id),
            FOREIGN KEY (id_prestation) REFERENCES " . DB_PREFIX . "prestation(id)
        )");

    $createTable->execute();
    echo "Table facture succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "reserve (
            id INTEGER AUTO_INCREMENT PRIMARY KEY,
            id_voyageur INTEGER,
            nb_personnes INTEGER,
            id_bien INTEGER,
            start_date DATE,
            end_date DATE,
            is_validated INTEGER,
            is_paid INTEGER,
            note INTEGER,
            FOREIGN KEY (id_voyageur) REFERENCES " . DB_PREFIX . "voyageur(id),
            FOREIGN KEY (id_bien) REFERENCES " . DB_PREFIX . "bien(id)
        )");


    $createTable->execute();
    echo "Table reserve succefully imported.";


    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "effectue (
        id_prestation INTEGER,
        id_prestataire INTEGER,
        FOREIGN KEY (id_prestation) REFERENCES " . DB_PREFIX . "prestation(id),
        FOREIGN KEY (id_prestataire) REFERENCES " . DB_PREFIX . "prestataire(id)
    )");

    $createTable->execute();
    echo "Table effectue succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "type_presta (
        id INTEGER AUTO_INCREMENT PRIMARY KEY,
       type_prestation VARCHAR(255), 
       all_id text DEFAULT '0:0.'
    )");
    $createTable->execute();
    echo "Table reserve succefully imported.";


    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "disponibility (
        id INTEGER AUTO_INCREMENT PRIMARY KEY,
        id_prestataire INTEGER,
        disponibility text,
        FOREIGN KEY (id_prestataire) REFERENCES " . DB_PREFIX . "prestataire(id)
    )");
    $createTable->execute();
    echo "Table disponiblity succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "réserve_presta_voyageur (
        id_prestation INTEGER,
        id_voyageur INTEGER,
        FOREIGN KEY (id_prestation) REFERENCES " . DB_PREFIX . "prestation(id),
        FOREIGN KEY (id_voyageur) REFERENCES " . DB_PREFIX . "voyageur(id)
    )");

    $createTable->execute();
    echo "Table réserve_presta_voyageur succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "réserve_presta (
        id_taker INTEGER,
        ask_taker TEXT,
        FOREIGN KEY (id_taker) REFERENCES " . DB_PREFIX . "user(id)
    )");

    $createTable->execute();
    echo "Table réserve_presta_bailleur succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "consulte (
        id_bailleur INTEGER,
        id_voyageur INTEGER,
        id_bien INTEGER,
        FOREIGN KEY (id_bailleur) REFERENCES " . DB_PREFIX . "bailleur(id),
        FOREIGN KEY (id_voyageur) REFERENCES " . DB_PREFIX . "voyageur(id),
        FOREIGN KEY (id_bien) REFERENCES " . DB_PREFIX . "bien(id)
    )");

    $createTable->execute();
    echo "Table consulte succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "fais_facture (
        id_facture INTEGER,
        id_prestation INTEGER,
        FOREIGN KEY (id_facture) REFERENCES " . DB_PREFIX . "facture(id),
        FOREIGN KEY (id_prestation) REFERENCES " . DB_PREFIX . "prestataire(id)
    )");
    $createTable->execute();
    echo "Table fais_facture succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "tickets (
        id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
        title varchar(60) NOT NULL,
        content text NOT NULL,
        email varchar(255) NOT NULL,
        category varchar(30) NOT NULL,
        time timestamp NOT NULL DEFAULT current_timestamp(),
        administrator_id int(11) DEFAULT NULL,
        status tinyint(11) NOT NULL DEFAULT 0,
        level tinyint(11) NOT NULL DEFAULT 0
      )");
    $createTable->execute();
    echo "Table tickets succefully imported.";

    $createTable = $databaseConnection->prepare("CREATE TABLE " . DB_PREFIX . "etat_lieux (
        id_resa INTEGER,
        id_voyageur INTEGER,
        type VARCHAR(10),
        date DATE,
        proprety INTEGER,
        etat INTEGER,
        facility INTEGER,
        FOREIGN KEY (id_resa) REFERENCES " . DB_PREFIX . "reserve(id),
        FOREIGN KEY (id_bailleur) REFERENCES " . DB_PREFIX . "bailleur(id),
        FOREIGN KEY (id_voyageur) REFERENCES " . DB_PREFIX . "voyageur(id)
    )");

    $createTable->execute();
    echo "Table consulte succefully imported.";


} catch (Exception $exception) {
    echo "Error: " . $exception->getMessage();
}
