<?php

require_once __DIR__ . '/const.inc.php';
function getDatabaseConnection()
{
    return new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PWD);
}
