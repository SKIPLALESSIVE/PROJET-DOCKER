function liste_prestataire() {
    return fetch("https://ela-dev.fr:3000/liste_not_validated_presta", {})
    .then(response => response.json())
    .then(data => {
        const tableaux = data.map(item => {
            return {
                id: item.id,
                lastname: item.lastname,
                firstname: item.firstname,
                email: item.email,
                phone: item.phone,
            };
        });
        console.log(tableaux);
        return tableaux;
    });
}
