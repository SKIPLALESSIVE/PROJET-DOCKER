<?php include 'template/headerAdministration.php'; ?>
<title>PCS - Bailleur - Administration</title>
</head>

<body id="page-top">
    <!-- Navigation-->
    <?php include 'template/navbarAdministrationLevel.php'; ?>
    <!-- Nav Section -->
    <section class="page-section duckBlueBg" id="navigation">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 col-xl-6 text-center">
                    <h2 class="mt-0 textLunarWhite">Accueil des pages d'administration</h2>
                    <hr class="divider" />
                    <a href="userAdministration.php"><button class="btn btn-primary">Prestataires</button></a>
                    <a href="seeBailleurs.php"><button class="btn btn-primary">Bailleurs</button></a>
                    <a href="validateAdministration.php"><button class="btn btn-primary">Validation</button></a>
                    <a href="voir_all_resa.php"><button class="btn btn-primary">Réservation</button></a>
                    <a href="voir_all_voyageurs.php"><button class="btn btn-primary">Voyageurs</button></a>
                    <hr class="divider" />
                </div>
            </div>
        </div>
    </section>
    <!-- Footer-->
    <?php include '../template/footer.php' ?>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
    <script>
        function responsiveNavBar() {
            document.getElementById("navbarResponsive").classList.toggle("show");
        }
    </script>
</body>

</html>