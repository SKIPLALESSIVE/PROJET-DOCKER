<?php include 'template/headerAdministration.php'; ?>
<title>Voir toutes les réservations et les supprimer</title>
<link rel="stylesheet" href="../css/styles.css">
</head>

<body id="page-top">
    <!-- Navigation-->
    <?php include 'template/navbarAdministrationLevel.php'; ?>
    <section class="page-section duckBlueBg" id="navigation">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">ID Voyageur</th>
                        <th scope="col">ID Bien</th>
                        <th scope="col">Date de début</th>
                        <th scope="col">Date de fin</th>
                        <th scope="col">Payé</th>
                        <th scope="col">Validé</th>
                        <th scope="col">Supprimer</th>
                        <th scope="col">Valider</th>
                    </tr>
                </thead>
                <tbody id="liste_resa_body"></tbody>
            </table>
        </div>
    </section>

    <script>
        fetch("https://ela-dev.fr:3000/all_reservations", {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                const listeResaBody = document.getElementById("liste_resa_body");
                data.forEach(reservation => {
                    const reservationRow = document.createElement("tr");
                    reservationRow.innerHTML = `
                    <td scope="row">${reservation.id}</td>
                    <td scope="row">${reservation.id_voyageur}</td>
                    <td scope="row">${reservation.id_bien}</td>
                    <td scope="row">${reservation.start_date}</td>
                    <td scope="row">${reservation.end_date}</td>
                    <td scope="row">${reservation.is_paid}</td>
                    <td scope="row">${reservation.is_validated}</td>
                    <td scope="row"><button onclick="supprimerReservation(${reservation.id})" class="btn btn-danger">Supprimer</button></td> 
                    <td scope="row"><button onclick="validerReservation(${reservation.id})" class="btn btn-primary">Valider</button></td> 
                `;

                    listeResaBody.appendChild(reservationRow);
                });
            })
            .catch(error => console.error("Erreur lors du chargement des réservations:", error));

        function supprimerReservation(idReservation) {
            fetch("https://ela-dev.fr:3000/delete_reservation", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: idReservation
                    })
                })
                .then(() => location.reload());
            console.log("Suppression de la réservation avec l'ID:", idReservation);
        }

        function validerReservation(idReservation) {
            fetch("https://ela-dev.fr:3000/validate_reservation", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: idReservation
                    })
                })
                .then(() => location.reload());
            console.log("Validation de la réservation avec l'ID:", idReservation);
        }
    </script>
</body>

</html>