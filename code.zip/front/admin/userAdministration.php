<?php include 'template/headerAdministration.php'; ?>
<title>PCS - Prestataires - Administration</title>
</head>

<body id="page-top">

    <!-- Navigation-->
    <?php include 'template/navbarAdministrationLevel.php'; ?>

    <!-- Administration -->
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-12 text-center">
                    <div id="prestataires-container">
                        <section>
                            <h2 class="text-uppercase mb-4">Liste des Prestataires</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col">Id</th>
                                            <th scope="col">Rôle</th>
                                            <th scope="col">Validé</th>
                                            <th scope="col">Nom</th>
                                            <th scope="col">Prénom</th>
                                            <th scope="col">Adresse</th>
                                            <th scope="col">Téléphone</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="liste-utilisateurs">
                                        <!-- Les utilisateurs seront ajoutés ici -->
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>

                    <script>
                        const presta = "prestataire";
                        document.addEventListener("DOMContentLoaded", function() {
                         
                            const url = 'https://ela-dev.fr:3000/show_prestataire';

                            const options = {
                                headers: {
                                    'Authorization': `Bearer <?php echo ($_COOKIE['token']); ?>` 
                                }
                            };

                            fetch(url, options)
                                .then(response => response.json())
                                .then(users => {
                                    console.log(users);
                                    const userList = document.getElementById('liste-utilisateurs');
                                    users.forEach(user => {
                                        const row = document.createElement('tr');
                                        row.innerHTML = `
                                            <td>${user.id}</td>
                                            <td>${presta}</td>
                                            <td>${user.is_validated}</td>
                                            <td>${user.lastname}</td>
                                            <td>${user.firstname}</td>
                                            <td>${user.address}</td>
                                            <td>${user.phone}</td>
                                            <td>${user.email}</td>
                                            <td>
                                                <form action="https://ela-dev.fr:3000/delete_presta" method="post" onsubmit="return submitForm(this);">
                                                    <input type="hidden" name="id" value="${user.id}">
                                                    <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                                </form>
                                            </td>
                                        `;
                                        userList.appendChild(row);
                                    });
                                })
                                .catch(error => {
                                    console.error('Erreur lors de la récupération des utilisateurs:', error);
                                });
                        });

                        function submitForm(form) {
                            const token = "<?php echo $_COOKIE['token']; ?>";
                            const id = form.querySelector('input[name="id"]').value;
                            const url = form.action;

                            fetch(url, {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Authorization': `Bearer ${token}`
                                    },
                                    body: JSON.stringify({
                                        id: id
                                    })
                                })
                                .then(response => {
                                    if (!response.ok) {
                                        throw new Error('Erreur lors de la requête');
                                    }
                                    window.location.reload();
                                })
                                .then(data => {
                                    console.log(data.message);
                                })
                                .catch(error => {
                                    console.error('Erreur:', error);
                                });

                            return false;
                        }
                    </script>
                </div>
            </div>
        </div>
    </section>
    <script>
        function responsiveNavBar() {
            document.getElementById("navbarResponsive").classList.toggle("show");
        }
    </script>
    <!-- Footer-->
    </body>
    <?php include 'template/footerAdministration.php' ?>