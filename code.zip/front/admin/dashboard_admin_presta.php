<html>

<head>
  <title>Dashboard admin </title>
</head>

<body>
  <div id="app"></div>
  <h3> prestataires en attente de validation </h3>
  <div id="liste-prestataires"></div>
  <button id="envoyer">Envoyer</button>

  <script>
    sessionStorage.setItem('is_admin', '1');
    <?php require_once __DIR__ . '/js/liste_prestataire_not_validated.js'; ?>
    const isAdmin = sessionStorage.getItem('is_admin');

    if (isAdmin === '1') {
      console.log("L'utilisateur est un administrateur.");
    } else {
      <?php echo (header('Location: ../index.php')); ?>
    }

    liste_prestataire()
      .then(data => {
        const listePrestatairesDiv = document.getElementById('liste-prestataires');
        data.forEach(prestataire => {
          const prestataireDiv = document.createElement('div');
          prestataireDiv.innerHTML = `
          <p>ID: ${prestataire.id}</p>
          <p>Nom: ${prestataire.lastname}</p>
          <p>Prénom: ${prestataire.firstname}</p>
          <p>Email: ${prestataire.email}</p>
          <p>Téléphone: ${prestataire.phone}</p>
          <input type="checkbox" id="valider_${prestataire.id}" name="valider_${prestataire.id}" value="${prestataire.id}">
          <label for="valider_${prestataire.id}">Valider</label>
          <hr>
        `;
          listePrestatairesDiv.appendChild(prestataireDiv);
        });
      })
      .catch(error => {
        console.error('Erreur lors de la récupération des prestataires :', error);
      });

    // Fonction pour gérer l'envoi des données vers localhost:3000/validated_presta
    document.getElementById('envoyer').addEventListener('click', function() {
      const prestatairesValides = [];
      document.querySelectorAll('input[type="checkbox"]:checked').forEach(checkbox => {
        prestatairesValides.push(checkbox.value);
      });
      const ids = prestatairesValides.join(',');
      // Envoyer les IDs des prestataires validés vers localhost:3000/validated_presta
      fetch('https://ela-dev.fr:3000/validated_presta', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            ids: ids
          })
        })
        .then(response => {
          if (!response.ok) {
            throw new Error('Erreur lors de la validation des prestataires.');
          }
          window.location.reload();
          alert('Opération effectuée !');
        })
        .catch(error => {
          console.error('Erreur lors de la validation des prestataires :', error);
        });
    });
  </script>
</body>

</html>