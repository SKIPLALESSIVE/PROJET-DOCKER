<?php include 'template/headerAdministration.php'; ?>
<title>PCS - Voyageurs - Administration</title>
</head>

<body id="page-top">

    <!-- Navigation-->
    <?php include 'template/navbarAdministrationLevel.php'; ?>
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-12 text-center">
                    <div id="prestataires-container">
                        <section>
                            <h2 class="text-uppercase mb-4">Liste des Voyageurs</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <thead>
                                            <tr>
                                                <th scope="col">ID</th>
                                                <th scope="col">VIP ?</th>
                                                <th scope="col">Rôle</th>
                                                <th scope="col">Nom</th>
                                                <th scope="col">Prénom</th>
                                                <th scope="col">Adresse</th>
                                                <th scope="col">Téléphone</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                    <tbody id="liste_voyageur_body"></tbody>
                                </table>

                                <script>
                                    var role = "voyageur";

                                    fetch("https://ela-dev.fr:3000/all_voyageurs", {
                                        method: 'POST'
                                    })
                                        .then(response => response.json())
                                        .then(data => {
                                            console.log('Résultats de la requête:', data);
                                            const listeVoyageurBody = document.getElementById("liste_voyageur_body");
                                            data.forEach(result => {
                                                const user = result.user;
                                                const voyageur = result.voyageur;
                                                const voyageurRow = document.createElement("tr");
                                                voyageurRow.innerHTML = `
                    <td>${user.id}</td>
                    <td>${voyageur.is_vip}</td>
                    <td>${role}</td>
                    <td>${user.lastname}</td>
                    <td>${user.firstname}</td>
                    <td>${user.address}</td>
                    <td>${user.phone}</td>
                    <td>${user.email}</td>
                    <td>
                                                <form action="https://ela-dev.fr:3000/delete_voyageur" method="post" onsubmit="return submitForm(this);">
                                                    <input type="hidden" name="id" value="${user.id}">
                                                    <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                                </form>
                                            </td>
                `;
                                                listeVoyageurBody.appendChild(voyageurRow);
                                            });
                                        })
                                        .catch(error => console.error("Erreur lors du chargement des voyageurs:", error));

                                    function supprimerVoyageur(idVoyageur) {
                                        fetch("https://ela-dev.fr:3000/delete_voyageur", {
                                            method: 'POST',
                                            headers: {
                                                'Content-Type': 'application/json'
                                            },
                                            body: JSON.stringify({
                                                id: idVoyageur
                                            })
                                        })
                                            .then(() => location.reload());
                                        console.log("Suppression du voyageur avec l'ID:", idVoyageur);
                                    }
                                </script>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
    </section>

</body>

</html>
<?php include 'template/footerAdministration.php' ?>