<?php include 'template/headerAdministration.php'; ?>
<title>PCS - ValidateAdministration</title>

</head>

<body id="page-top">

    <!-- Navigation-->
    <?php include 'template/navbarAdministrationLevel.php'; ?>
    <!-- Administration -->
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-12 text-center">
                    <div id="prestataires-container">
                        <section>
                            <h2 class="text-uppercase mb-4">Liste des validations des Prestataires</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col">Id</th>
                                            <th scope="col">Rôle</th>
                                            <th scope="col">Validé</th>
                                            <th scope="col">Nom</th>
                                            <th scope="col">Prénom</th>
                                            <th scope="col">Adresse</th>
                                            <th scope="col">Téléphone</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="liste-utilisateurs">
                                        <!-- Les utilisateurs seront ajoutés ici -->
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                    <div id="bien-container">
                        <section>
                            <h2 class="text-uppercase mb-4">Liste des validations des Biens</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col">Id</th>
                                            <th scope="col">Adresse</th>
                                            <th scope="col">Type de bien</th>
                                            <th scope="col">Nombre de chambres</th>
                                            <th scope="col">Nombre d'occupants</th>
                                            <th scope="col">Prix</th>
                                            <th scope="col">Date d'abonnement</th>
                                            <th scope="col">Abonnement payé</th>
                                            <th scope="col">Validé</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="liste-biens">
                                        <!-- Les biens seront ajoutés ici -->
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                    <script>
                        document.addEventListener("DOMContentLoaded", function() {
                            const prestataireUrl = 'https://ela-dev.fr:3000/show_prestataire_not_validated';
                            const bienUrl = 'https://ela-dev.fr:3000/show_bien_admin';

                            const options = {
                                headers: {
                                    'Authorization': `Bearer <?php echo ($_COOKIE['token']); ?>`
                                }
                            };

                            // Fetch pour les prestataires
                            fetch(prestataireUrl, options)
                                .then(response => response.json())
                                .then(users => {
                                    console.log('Résultats de la requête:', users);
                                    const userList = document.getElementById('liste-utilisateurs');
                                    users.forEach(result => {
                                        const user = result.user;
                                        const prestataire = result.prestataire;

                                        const row = document.createElement('tr');
                                        row.innerHTML = `
                                            <td>${user.id}</td>
                                            <td>${user.role}</td>
                                            <td>${prestataire.is_validated}</td>
                                            <td>${user.lastname}</td>
                                            <td>${user.firstname}</td>
                                            <td>${user.address}</td>
                                            <td>${user.phone}</td>
                                            <td>${user.email}</td>
                                            <td>
                                                <form action="https://ela-dev.fr:3000/validate_prestataire" method="POST" onsubmit="return submitForm(this)">
                                                    <input type="hidden" name="id" value="${user.id}">
                                                    <button type="submit" class="btn btn-primary">Valider</button>
                                                </form>
                                                <a href="../assets/presta_${user.id}/"><button class="btn btn-info">Consulter documents</button></a>
                                            </td>
                                        `;
                                        userList.appendChild(row);
                                    });
                                })
                                .catch(error => {
                                    console.error('Erreur lors de la récupération des utilisateurs:', error);
                                });

                            // Fetch pour les biens
                            fetch(bienUrl, options)
                                .then(response => response.json())
                                .then(biens => {
                                    console.log('Résultats de la requête:', biens);
                                    const bienList = document.getElementById('liste-biens');
                                    biens.forEach(bien => {
                                        const row = document.createElement('tr');
                                        row.innerHTML = `
                                            <td>${bien.id}</td>
                                            <td>${bien.address}</td>
                                            <td>${bien.bien_type}</td>
                                            <td>${bien.chambers_nb}</td>
                                            <td>${bien.occupants_nb}</td>
                                            <td>${bien.price}</td>
                                            <td>${new Date(bien.subscription_date).toLocaleDateString()}</td>
                                            <td>${bien.subscription_paid ? 'Oui' : 'Non'}</td>
                                            <td>${bien.is_validated ? 'Oui' : 'Non'}</td>
                                            <td>
                                                <form action="https://ela-dev.fr:3000/validate_bien" method="POST" onsubmit="return submitForm(this)">
                                                    <input type="hidden" name="id" value="${bien.id}">
                                                    <button type="submit" class="btn btn-primary">Valider</button>
                                                </form>
                                                <a href="../assets/bien_${bien.id}/"><button class="btn btn-info">Consulter les photos</button></a>
                                            </td>
                                        `;
                                        bienList.appendChild(row);
                                    });
                                })
                                .catch(error => {
                                    console.error('Erreur lors de la récupération des biens:', error);
                                });
                        });

                        function submitForm(form) {
                            const token = "<?php echo $_COOKIE['token']; ?>";
                            const id = form.querySelector('input[name="id"]').value;
                            const url = form.action;

                            fetch(url, {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Authorization': `Bearer ${token}`
                                    },
                                    body: JSON.stringify({
                                        id: id
                                    })
                                })
                                .then(response => {
                                    if (!response.ok) {
                                        throw new Error('Erreur lors de la requête');
                                    }
                                    window.location.reload();
                                })
                                .then(data => {
                                    console.log(data.message);
                                })
                                .catch(error => {
                                    console.error('Erreur:', error);
                                });

                            return false;
                        }
                    </script>
                </div>
            </div>
        </div>
    </section>
    <script>
        function responsiveNavBar() {
            document.getElementById("navbarResponsive").classList.toggle("show");
        }
    </script>
    <!-- Footer-->
    <?php include 'template/footerAdministration.php' ?>
