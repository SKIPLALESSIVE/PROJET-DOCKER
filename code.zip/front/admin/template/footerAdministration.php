<center>

       <footer class="bg-light py-5 lunarWhiteBg">
              <div class="container px-4 px-lg-5">
                     <div class="small text-center text-muted">Copyright &copy; <?php echo date("Y"); ?> - TeamCar</div>
              </div>

</center>