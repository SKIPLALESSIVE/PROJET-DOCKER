<!DOCTYPE html>
<html>

<head>
    <title>Affichage des types de prestation</title>
</head>

<body>

    <div id="typesPrestation"></div>
    <input type="date" id="datePrestation">
    <button onclick="envoyerPrestataires()">Voir les prestataires et les envoyer</button>
    <div id="prestatairesDisponibles"></div>

    <form id="reservationForm" action="resa_presta.php" method="POST" style="display: none;">
        <input type="hidden" id="userId" name="userId">
        <input type="hidden" id="prestataireId" name="prestataireId">
        <input type="hidden" id="prix" name="prix">
        <input type="hidden" id="typePrestation" name="typePrestation">
        <input type="hidden" id="datePrestation2" name="datePrestation2">
    </form>

    <script src="js/recup_token.js"></script>
    <script src="js/show_type_prestation.js"></script>
    <script>
        var prestatairesInfo = [];
        var datePrestation;

        function extractPrestatairesInfo(allId) {
            var prestataires = allId.split(".");
            prestataires.forEach(function(prestataireInfo) {

                var info = prestataireInfo.split(":");
                var idPrestataire = parseInt(info[0]);
                var prix = parseFloat(info[1]);
                prestatairesInfo.push({
                    id: idPrestataire,
                    prix: prix
                });
            });
        }

        async function afficherTypesPrestation() {
            try {
                var recup_all_type = await show_all_prestation();
                var data = recup_all_type;
                var typesPrestationDiv = document.getElementById("typesPrestation");
                data.forEach(function(item) {
                    var p = document.createElement("p");
                    p.textContent = item.type_prestation;

                    var checkbox = document.createElement("input");
                    checkbox.type = "checkbox";
                    checkbox.classList.add("prestation-checkbox"); // Ajout d'une classe pour les cases à cocher

                    typesPrestationDiv.appendChild(p);
                    typesPrestationDiv.appendChild(checkbox);
                    extractPrestatairesInfo(item.all_id);
                });
            } catch (error) {
                console.error('Une erreur est survenue :', error);
            }
        }

        function envoyerPrestataires() {
            var datePrestation = document.getElementById("datePrestation").value;
            console.log("Date sélectionnée :", datePrestation);

            var checkboxes = document.querySelectorAll('.prestation-checkbox:checked');
            var nomsPrestationsSelectionnees = [];

            checkboxes.forEach(function(checkbox) {
                var nomPrestation = checkbox.previousElementSibling.textContent;
                nomsPrestationsSelectionnees.push(nomPrestation);
            });

            console.log("Noms des prestations sélectionnées :", nomsPrestationsSelectionnees);

            // Préparer les données à envoyer
            var data = {
                datePrestation: datePrestation,
                prestationSelectionnee: nomsPrestationsSelectionnees[0] // Sélectionner uniquement la première prestation
            };

            // Effectuer la requête Fetch
            fetch('https://ela-dev.fr:3000/afficher_presta_dates', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            }).then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error('Erreur lors de la requête Fetch');
                }
            }).then(jsonData => {
                console.log(jsonData);

                var prestatairesDisponibles = [];
                jsonData.disponibilities.forEach(function(disponibilite) {
                    if (disponibilite.disponiblity === datePrestation) {
                        prestatairesDisponibles.push(disponibilite.id_prestataire);
                    }
                });

                console.log("Prestataires disponibles pour la date sélectionnée :", prestatairesDisponibles);

                var prestatairesDiv = document.getElementById("prestatairesDisponibles");
                console.log("Informations des prestataires disponibles :", prestatairesInfo);
                prestatairesDisponibles.forEach(function(id) {
                    var prestataire = prestatairesInfo.find(prestataire => prestataire.id === id);
                    if (prestataire) {
                        var prix = prestataire.prix;
                        var p = document.createElement("p");
                        p.textContent = 'Ce prestataire est disponible : ' + id + ' au prix de ' + prix + ' € ';
                        var boutonReserver = document.createElement("button");
                        boutonReserver.textContent = "Réserver";
                        prestatairesDiv.appendChild(p);
                        prestatairesDiv.appendChild(boutonReserver);
                        boutonReserver.addEventListener("click", function() {
                            document.getElementById('userId').value = sessionStorage.getItem('userId');
                            document.getElementById('prestataireId').value = id;
                            document.getElementById('prix').value = prix;
                            document.getElementById('typePrestation').value = nomsPrestationsSelectionnees[0];
                            document.getElementById('datePrestation2').value = datePrestation;

                            // Soumettre automatiquement le formulaire
                            document.getElementById('reservationForm').submit();
                        });
                    } else {
                        console.error("Prestataire avec l'ID " + id + " non trouvé dans prestatairesInfo");
                    }
                });
            }).catch(error => {
                console.error('Erreur lors de la requête Fetch :', error);
            });
        }

        afficherTypesPrestation();
    </script>

</body>

</html>