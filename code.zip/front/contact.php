<?php include __DIR__ . '/template/header.php';  ?>
<title>Paris Care Taker - Contact</title>
</head>

<body id="page-top">
    <!-- Navigation-->
    <?php include 'template/nav.php' ?>

    <!-- Contact-->
    <section class="page-section duckBlueBg" id="contact">
        <div class="container">
            <h2 class="text-white font-weight-bold text-center">Vous avez un problème ?</h2>
            <hr class="divider duckBlueDarkBg" />
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="mt-3 mx-auto">
                        <select id="selectInterface" class="form-select" aria-label="Default select example">
                            <option selected>Choisissez une interface</option>
                            <option value="Prestataires">Prestataires</option>
                            <option value="Bailleurs">Bailleurs</option>
                            <option value="Voyageurs">Voyageurs</option>
                        </select>
                    </div>
                    <div id="secondSelectContainer" class="mt-3"></div>
                    <div id="answerContainer" class="mt-3 lunarWhiteText"></div> <!-- Container pour afficher la réponse -->
                </div>
            </div>
        </div>
    </section>

    <script>
        // Sélection du premier menu déroulant
        var selectInterface = document.getElementById('selectInterface');

        // Écoute de l'événement de changement du premier menu déroulant
        selectInterface.addEventListener('change', function() {
            var selectedValue = selectInterface.value;
            var secondSelectContainer = document.getElementById('secondSelectContainer');

            // Effacer le contenu du deuxième menu déroulant
            secondSelectContainer.innerHTML = '';

            // Si la catégorie "Prestataires" est sélectionnée, afficher les questions pour les prestataires
            if (selectedValue === 'Prestataires') {
                var questionsPrestataires = [
                    "Comment puis-je m'inscrire ?",
                    "Quel est le temps de validation de mon compte ?",
                    "Mon compte a été suspendu, que faire ?",
                    "Comment puis-je modifier mes informations personnelles ?",
                    "Comment puis-je ajouter un service ?",
                    "Comment puis-je supprimer un service ?",
                    "Autre question..."
                ];
                createSecondSelect(questionsPrestataires);
            }
            // Si la catégorie "Bailleurs" est sélectionnée, afficher les questions pour les bailleurs
            else if (selectedValue === 'Bailleurs') {
                var questionsBailleurs = [
                    "Comment puis-je m'inscrire ?",
                    "Quel est le temps de validation de mon compte ?",
                    "Mon compte a été suspendu, que faire ?",
                    "Comment puis-je modifier mes informations personnelles ?",
                    "Comment puis-je ajouter un bien immobilier ?",
                    "Comment puis-je supprimer un bien immobilier ?",
                    "Autre question..."
                ];
                createSecondSelect(questionsBailleurs);
            }
            // Si la catégorie "Voyageurs" est sélectionnée, afficher les questions pour les voyageurs
            else if (selectedValue === 'Voyageurs') {
                var questionsVoyageurs = [
                    "Comment puis-je m'inscrire ?",
                    "Quel est le temps de validation de mon compte ?",
                    "Mon compte a été suspendu, que faire ?",
                    "Comment puis-je modifier mes informations personnelles ?",
                    "Comment puis-je réserver un bien immobilier ?",
                    "Comment puis-je annuler une réservation ?",
                    "Comment puis-je laisser un avis ?",
                    "Comment accéder à mes factures ?",
                    "Autre question..."
                ];
                createSecondSelect(questionsVoyageurs);
            }
        });

        // Fonction pour créer le deuxième menu déroulant avec les questions appropriées
        function createSecondSelect(questions) {
            var secondSelectContainer = document.getElementById('secondSelectContainer');
            var answerContainer = document.getElementById('answerContainer'); // Ajout de la référence à l'élément de réponse
            var secondSelect = document.createElement('select');
            secondSelect.className = 'form-select mt-3';
            secondSelect.setAttribute('aria-label', 'Default select example');

            // Ajouter une option par défaut
            var defaultOption = document.createElement('option');
            defaultOption.textContent = 'Choisissez une question';
            defaultOption.disabled = true;
            defaultOption.selected = true;
            secondSelect.appendChild(defaultOption);

            // Ajouter les options au deuxième menu déroulant
            questions.forEach(function(question, index) {
                var option = document.createElement('option');
                option.value = index; // ajuster l'index ici
                option.textContent = question;
                secondSelect.appendChild(option);
            });

            // Événement de changement pour le deuxième menu déroulant
            secondSelect.addEventListener('change', function() {
                var selectedIndex = secondSelect.selectedIndex;
                var selectedQuestion = questions[selectedIndex - 1];
                var answerText = getAnswer(selectedQuestion);

                var category = document.getElementById('selectInterface').value;

                // Afficher la réponse
                if (answerText.includes("contacter notre service client")) {
                    // Afficher le formulaire de contact
                    answerContainer.innerHTML = `
            <p>${answerText}</p>
            <form id="contactForm" action="https://ela-dev.fr:3000/add_ticket" method="POST">
                <input type="hidden" name="title" value="${selectedQuestion}">
                <div class="mb-3">
                    <label for="email" class="form-label">Adresse e-mail</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="content" class="form-label">Contenu</label>
                    <textarea class="form-control" id="content" name="content" rows="3" required></textarea>
                </div>
                <input type="hidden" name="category" value="${category}">
                <button type="submit" class="btn btn-primary">Envoyer</button>
            </form>
        `;
                } else {
                    // Afficher la réponse normale
                    answerContainer.textContent = answerText;
                }
            });

            // Ajouter le deuxième menu déroulant au conteneur
            secondSelectContainer.appendChild(secondSelect);
        }


        // Fonction pour obtenir la réponse correspondant à la question sélectionnée
        function getAnswer(question) {
            // Utilisez une structure de contrôle pour déterminer la réponse en fonction de la question
            switch (question) {
                case "Comment puis-je m'inscrire ?":
                    return "Pour vous inscrire, veuillez cliquer sur le bouton 'Login' en haut à droite de la page puis sur 'Rejoignez-nous'.";
                case "Quel est le temps de validation de mon compte ?":
                    return "Le temps de validation de votre compte est de maximum 24 heures.";
                case "Mon compte a été suspendu, que faire ?":
                    return "Si votre compte a été suspendu, veuillez contacter notre service client.";
                case "Comment puis-je modifier mes informations personnelles ?":
                    return "Pour modifier vos informations personnelles, veuillez vous connecter à votre compte et accéder à la section 'Mon profil'.";
                case "Comment puis-je ajouter un service ?":
                    return "Pour ajouter un service, veuillez vous connecter à votre compte et accéder à la section 'Mes services'.";
                case "Comment puis-je supprimer un service ?":
                    return "Pour supprimer un service, veuillez vous connecter à votre compte et accéder à la section 'Mes services'.";
                case "Comment puis-je ajouter un bien immobilier ?":
                    return "Pour ajouter un bien immobilier, veuillez vous connecter à votre compte et accéder à la section 'Mes biens immobiliers'.";
                case "Comment puis-je supprimer un bien immobilier ?":
                    return "Pour supprimer un bien immobilier, veuillez vous connecter à votre compte et accéder à la section 'Mes biens immobiliers'.";
                case "Comment puis-je réserver un bien immobilier ?":
                    return "Pour réserver un bien immobilier, veuillez vous connecter à votre compte, rechercher un bien et cliquer sur le bouton 'Réserver'.";
                case "Comment puis-je annuler une réservation ?":
                    return "Pour annuler une réservation, veuillez vous connecter à votre compte, accéder à la section 'Mes réservations' et cliquer sur le bouton 'Annuler'.";
                case "Comment puis-je laisser un avis ?":
                    return "Pour laisser un avis, veuillez vous connecter à votre compte, accéder à la section 'Mes réservations' et cliquer sur le bouton 'Laisser un avis'.";
                case "Comment accéder à mes factures ?":
                    return "Pour accéder à vos factures, veuillez vous connecter à votre compte et accéder à la section 'Mes factures'.";
                case "Autre question...":
                    return "Veuillez contacter notre service client pour toute autre question.";
                default:
                    return "Réponse par défaut pour cette question.";
            }
        }
    </script>

    <!-- Footer-->
    <?php include 'template/footer.php' ?>