<?php include __DIR__ . '/template/header.php'; ?>

<title>Paris CareTaker Service - Pwd Reset</title>
</head>

<body>
    <?php include 'template/nav.php'; ?>

    <!-- Connexion -->
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="lunarWhiteText mt-0">Mot de passe oublié</h2>
                    <hr class="divider duckBlueDarkBg" />
                    <form action="https://ela-dev.fr:3000/reset_password" method="post" id="formulairePassword" class="needs-validation" novalidate>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="email" type="email" id="email" placeholder="name@example.com" required="required" />
                            <label for="email">Votre Email</label>
                        </div>
                        <hr class="divider duckBlueDarkBg" />
                        <button class="btn btn-light btn-xl duckBlueDarkBg textLunarWhite" type="submit">Valider</button>
                    </form>
                    <hr class="divider duckBlueDarkBg">
                </div>
            </div>
        </div>
    </section>

    <?php include __DIR__ . '/template/footer.php'; ?>
</body>