<?php require __DIR__ . '/../template/startSession.php';
include '../template/header.php'; ?>
<title>PCS - Bailleur - Demande de Prestation</title>
</head>
<script> var userId = "<?php echo $_POST['userId'] ?>"; </script>

<?php if (isset($_GET["error"]) && !empty($_GET["error"])) { ?>
    <hr class="divider duckBlueDarkBg" />
    <div class="alert alert-danger" role="alert">
        <?php echo $_GET["error"]; ?>
    </div>
<?php } ?>

<body id="page-top">
    <script> var userId = sessionStorage.getItem('userId'); </script>
    <?php
    include '../template/nav.php'; ?>
    <section class="page-section duckBlueBg " id="navigation">
        <div class="container px-6 px-lg-6">
            <div class="row gx-6 gx-lg-6 justify-content-center">
                <div class="col-lg-10 col-xl-8 text-center ">
                    <div class="mt-0 textLunarWhite">
                        <h2 class="mt-0 lunarWhiteText">Demande de Prestation</h2>
                        <hr class="divider" />
                        <form action="https://ela-dev.fr:3000/ask_presta" method="post" id="askpresta"
                            class="needs-validation" novalidate>
                            <div class="form-floating mb-3">
                                <textarea name="asking" id="asking" class="form-control" rows="5" placeholder="ICI"
                                    required="required"></textarea>
                                <label for="asking">Décrivez votre demande, la conciergerie vous contactera au plus
                                    vite</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="hidden" name="userId" id="userId" />
                                <input type="hidden" name="interface" id="interface" value="bailleur" />
                            </div>

                            <hr class="divider duckBlueDarkBg" />
                            <button class="btn btn-light btn-xl duckBlueDarkBg textLunarWhite" type="submit">Envoyer
                            </button>
                        </form>
                    </div>
                </div>
            </div>
    </section>


    <script>
        document.getElementById('userId').value = userId;
    </script>
</body>
<?php include '../template/footer.php' ?>
