<?php include('../template/headerLevel2.php'); ?>
<title>Dashboard</title>
</head>
<?php

include __DIR__ . '/../template/navLevel2.php';
include __DIR__ . '/../template/startSession.php';
if (!isset($_GET['token'])) {
  if(isset($_COOKIE['token'])){
      $token = $_COOKIE['token'];
  }else{
      header('Location: ../login.php');
      exit;
  }
} else {
  $token = $_GET['token'];
}
$_SESSION['interface'] = 'bailleur';

setcookie('token', $token, time() + 3600, '/', null, false, true);

?>
<script>
  var userId;
  var token = "<?php echo $token ?>";
</script>

<body id="page-top">
  <section class="page-section duckBlueBg">
    <div class="container px-4 px-lg-5">
      <div class="row gx-4 gx-lg-5 justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="lunarWhiteText mt-0">Dashboard bailleur</h2>
          <hr class="divider duckBlueDarkBg" />
          <a href="addBien.php"><button class="btn btn-primary">Ajouter un bien</button></a>
          <a href="SeeBiens.php"><button class="btn btn-primary">Voir un résumé de mes biens et les supprimer</button></a>
          <a href="ask_presta.php"><button class="btn btn-primary">Demander une prestation</button></a>
          <a href="AskFacture.php"><button class="btn btn-primary">Demander un récapitulatif de ma balance </button></a>
          <hr class="divider duckBlueDarkBg" />
        </div>
      </div>
    </div>
  </section>
  <script>
    async function recup_token(token) {
      const headers = new Headers({
        "Authorization": `Bearer ${token}`
      });

      try {
        const response = await fetch("https://ela-dev.fr:3000/recup_token_bailleur", {
          headers: headers
        });


        if (!response.ok) {
          throw new Error(`API request failed with status ${response.status}`);
        }

        const data = await response.json();
        return data;
      } catch (error) {
        console.error("Error:", error);

        alert("Error retrieving user information!");
        throw error;
      }
    }
    recup_token(token)
      .then(UserInfo => {
        userId = UserInfo.id;
        sessionStorage.setItem('userId', userId);

      })
      .catch(error => {
        console.error("Error:", error);
      });
  </script>
  <?php include('../template/footerLevel2.php'); ?>