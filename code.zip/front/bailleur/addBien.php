<?php include('../template/headerLevel2.php'); ?>

<?php session_start(); ?> 
<script>
var userId = sessionStorage.getItem('userId');
</script>
<?php   
if (isset($_GET['message'])) {
    $message = $_GET['message'];
    echo "<script>window.alert(\"$message\");</script>";
}
?>

<title>Paris CareTaker Service - Ajout de bien </title>
</head>

<body>
<?php include '../template/nav.php'; ?>
    <section class="page-section duckBlueBg lunarWhiteText">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class=" mt-0">Ajout de Bien</h2>
                    <?php if (isset($_GET["error"]) && !empty($_GET["error"])) { ?>
                        <hr class="divider duckBlueDarkBg" />
                        <div class="alert alert-danger" role="alert">
                            <?php echo $_GET["error"]; ?>
                        </div>
                    <?php } ?>
                    <hr class="divider duckBlueDarkBg" />
                    <form action="https://ela-dev.fr:3000/add_bien" method="post">
                        <input type="hidden" name="userId" id="userId" class="btn btn-primary btn-xl">
                            <div class="form-group">
                                <label for="exampleFormControlInput1">Quel type de conciergerie souhaitez vous ?</label>
                                <br>
                                <input type="radio" id="gestion" name="type_gestion" value="gestion">
                                <label for="gestion">Gestion de A à Z</label>
                                <br>
                                <input type="radio" id="gestion" name="type_gestion" value="yeld">
                                <label for="yeld">Yeld Management</label>
                                <br>
                                <input type="radio" id="gestion" name="type_gestion" value="other" onclick="makeOtherTextInputAppear()">
                                <label for="other">Autre</label>
                                <input type="text" class="form-control" id="otherText" placeholder="[...]" name="otherText" style="display: none">
                                <hr class="divider" />
                            </div>
                            <div class="form-group">
                                <label for="addresse">Adresse de votre propriété en location courte durée</label>
                                <input type="text" class="form-control" id="adresse" placeholder="Adresse" name="adresse">
                                <hr class="divider " />
                            </div>
                            <div class="form-group">
                                <label for="pays">Pays de votre propriété en location courte durée</label>
                                <select class="form-select" id="pays" name="pays">
                                <hr class="divider " />
                                    <?php
                                    $pays = file_get_contents('../assets/pays/countries-FR.json');
                                    $pays = json_decode($pays, true);
                                    foreach ($pays as $key => $value) {
                                        echo '<option value="' . $key . '">' . $value . '</option>';
                                        if ($key == "FR") {
                                            echo '<option value="FR" selected>France</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <hr class="divider" />
                            <div class="form-group">
                                <div class="row">
                                    <div class="col">
                                        <label for="type">Type de bien</label>
                                        <select class="form-select" id="type" name="type">
                                            <option value="appartement">Appartement</option>
                                            <option value="maison">Maison</option>
                                            <option value="studio">Studio</option>
                                            <option value="loft">Loft</option>
                                            <option value="duplex">Duplex</option>
                                            <option value="penthouse">Penthouse</option>
                                            <option value="villa">Villa</option>
                                            <option value="chateau">Château</option>
                                            <option value="autre">Autre</option>
                                            
                                        </select>
                                    </div>
                                    <div class="col">
                                        <label for="location">Type de location</label>
                                        <select class="form-select" id="location" name="location">
                                            <option value="entier">Logement entier</option>
                                            <option value="partage">Logement partagé</option>
                                            <option value="chambre">Chambre privée</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <br>
                            <hr class="divider " />
                                <label for="chambres">Nombre de chambres</label>
                                <select class="form-select" id="chambres" name="chambres">
                                    <option value="1">1 chambre</option>
                                    <option value="2">2 chambres</option>
                                    <option value="3">3 chambres</option>
                                    <option value="4">4 chambres</option>
                                    <option value="5">5 chambres</option>
                                    <option value="6">6 chambres</option>
                                    <option value="7">7 chambres</option>
                                    <option value="8">8 chambres</option>
                                    <option value="9">9 chambres</option>
                                    <option value="10">10 chambres</option>
                                </select>
                                
                            </div>
                            <input type="text" class="form-control" id="prix" placeholder="Prix par nuit" name="prix">
                            <div class="form-group">
                                <label for="capacite">Quelle est la capacité d'accueil de votre logement ?</label>
                                <select class="form-select" id="capacite" name="capacite">
                                    <option value="1">1 personne</option>
                                    <option value="2">2 personnes</option>
                                    <option value="3">3 personnes</option>
                                    <option value="4">4 personnes</option>
                                    <option value="5">5 personnes</option>
                                    <option value="6">6 personnes</option>
                                    <option value="7">7 personnes</option>
                                    <option value="8">8 personnes</option>
                                    <option value="9">9 personnes</option>
                                    <option value="10">10 personnes</option>
                                    
                                </select>
                                <hr class="divider " />
                                <button type="submit" class="btn btn-primary btn-xl">Ajouter le bien</button>
                                </form>
                            </div>
   
                            <script>
        document.addEventListener("DOMContentLoaded", function() {
            var userId = sessionStorage.getItem('userId');
            document.getElementById('userId').value = userId;
        });

        function makeOtherTextInputAppear() {
           
            var otherRadioButton = document.getElementById('other');
            var otherTextInput = document.getElementById('otherText');
            if (otherRadioButton.checked) {
                otherTextInput.style.display = 'block';
            } else {
                otherTextInput.style.display = 'none';
            }
        }
    </script>

</body>