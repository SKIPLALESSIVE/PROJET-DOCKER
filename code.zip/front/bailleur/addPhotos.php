<?php 
$bienId = $_POST['id']; 
?>


<?php include '../template/navLevel2.php'; ?>
    <div class="text-center lunarWhiteText">
        <div class="page-section duckBlueBg">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-8 col-xl-6 text-center">
                        <h2>Formulaire de téléchargement des photos pour votre bien </h2>
                        <h3> Attention seuls les images au format JPEG, JPG et PNG sont acceptées. </h3>
                        <h4> (un message de succès ne veut pas dire que l'envoi a réussi si votre fichier ne remplit pas cette condition) </h4>
                        <hr class="divider" />
                        <form id="form1" enctype="multipart/form-data">
                            <label for="file1">Sélectionnez un fichier :</label><br>
                            <input type="file" id="file1" name="file1" class="btn" required><br><br>
                            <input type="hidden" name="fileType" value="photo1" class="btn">
                            <button type="button" onclick="uploadFile('form1')" class="btn btn-primary">Télécharger</button>
                            <hr class="divider" />
                        </form>

                        <h2>Formulaire de téléchargement de votre deuxième photo </h2>
                        <hr class="divider" />
                        <form id="form2" enctype="multipart/form-data">
                            <label for="file2">Sélectionnez un fichier :</label><br>
                            <input type="file" id="file2" name="file2" class="btn" required><br><br>
                            <input type="hidden" name="fileType" value="photo2">
                            <button type="button" onclick="uploadFile('form2')" class="btn btn-primary">Télécharger</button>
                            <hr class="divider" />
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function uploadFile(formId) {
            try {
                const form = document.getElementById(formId);
                const formData = new FormData(form);
                const bienId = <?php echo $bienId; ?>;
                console.log('ID récupéré :', bienId);

                formData.append('bienId', bienId);

                const response = await fetch('TRT_addPhotos.php', {
                    method: 'POST',
                    body: formData
                });

                if (!response.ok) {
                    throw new Error('Erreur lors du téléchargement du fichier.');
                }

                const data = await response.json();
                alert('Le fichier a été téléchargé avec succès.');
                form.reset();
            } catch (error) {
            }
        }

        </script>