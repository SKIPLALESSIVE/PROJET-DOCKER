<?php $id = $_GET['ids']; ?>

<script>
var id = <?php echo $id; ?>;
console.log(id); 

fetch("https://ela-dev.fr:3000/validated_payements", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ id: id, type: 'subscription' })
})
.then(response => {
  if (response.ok) {
    window.location.href = `dashboard_bailleur.php`;
  } else {
    // Gestion des erreurs
    alert('Une erreur est survenue lors de la validation du paiement. Veuillez réessayer.');
  }
})
.catch(error => {
  // Affichage d'un message d'erreur plus précis
  alert(`Une erreur réseau est survenue : ${error.message}`);
});
</script>

<h2>Votre Paiement a bien été reçu !, Vous pouvez dès à présent retourner sur votre dashboard !</h2>
<form action="https://ela-dev.fr:3000/validated_prestation" method="post">
  <input type="hidden" value="<?php echo $id; ?>" name="id">
</form>
<button type="submit">Retourner sur le dashboard</button>