<?php session_start(); ?>
<title>PCS - Voir ses biens </title>
<?php include '../template/header.php'; ?>
<title>Voir tous les biens et les supprimer</title>
<link rel="stylesheet" href="../css/styles.css">
</head>

<body id="page-top">
    <?php include '../template/nav.php'; ?>
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-12 text-center">
                    <div id="prestataires-container">
                        <section>
                            <h2 class="text-uppercase mb-4">Liste des biens</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col">Id</th>
                                            <th scope="col">Validé</th>
                                            <th scope="col">Abonnement payé ? </th>
                                            <th scope="col">Pays</th>
                                            <th scope="col">Type de bien</th>
                                            <th scope="col">Type de location</th>
                                            <th scope="col">Adresse</th>
                                            <th scope="col">Nombre de chambres</th>
                                            <th scope="col">Capacité d'accueil</th>
                                            <th scope="col">Prix</th>
                                            <th scope="col">Id Documents</th>
                                            <th scope="col">Note</th>
                                            <th scope="col">Actions</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody id="liste-biens">

                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>

                    <script>
                        document.addEventListener("DOMContentLoaded", function () {
                            const url = 'https://ela-dev.fr:3000/show_bien_bailleur';
                            const userId = sessionStorage.getItem('userId');

                            fetch(url, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                                body: JSON.stringify({ id: userId })
                            })
                                .then(response => response.json())
                                .then(data => {
                                    console.log(data);
                                    const listeBiens = document.getElementById('liste-biens');

                                    data.forEach(entry => {
                                        const bien = entry.bien;
                                        const moyenne = entry.moyenne;

                                        const row = document.createElement('tr');
                                        row.innerHTML = `
                <td>${bien.id}</td>
                <td>${bien.is_validated}</td>
                <td>${bien.subscription_paid}</td>
                <td>${bien.land}</td>
                <td>${bien.bien_type}</td>
                <td>${bien.location_type}</td>
                <td>${bien.address}</td>
                <td>${bien.chambers_nb}</td>
                <td>${bien.occupants_nb}</td>
                <td>${bien.price}</td>
                <td>${bien.id_docs}</td>
                <td>${moyenne !== 0 ? moyenne : "pas encore de note"}</td>
                <td>
                    <form action="https://ela-dev.fr:3000/delete_bien" method="post" onsubmit="return submitForm(this);">
                        <input type="hidden" name="id" value="${bien.id}">
                        <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                    </form>
                    <form action="addPhotos.php" method="post">
                        <input type="hidden" name="id" value="${bien.id}">
                        <button type="submit" class="btn btn-primary btn-sm">Ajouter une photo</button>
                    </form>
                    
                    <form action="payBailleur.php" method="post">
                        <input type="hidden" name="id" value="${bien.id}">
                        <button type="submit" class="btn btn-primary btn-sm">Payer la subscription</button>
                    </form>
                </td>
            `;
                                        listeBiens.appendChild(row);
                                    });
                                })
                                .catch(error => {
                                    console.error('Erreur lors de la récupération des biens:', error);
                                });
                        });

                        function responsiveNavBar() {
                            document.getElementById("navbarResponsive").classList.toggle("show");
                        }
                    </script>
                </div>
            </div>
        </div>
    </section>
</body>
<?php include '../template/footer.php' ?>

</html>