<?php include __DIR__ . '/template/header.php'; ?>

<title>Paris CareTaker Service - Pwd Reset</title>
</head>

<body>
    <?php include 'template/nav.php'; ?>

    <!-- Connexion -->
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="lunarWhiteText mt-0">Mot de passe oublié</h2>
                    <hr class="divider duckBlueDarkBg" />
                    <form action="https://ela-dev.fr:3000/change_password" method="post" id="formulaireResetPwd" class="needs-validation" novalidate>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="code" type="number" id="code" placeholder="Code" required="required" />
                            <label for="code">Code</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input class="form-control" name="password" type="password" id="password" placeholder="Votre Mot De Passe" required="required" />
                            <label for="password">Votre Nouveau Mot De Passe</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input class="form-control" name="password2" type="password" id="password2" placeholder="Votre Mot De Passe" required="required" />
                            <label for="password2">Confirmer Votre Nouveau Mot De Passe</label>
                        </div>

                        <hr class="divider duckBlueDarkBg" />
                        <input type="hidden" id="donneesJson" name="donneesJson">
                        <button class="btn btn-light btn-xl duckBlueDarkBg textLunarWhite" type="submit">Valider</button>
                    </form>
                    <hr class="divider duckBlueDarkBg">
                </div>
            </div>
        </div>
    </section>

    <script>
        const formData = new FormData(document.getElementById('formulaireConnexion'));
        const data = {};
        for (const [cle, valeur] of formData.entries()) {
            data[cle] = valeur;
        }
        const donneesJson = JSON.stringify(data);
        document.getElementById('donneesJson').value = donneesJson;
    </script>
    <?php include __DIR__ . '/template/footer.php'; ?>
</body>