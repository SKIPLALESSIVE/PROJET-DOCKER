<?php include __DIR__ . '/template/header.php'; ?>

<?php
if (isset($_GET['message'])) {
    $message = $_GET['message'];
    echo "<script>window.alert(\"$message\");</script>";
}
?>

<title>Paris CareTaker Service - Prestataire Login</title>
</head>

<body>
    <?php include 'template/nav.php'; ?>

    <!-- Connexion -->
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="lunarWhiteText mt-0">Connexion</h2>
                    <?php if (isset($_GET["error"]) && !empty($_GET["error"])) { ?>
                        <hr class="divider duckBlueDarkBg" />
                        <div class="alert alert-danger" role="alert">
                            <?php echo $_GET["error"]; ?>
                        </div>
                    <?php } ?>
                    <hr class="divider duckBlueDarkBg" />
                    <form action="http://172.19.0.2:3000/login" method="post" id="formulaireConnexion" class="needs-validation" novalidate>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="email" type="email" id="email" placeholder="name@example.com" required="required" />
                            <label for="email">Login (Email)</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="password" type="password" id="password" placeholder="Votre Mot De Passe" required="required" />
                            <label for="password">Votre Mot De Passe</label>
                        </div>
                        <div>
                            <select class="form-select" name="interface" id="interface" required>
                                <option value="" disabled selected>Sélectionner une interface</option>
                                <option value="bailleur">Bailleur</option>
                                <option value="prestataire">Prestataire</option>
                                <option value="voyageur">Voyageur</option>
                            </select>
                        </div>
                        <hr class="divider duckBlueDarkBg" />
                        <input type="hidden" id="donneesJson" name="donneesJson">
                        <button class="btn btn-light btn-xl duckBlueDarkBg textLunarWhite" type="submit">Se connecter</button>
                    </form>
                    <hr class="divider duckBlueDarkBg">
                    <p class="lunarWhiteText mb-6">Vous ne faites pas encore parti de nos membre ? <a href="register.php">Rejoignez-nous !</a></p>
                    <hr class="divider duckBlueDarkBg">
                    <p class="lunarWhiteText mb-6">Vous avez oublié votre mot de passe ? Réinitialisez le<a href="passwordRecover.php"> ici</a></p>
                    <hr class="divider duckBlueDarkBg">
                </div>
            </div>
        </div>
    </section>


    <script>
        const formData = new FormData(document.getElementById('formulaireConnexion'));
        const data = {};
        for (const [cle, valeur] of formData.entries()) {
            data[cle] = valeur;
        }
        const donneesJson = JSON.stringify(data);
        document.getElementById('donneesJson').value = donneesJson;
    </script>
    <?php include __DIR__ . '/template/footer.php'; ?>
</body>
