function show_all_prestation() {
  return fetch("https://ela-dev.fr:3000/show_all_presta_type", {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Erreur lors de la récupération des données");
      }
      return response.json();
    })
    .then((data) => {
      console.log(data);
      return data;
    })
    .catch((error) => {
      console.error("Erreur :", error);
      throw error; // Renvoie l'erreur
    });
}
