async function afficherTypesPrestation() {
  try {
    var recup_all_type = await show_all_prestation();
    var data = recup_all_type;

    var typesPrestationDiv = document.getElementById("typesPrestation");
    data.forEach(function (item) {
      var p = document.createElement("p");
      p.textContent = item.type_prestation;

      var checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.classList.add("prestation-checkbox"); // Ajout d'une classe pour les cases à cocher

      typesPrestationDiv.appendChild(p);
      typesPrestationDiv.appendChild(checkbox);

      // Création d'un objet pour stocker les prix en fonction de l'ID du prestataire
      var prixParId = {};

      // Diviser la chaîne all_id avec le point-virgule pour obtenir chaque paire id/prix
      var prestataires = item.all_id.split(".");
      prestataires.forEach(function (prestataireInfo) {
        // Diviser chaque paire id/prix avec le double point pour obtenir l'identifiant et le prix
        var info = prestataireInfo.split(":");
        var idPrestataire = info[0];
        var prix = parseFloat(info[1]);

        // Vérifier si l'ID du prestataire est vide ou si le prix n'est pas un nombre valide
        if (idPrestataire !== "" && !isNaN(prix)) {
          // Si l'ID du prestataire n'existe pas encore dans prixParId, créer un nouveau tableau pour cet ID
          if (!prixParId[idPrestataire]) {
            prixParId[idPrestataire] = [];
          }
          // Ajouter le prix à la liste des prix pour cet ID
          prixParId[idPrestataire].push(prix);
        }
      });

      // Écouter les clics sur la case à cocher
      checkbox.addEventListener("change", function () {
        // Supprimer les informations des prestataires actuellement affichées
        var prestataireElements =
          typesPrestationDiv.querySelectorAll(".prestataire-info");
        prestataireElements.forEach(function (element) {
          element.remove();
        });

        // Si la case à cocher est cochée, afficher les informations des prestataires
        if (this.checked) {
          // Afficher les prix en fonction de l'ID du prestataire
          for (var id in prixParId) {
            if (prixParId.hasOwnProperty(id)) {
              var prixList = prixParId[id];
              prixList.forEach(function (prix) {
                var prestataireElement = document.createElement("p");
                prestataireElement.textContent =
                  "ID Prestataire: " + id + ", Prix: " + prix.toFixed(2) + " €";
                prestataireElement.classList.add("prestataire-info"); // Ajout d'une classe pour les informations des prestataires
                typesPrestationDiv.appendChild(prestataireElement);
              });
            }
          }
        }
      });
    });
  } catch (error) {
    console.error("Une erreur est survenue :", error);
  }
}
