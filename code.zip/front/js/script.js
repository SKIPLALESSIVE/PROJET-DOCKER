/*!
 * Start Bootstrap - Creative v7.0.7 (https://startbootstrap.com/theme/creative)
 * Copyright 2013-2023 Start Bootstrap
 * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-creative/blob/master/LICENSE)
 */
//
// Scripts
//

window.addEventListener("DOMContentLoaded", (event) => {
  // Navbar shrink function
  var navbarShrink = function () {
    const navbarCollapsible = document.body.querySelector("#mainNav");
    if (!navbarCollapsible) {
      return;
    }
    if (window.scrollY === 0) {
      navbarCollapsible.classList.remove("navbar-shrink");
    } else {
      navbarCollapsible.classList.add("navbar-shrink");
    }
  };

  // Shrink the navbar
  navbarShrink();

  // Shrink the navbar when page is scrolled
  document.addEventListener("scroll", navbarShrink);

  // Activate Bootstrap scrollspy on the main nav element
  const mainNav = document.body.querySelector("#mainNav");
  if (mainNav) {
    new bootstrap.ScrollSpy(document.body, {
      target: "#mainNav",
      rootMargin: "0px 0px -40%",
    });
  }

  // Collapse responsive navbar when toggler is visible
  const navbarToggler = document.body.querySelector(".navbar-toggler");
  const responsiveNavItems = [].slice.call(
    document.querySelectorAll("#navbarResponsive .nav-link")
  );
  responsiveNavItems.map(function (responsiveNavItem) {
    responsiveNavItem.addEventListener("click", () => {
      if (window.getComputedStyle(navbarToggler).display !== "none") {
        navbarToggler.click();
      }
    });
  });

  // Activate SimpleLightbox plugin for portfolio items
  new SimpleLightbox({
    elements: "#portfolio a.portfolio-box",
  });
});

function makeOtherTextInputAppear() {
  var input = document.getElementById("otherText");

  if (input.style.display === "block") {
    input.style.display = "none";
  } else {
    input.style.display = "block";
  }
}

function selectAll() {
  // Récupérer toutes les cases à cocher à l'intérieur du modal
  var checkboxes = document.querySelectorAll(
    '#exampleModal input[type="checkbox"]'
  );
  // Parcourir toutes les cases à cocher et les cocher
  checkboxes.forEach(function (checkbox) {
    checkbox.checked = true;
  });
}

// Tableau contenant les URL des images pour le fond
var images = [
  "url('assets/img/bg-masthead1.jpg')",
  "url('assets/img/bg-masthead2.jpg')",
];

// Variable pour suivre l'index de l'image actuelle
var currentIndex = 0;

// Fonction pour changer la source de l'image
function changeBackground() {
  var masthead = document.getElementById("masthead");
  var imageUrl = images[currentIndex];
  currentIndex = (currentIndex + 1) % images.length;
  masthead.style.background =
    "linear-gradient(to bottom, rgba(24, 83, 81, 0.5) 0%, rgba(24, 83, 81, 0.5) 100%), " +
    imageUrl;
  masthead.style.backgroundSize = "cover";
  masthead.style.backgroundPosition = "center";
}

setInterval(changeBackground, 5000);
