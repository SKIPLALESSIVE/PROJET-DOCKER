function recup_token(token) {
  const headers = new Headers({
    Authorization: "Bearer " + token,
  });
  return fetch("https://ela-dev.fr:3000/recup_token", { headers: headers })
    .then((response) => response.json())
    .then((data) => {
      const tableau = {
        id: data.id,
        email: data.email,
        is_validated: data.is_validated,
      };
      return tableau;
    });
}
