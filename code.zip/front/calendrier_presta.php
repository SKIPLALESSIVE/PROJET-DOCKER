<?php include __DIR__ . '/template/verifyTokenExist.php'; ?>
<?php include __DIR__ . '/template/header.php'; ?>
<title>Paris CareTaker Service - Calendrier Prestataire</title>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
<link href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css' rel='stylesheet'>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/locales/fr.js'></script>
</head>

<body>
  <?php include 'template/nav.php'; ?>

  <section class="page-section duckBlueBg">
    <div class="container px-4 px-lg-5">
      <div class="row gx-4 gx-lg-5 justify-content-center">
        <div id='calendar'></div>
      </div>
    </div>
  </section>

  <!-- Modal -->
  <div class="modal fade" id="availabilityModal" tabindex="-1" aria-labelledby="availabilityModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="availabilityModalLabel">Êtes-vous disponible ?</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Voulez-vous confirmer votre disponibilité ?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Non</button>
          <form action="https://ela-dev.fr:3000/add_disponibility" method="post" id="formulaireDisponibility" class="needs-validation" novalidate>
            <button type="submit" class="btn btn-primary">Oui</button>
            <!-- Champ de formulaire invisible pour stocker la date -->
            <input type="hidden" name="date" id="selectedDate">
            <!-- Champ de formulaire pour stocker le jeton -->
            <input type="hidden" name="token" value="<?php echo ($_COOKIE['token']) ?>">
          </form>
        </div>
      </div>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var calendarEl = document.getElementById('calendar');

      var calendar = new FullCalendar.Calendar(calendarEl, {
        displayEventTime: false,
        selectable: true,
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        dateClick: function(info) {
          // Mettre à jour la valeur du champ de formulaire avec la date sélectionnée
          document.getElementById('selectedDate').value = info.dateStr;
          $('#availabilityModal').modal('show'); // Afficher la modal au clic sur une date
        },
        events: {
          url: 'https://ela-dev.fr:3000/get_disponibilities?token=<?php echo $_COOKIE['token']; ?>',
          method: 'GET',
          failure: function() {
            alert('Erreur lors du chargement des disponibilités.');
          }
        }
      });

      calendar.render();
    });
  </script>



  <?php include __DIR__ . '/template/footer.php'; ?>

</body>

</html>