from flask import Flask, jsonify, request
from flask_cors import CORS
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

import spacy

nlp = spacy.load("fr_core_news_sm")

app = Flask(__name__)
CORS(app)

bot = ChatBot('ParisCareTaker')

# Création d'une instance d'entraîneur de liste liée à l'instance ChatBot
list_trainer = ListTrainer(bot)

# Liste de questions et réponses correspondantes pour l'entraînement
custom_training_data = [
    ["Pour qui tu travailles ?", "Je suis au service de ParisCareTakerServices, la conciergerie 2.0 !"],
    ["Où est ce que je peux voir mes prestations ?", "Tu peux retrouver cette information sur ton dashboard prestataire !"],
    ["Je n\'arrive pas à me connecter à mon compte, j\'ai un message \"mauvaise interface\"", "Veille à sélectionner la bonne interface !"],
    ["Je ne trouve pas où faire une réservation", "Pour faire une réservation il te suffit de te rendre sur ton dashboard voyageur !"],
    ["Je voudrai ajouter un bien et vous faire confiance !", "Tu peux ajouter un bien sur ton dashboard bailleur !"],
]

# Entraînement de l'entraîneur de liste avec des données personnalisées
for question, answer in custom_training_data:
    list_trainer.train([question, answer])

@app.route('/ask', methods=['POST'])
def ask():
    # Récupération du message de l'utilisateur à partir de la requête POST
    user_message = request.form['user_message']

    # Obtention de la réponse du chatbot
    bot_response = bot.get_response(user_message)

    # Renvoi de la réponse du chatbot au format JSON
    return jsonify({'bot_response': str(bot_response)})

if __name__ == '__main__':
    app.run()
