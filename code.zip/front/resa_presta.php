<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réservations</title>
</head>

<body onload="showResa()">
    <div id="reservations">
        Réservations qui vous concernent :
    </div>

    <script>
        var userId = <?php echo json_encode($userId); ?>;

        function showResa() {
            var options = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id: userId
                })
            };
            fetch('https://ela-dev.fr:3000/show_reservation', options)
                .then(response => response.json())
                .then(data => {
                    var reservationsDiv = document.getElementById('reservations');
                    data.forEach(reservation => {
                        reservationsDiv.innerHTML += '<p>' + JSON.stringify(reservation) + '</p>';
                    });
                })
                .catch(error => console.error('Erreur lors de la récupération des réservations :', error));
        }
    </script>
</body>

</html>