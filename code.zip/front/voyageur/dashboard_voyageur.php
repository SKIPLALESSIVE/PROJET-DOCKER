<?php include('../template/headerLevel2.php'); ?>
<title>Dashboard</title>
</head>
<?php
session_start()
?>
<?php

if (!isset($_SESSION['token'])) {
    if (isset($_COOKIE['token'])) {
        $token = $_COOKIE['token'];
        if ($token) {
           
            $_SESSION['token'] = $token;
        } else {
         
            header('Location: ../login.php');
            exit;
        }
    } else {
        header('Location: ../login.php');
        exit;
    }
} else {
    $token = $_SESSION['token'];
}

// Définir l'interface utilisateur
$_SESSION['interface'] = 'voyageur';

$tokenJS = $token;

?>

<script>
    var token = "<?php echo $tokenJS; ?>";
</script>


<body id="page-top">
    <!-- Navigation-->
    <?php include '../template/navLevel2.php' ?>
    <!-- Connexion -->
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="lunarWhiteText">Dashboard Voyageur</h2>
                    <hr class="divider">
                    <a href="make_resa.php"><button class="btn btn-primary btn-xl">Faire une nouvelle réservation</button></a>
                    <hr class="divider">

                    <form action="see_resa.php" method="post">
                        <input type="hidden" name="userId" id="userId" class="btn btn-primary btn-xl">
                        <button type="submit" class="btn btn-primary btn-xl">Voir vos réservations passées et futures</button>
                        <hr class="divider">
                    </form>

                    <form action="ask_presta.php" method="post">
                        <input type="hidden" name="userId" id="userId" class="btn btn-primary btn-xl">
                        <input type="hidden" name="token" id="token" class="btn btn-primary btn-xl">
                        <button type="submit" class="btn btn-primary btn-xl">Une urgence ? Demandez une prestation !</button>
                        <hr class="divider">
                    </form>

                    <form action="ask_abonnement.php" method="post">
                        <input type="hidden" name="userId" id="userId" class="btn btn-primary btn-xl">
                        <input type="hidden" name="token" id="token" class="btn btn-primary btn-xl">
                        <button type="submit" class="btn btn-primary btn-xl">Voir les abonnements !</button>
                        <hr class="divider">
                    </form>

                    <script>
                        async function recup_token(token) {
                            const headers = new Headers({
                                "Authorization": `Bearer ${token}`
                            });

                            try {
                                const response = await fetch("https://ela-dev.fr:3000/recup_token_voyageur", {
                                    headers: headers
                                });

                                if (!response.ok) {
                                    throw new Error(`API request failed with status ${response.status}`);
                                }

                                const data = await response.json();
                                return data;
                            } catch (error) {
                                console.error("Error:", error);
                                alert("Error retrieving user information!");
                                throw error;
                            }
                        }

                        recup_token(token)
                            .then(UserInfo => {
                                var userId = UserInfo.id;
                                sessionStorage.setItem('userId', userId);
                                sessionStorage.setItem('token', token);
                                console.log(sessionStorage.getItem('userId'));
                                document.querySelectorAll('input[name="userId"]').forEach(input => input.value = userId);
                                document.querySelectorAll('input[name="token"]').forEach(input => input.value = token);
                            })
                            .catch(error => {
                                console.error("Error:", error);
                            });
                    </script>
                </div>
            </div>
        </div>
    </section>
    <?php include('../template/footerLevel2.php'); ?>
</body>