<?php require __DIR__ . '/../template/startSession.php';
include '../template/header.php'; ?>
<title>PCS - Voyageur - Demande d'abonnement</title>
<link rel="stylesheet" href="../css/styles.css">
</head>

<?php if (isset($_GET["error"]) && !empty($_GET["error"])) { ?>
    <hr class="divider duckBlueDarkBg" />
    <div class="alert alert-danger" role="alert">
        <?php echo $_GET["error"]; ?>
    </div>
<?php } ?>

<body id="page-top">
    <?php
    include '../template/nav.php'; ?>

    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-12 text-center">
                    <div id="prestataires-container">
                        <section>
                            <h2 class="text-uppercase mb-4 lunarWhiteText">Liste des Abonnements</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col"></th>
                                            <th scope="col">Formule Gratuite</th>
                                            <th scope="col">Abonnement basique</th>
                                            <th scope="col">VIP +</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="lunarWhiteText"> Présence de publicités dans le contenu
                                                consulté</td>
                                            <td class="lunarWhiteText"> Oui</td>
                                            <td class="lunarWhiteText"> Non</td>
                                            <td class="lunarWhiteText"> Non</td>
                                        </tr>
                                        <tr>
                                            <td class="lunarWhiteText"> Commenter, publier des avis</td>
                                            <td class="lunarWhiteText"> Oui</td>
                                            <td class="lunarWhiteText"> Oui</td>
                                            <td class="lunarWhiteText"> Oui</td>
                                        </tr>
                                        <tr>
                                            <td class="lunarWhiteText"> 5% de réduction sur les prestations</td>
                                            <td class="lunarWhiteText"> Non</td>
                                            <td class="lunarWhiteText"> Non</td>
                                            <td class="lunarWhiteText"> Oui</td>
                                        </tr>
                                        <tr>
                                            <td class="lunarWhiteText"> Prestations offertes</td>
                                            <td class="lunarWhiteText"> Non</td>
                                            <td class="lunarWhiteText"> Oui, dans la limite d'une par an</td>
                                            <td class="lunarWhiteText"> Oui, 5 par ans et sans limite de montant
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="lunarWhiteText"> Accès prioritaire aux prestations </td>
                                            <td class="lunarWhiteText"> Non</td>
                                            <td class="lunarWhiteText"> Oui, une seule par an </td>
                                            <td class="lunarWhiteText"> Oui </td>
                                        </tr>
                                        <tr>
                                            <td class="lunarWhiteText"> Accès prioritaire aux prestations </td>
                                            <td class="lunarWhiteText"> Non</td>
                                            <td class="lunarWhiteText"> Oui, une seule par an </td>
                                            <td class="lunarWhiteText"> Oui </td>
                                        </tr>
                                        <tr>
                                            <td class="lunarWhiteText">Prix </td>
                                            <td class="lunarWhiteText"> Gratuit ! </td>
                                            <td class="lunarWhiteText"> 120€ par an </td>
                                            <td class="lunarWhiteText"> 800€ par an </td>
                                        </tr>
                                        <tr>
                                            <td class="lunarWhiteText"> Votre abonnement actuel </td>
                                            <td class="lunarWhiteText"> </td>
                                            <td class="lunarWhiteText"> </td>
                                            <td class="lunarWhiteText"> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </section>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <form id="subscriptionForm" action="payAbo.php" method="POST">
        <input type="hidden" name="userId" value="<?php echo $_POST['userId']; ?>">
        <input type="hidden" name="subscription" id="subscriptionField">
    </form>

    <script>
        var userId = <?php echo $_POST['userId']; ?>;

        fetch("https://ela-dev.fr:3000/user_abonnement", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: userId })
        })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                var isVIP = data[0].is_vip;
                var isVIPdate = new Date(data[0].is_vip_date); // convertis la date en objet date, plus facile pour manipuler 
                var currentDate = new Date();
                var difference = currentDate.getTime() - isVIPdate.getTime(); // différence en milliseconde entre les deux 

                // Convertir la différence en années
                var differenceInYears = difference / (1000 * 3600 * 24 * 365);
                if (differenceInYears > 1) {
                    isVIP = 0;
                }
                var lastRow = document.querySelector('.table tbody tr:last-child');
                if (isVIP === 0) {
                    lastRow.querySelector('td:nth-child(2)').textContent = 'Vous êtes en version free !';
                    lastRow.querySelector('td:nth-child(3)').innerHTML = '<button class="btn btn-primary" onclick="setSubscription(\'basicAbonnement\')">Passer à cet abonnement !</button>';
                    lastRow.querySelector('td:nth-child(4)').innerHTML = '<button class="btn btn-primary" onclick="setSubscription(\'vip\')">Passer à cet abonnement !</button>';
                } else if (isVIP === 1) {
                    lastRow.querySelector('td:nth-child(3)').textContent = 'Votre abonnement actuel (VIP)';
                    lastRow.querySelector('td:nth-child(4)').innerHTML = '<button class="btn btn-primary" onclick="setSubscription(\'vip\')">Passer à cet abonnement !</button>';
                } else if (isVIP === 2) {
                    lastRow.querySelector('td:nth-child(4)').textContent = 'Vous êtes déjà au max !';
                }
            })
            .catch(error => console.error('Erreur lors de la récupération des données:', error));

        function setSubscription(subscription) {
            document.getElementById('subscriptionField').value = subscription;
            document.getElementById('subscriptionForm').submit();
        }
    </script>

    <?php include ('../template/footerLevel2.php'); ?>
</body>