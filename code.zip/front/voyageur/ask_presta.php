
<?php require __DIR__ . '/../template/startSession.php';
 include '../template/headerLevel2.php'; ?>
 <title>PCS - Voyageur - Demande de Prestation</title>
</head>
<script> var userId = "<?php echo $_POST['userId'] ?>"; 
console.log(sessionStorage.getItem('token'));
</script>

<?php if (isset($_GET["error"]) && !empty($_GET["error"])) { ?>
                        <hr class="divider duckBlueDarkBg" />
                        <div class="alert alert-danger" role="alert">
                            <?php echo $_GET["error"]; ?>
                        </div>
                    <?php } ?>
                    <body id="page-top">
<?php
 include '../template/navLevel2.php'; ?>
<section class="page-section duckBlueBg" id="navigation">
    <div class="container px-6 px-lg-6">
        <div class="row gx-6 gx-lg-6 justify-content-center">   
            <div class="col-lg-10 col-xl-8 text-center ">
                <div class="mt-0 textLunarWhite">
                    <h2 class="mt-0 textLunarWhite">Demande de Prestation</h2>
                    <hr class="divider" />
                    <form action="https://ela-dev.fr:3000/ask_presta" method="post" id="askpresta" class="needs-validation" novalidate>
    <div class="form-floating mb-8">
        <textarea name="asking" id="asking" class="form-control" rows="15" placeholder="ICI" required="required"></textarea>
        <label for="asking">Décrivez votre demande, la conciergerie vous contactera au plus vite</label>
    </div>
    <div class="form-floating mb-3">
        <input type="hidden" name="userId" id="userId" />
        <input type ="hidden" name="interface" id="interface" value="voyageur" />
    </div>
   
    <hr class="divider duckBlueDarkBg" />
    <button class="btn btn-light btn-xl duckBlueDarkBg textLunarWhite" type="submit">Envoyer </button>
</form>
                </div>
            </div>
        </div>
    </section>


    <script>
        document.getElementById('userId').value = userId;
    </script>
    <?php include '../template/footerLevel2.php'; ?>
</body> 
