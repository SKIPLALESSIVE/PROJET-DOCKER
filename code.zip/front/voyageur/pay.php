<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Paiement Stripe</title>
</head>
<body>

  <h1>Formulaire de paiement</h1>

  <form id="payment-form">
    <div id="payment-element"></div>
    
    <div id="link-auth-element"></div>
    <!-- Ajouter un élément avec l'ID address-element -->
    <div id="address-element"></div>
    <button id="submit">
      <div class="spinner hidden" id="spinner"></div>
      <span id="button-text">Payer maintenant</span>
    </button>
    <div id="payment-message" class="hidden"></div>
  </form>

  <script src="https://js.stripe.com/v3/"></script>
  <script> 
    const stripe = Stripe("pk_test_51P1BWfRsg6atUtC62zeGKy1flE2rVyaE45sld0mhH0FbhQrq7C1lIrdJrcqjn1Roxamj8UoWQXhU0KwMQA1iwaCf00IrG9n5SP");

    const urlParams = new URLSearchParams(window.location.search);
    const price = parseFloat(urlParams.get('price'));
    const id = urlParams.get('id');

    let elements;

    initialize();
    checkStatus();
  var token = sessionStorage.getItem('token');
    document.querySelector("#payment-form").addEventListener("submit", handleSubmit);

    async function initialize() {
      const response = await fetch("https://ela-dev.fr:3000/create-payment-intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: [{ prix: price }] }),
      });
      const { clientSecret } = await response.json();

      const appearance = { theme: 'flat', variables: { colorPrimaryText: '#262626' }};
      const options = { mode: 'billing' };

      elements = stripe.elements({ clientSecret });

      const linkAuthElement = elements.create('linkAuthentication');
      const addressElement = elements.create('address', options);
      const paymentElement = elements.create('payment');

      linkAuthElement.mount('#link-auth-element');
      addressElement.mount('#address-element');
      paymentElement.mount('#payment-element');
    }

    async function handleSubmit(e) {
      e.preventDefault();
      setLoading(true);

      try {
        // Une fois que l'appel à l'API est terminé avec succès, confirmer le paiement
        const { error, paymentIntent } = await stripe.confirmPayment({
          elements,
          confirmParams: {
            return_url: `https://ela-dev.fr/2A3-EJH-PA/voyageur/checkout.php?ids=${id}token=${token}`,
          },
        });

        if (error && (error.type === "card_error" || error.type === "validation_error")) {
          showMessage(error.message);
          setLoading(false);
        } else {
          // Rediriger l'utilisateur après que le paiement a été confirmé avec succès
          window.location.href = `https://ela-dev.fr/2A3-EJH-PA/voyageur/checkout.php?ids=${id}token=${token}`;
        }
      } catch (error) {
        console.error("Une erreur s'est produite lors de l'appel à l'API:", error);
        showMessage("Une erreur s'est produite lors de la validation de la prestation. Veuillez réessayer.");
        setLoading(false);
      }
    }

    // Fonction pour vérifier le statut du paiement
    async function checkStatus() {
      const clientSecret = new URLSearchParams(window.location.search).get(
        "payment_intent_client_secret"
      );

      if (!clientSecret) {
        return;
      }

      const { paymentIntent } = await stripe.retrievePaymentIntent(clientSecret);

      switch (paymentIntent.status) {
        case "succeeded":
          showMessage("Payment succeeded!");
          break;
        case "processing":
          showMessage("Your payment is processing.");
          break;
        case "requires_payment_method":
          showMessage("Your payment was not successful, please try again.");
          break;
        default:
          showMessage("Something went wrong.");
          break;
      }
    }

    // Fonction pour afficher un message à l'utilisateur
    function showMessage(messageText) {
      const messageContainer = document.querySelector("#payment-message");

      messageContainer.classList.remove("hidden");
      messageContainer.textContent = messageText;

      setTimeout(function () {
        messageContainer.classList.add("hidden");
        messageContainer.textContent = "";
      }, 4000);
    }

    // Show a spinner on payment submission
    function setLoading(isLoading) {
      if (isLoading) {
        // Disable the button and show a spinner
        document.querySelector("#submit").disabled = true;
        document.querySelector("#spinner").classList.remove("hidden");
        document.querySelector("#button-text").classList.add("hidden");
      } else {
        document.querySelector("#submit").disabled = false;
        document.querySelector("#spinner").classList.add("hidden");
        document.querySelector("#button-text").classList.remove("hidden");
      }
    }
  </script>
</body>
</html>