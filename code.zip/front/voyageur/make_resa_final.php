<?php require __DIR__ . '/../template/startSession.php';
 include '../template/headerLevel2.php'; ?>
 <title>PCS - Voyageur - Réservation</title>
</head>
<body id="page-top">
<?php
 include '../template/navLevel2.php'; 

$bien_id = $_POST['bien_id']; ?>
<script> var bien_id = <?php echo $bien_id; ?>; </script>

<section class="page-section duckBlueBg" id="navigation">
 <div class="container px-4 px-lg-5">
     <div class="row gx-4 gx-lg-5 justify-content-center">
         <div class="col-lg-8 col-xl-6 text-center ">
<div id="bien_info"></div>

<div id="date_selection" class = "lunarWhiteText">
    <label for="start_date">Date de début :</label>
    <input type="date" id="start_date" name="start_date">
    <label for="end_date">Date de fin :</label>
    <input type="date" id="end_date" name="end_date">
    <label for ="nb_personnes">Nombre de personnes</label>
    <input type="text" id="nb_personnes" name="nb_personnes">
    <button id="reservation_button" class ="btn btn-primary">Réserver</button>
    <a id="pay_link" href="#" style="display: none;"><button type="submit" class="btn btn-primary">Payer et valider la réservation</button></a>
</div>
<script>
    console.log(sessionStorage.getItem('token')); 
    var prix;
    var id_resa;
    var start_date;
    var end_date;
    var user_id;
    var nb_personnes; 
    var total_price;

    async function get_bien() {
        try {
            const response = await fetch('http://localhost:3000/show_bien', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: bien_id }),
                mode: 'cors'
            });
            if (!response.ok) {
                throw new Error(`Erreur HTTP ! Statut : ${response.status}`);
            }
            const data = await response.json();
            console.log(data);

            const address = data[0].address;
            const bien_type = data[0].bien_type;
            const chambers_nb = data[0].chambers_nb;
            const land = data[0].land;
            const location_type = data[0].location_type;
            const occupants_nb = data[0].occupants_nb;
            prix = data[0].price;

            const bien_info_html = `
             <div class=\"lunarWhiteText\">
                <p>Adresse : ${address}</p>
                <p>Type de bien : ${bien_type}</p>
                <p>Nombre de chambres : ${chambers_nb}</p>
                <p>Pays : ${land}</p>
                <p>Type de location : ${location_type}</p>
                <p>Nombre d'occupants : ${occupants_nb}</p>
                <p>Prix : ${prix} €</p>
                </div>
                <hr class=\"divider\" />
            `;

            const bien_info_element = document.getElementById("bien_info");
            bien_info_element.innerHTML = bien_info_html;

        } catch (error) {
            console.error("Erreur:", error);
            alert("Erreur lors de la récupération des données de l'API !");
        }
    }

    get_bien();

    const reservationButton = document.getElementById("reservation_button");

    reservationButton.addEventListener("click", async function (event) {
        event.preventDefault();

        await sendReservation();
    });

    async function sendReservation() {
    try {
        start_date = document.getElementById("start_date").value;
        end_date = document.getElementById("end_date").value;
        user_id = sessionStorage.getItem('userId');

        const postData = {
            start_date: start_date,
            end_date: end_date,
            user_id: user_id,
            id_bien: bien_id,
            price : prix,
            nb_personnes : document.getElementById("nb_personnes").value
        };

        const response = await fetch('http://localhost:3000/send_resa', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(postData),
            mode: 'cors'
        });

        if (!response.ok) {
            throw new Error(`Erreur HTTP ! Statut : ${response.status}`);
        }

        const resData = await response.json();
        console.log("Réservation envoyée avec succès :", resData);

        id_resa = resData.id;
        const nb_nuits = resData.nb_nuits;
        total_price = prix * nb_nuits;
        configurePayLink();
    } catch (error) {  
        console.error("Erreur lors de l'envoi de la réservation :", error);
        alert("Erreur lors de l'envoi de la réservation !");
    }
} 


    function configurePayLink() {
        const payLink = document.getElementById("pay_link");
        payLink.href = `http://localhost/2A3-EJH-PA/voyageur/pay.php?price=${total_price}&id=${id_resa}`;
        payLink.style.display = "block";
    }
</script>
</div>
</div>
</div>
</section>
<?php include '../template/footer.php' ?>
</body>
</html>
