<?php include '../template/headerLevel2.php'; ?>

<!DOCTYPE html>
<html>

<head>
    <title>Voir toutes les réservations et les supprimer</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>

<?php include '../template/navLevel2.php'; ?>
<script> var token = sessionStorage.getItem('token'); </script>
<body id="page-top">
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-12 text-center">
                    <div id="prestataires-container">
                        <section>
                            <h2 class="text-uppercase mb-4">Liste des réservations</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col">ID Réservation</th>
                                            <th scope="col">ID Bien</th>
                                            <th scope="col">NB personnes</th>
                                            <th scope="col">prix</th>
                                            <th scope="col">Date de début</th>
                                            <th scope="col">Date de fin</th>
                                            <th scope="col">Payé</th>
                                            <th scope="col">Validé</th>
                                            <th scope="col">Actions</th>
                                            <th scope="col">Note</th>
                                        </tr>
                                    </thead>
                                    <tbody id="liste_resa_body"></tbody>
                                </table>
                            </div>
                        </section>
                        <a href = "make_resa.php"> <button class="btn btn-primary">Réserver un bien</button></a>
                        <a onclick="returnToDashboard()" class="btn btn-primary">Retourner au dashboard</a>
                    </div>

                    <script>
                        var userId = <?php echo $_POST['userId']; ?>;

                        fetch("https://ela-dev.fr:3000/user_all_reservation", {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ id: userId })
                        })
                            .then(response => response.json())
                            .then(data => {
                                console.log(data);
                                var tbody = document.getElementById("liste_resa_body");

                                data.forEach(reservation => {
                                    var row = document.createElement("tr");
                                    row.innerHTML = `
                    <td>${reservation.id}</td>
                    <td>${reservation.id_bien}</td>
                    <td>${reservation.nb_personnes}</td>
                    <td>${reservation.price}</td>
                    <td>${new Date(reservation.start_date).toLocaleDateString()}</td>
                    <td>${new Date(reservation.end_date).toLocaleDateString()}</td>
                    <td>${reservation.is_paid ? "Oui" : "Non"}</td>
                    <td>${reservation.is_validated ? "Oui" : "Non"}</td>
                    <td>
                        <button class="btn btn-primary" onclick="supprimerReservation(${reservation.id})">Supprimer</button>
                        ${!reservation.is_paid ? `<button class="btn btn-primary" onclick="payerReservation(${reservation.id}, ${reservation.price})">Payer</button>` : ''}
                    </td>
                    <td>
    <div class="rating-2">
        <input type="radio" id="star${reservation.id}_1" name="rating-2" value="1" ${Number(reservation.note) === 1 ? 'checked' : ''} onchange="updateRating(${reservation.id}, 1, 'reservation')" /><label for="star${reservation.id}_1" title="1 étoile"></label>
        <input type="radio" id="star${reservation.id}_2" name="rating-2" value="2" ${Number(reservation.note) === 2 ? 'checked' : ''} onchange="updateRating(${reservation.id}, 2, 'reservation')" /><label for="star${reservation.id}_2" title="2 étoiles"></label>
        <input type="radio" id="star${reservation.id}_3" name="rating-2" value="3" ${Number(reservation.note) === 3 ? 'checked' : ''} onchange="updateRating(${reservation.id}, 3, 'reservation')" /><label for="star${reservation.id}_3" title="3 étoiles"></label>
        <input type="radio" id="star${reservation.id}_4" name="rating-2" value="4" ${Number(reservation.note) === 4 ? 'checked' : ''} onchange="updateRating(${reservation.id}, 4, 'reservation')" /><label for="star${reservation.id}_4" title="4 étoiles"></label>
        <input type="radio" id="star${reservation.id}_5" name="rating-2" value="5" ${Number(reservation.note) === 5 ? 'checked' : ''} onchange="updateRating(${reservation.id}, 5, 'reservation')" /><label for="star${reservation.id}_5" title="5 étoiles"></label>
    </div>
</td>
                `;
                                    tbody.appendChild(row);
                                });
                            })
                            .catch(error => {
                                console.error("Error:", error);
                            });

                        function supprimerReservation(idReservation) {
                            fetch("https://ela-dev.fr:3000/delete_reservation", {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({ id: idReservation })
                            })
                                .then(() => location.reload());
                            console.log("Suppression de la réservation avec l'ID:", idReservation);
                        }

                        function payerReservation(id, price) {
                            window.location.href = `https://ela-dev.fr/2A3-EJH-PA/voyageur/pay.php?id=${id}&price=${price}`;
                        }

                        function updateRating(id, rating, type) {
            const body = {
                id: id,
                rating: rating,
                interface: type === 'reservation' ? 'reservation' : 'prestation'
            };
            fetch(`https://ela-dev.fr:3000/update_rating`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            })
            .then(response => response.json())
            .then(data => {
                console.log("Note mise à jour avec succès :", data);
            })
            .catch(error => console.error("Erreur lors de la mise à jour de la note :", error));
        }
        function returnToDashboard() {
        var token = sessionStorage.getItem('token');
        window.location.href = `dashboard_voyageur.php?token=${token}`;
    }
                        </script>
                </div>
            </div>
        </div>
    </section>
</body>
<?php include '../template/footerLevel2.php' ?>
</html>
