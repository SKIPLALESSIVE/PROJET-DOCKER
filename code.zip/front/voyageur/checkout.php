<?php session_start(); ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paiement Validé</title>
    <script>

        function getQueryParams() {
            const params = {};
            const queryString = window.location.search.slice(1); // Supprime le '?' au début de la chaîne de requête
            // split la chaîne de requête sur 'ids=' ou 'token=' et filtre les parties vides
            // renvoie un tableau contenant les valeurs de 'ids' et 'token'
            const pairs = queryString.split(/(?:ids=|token=)/).filter(Boolean);
            params['ids'] = pairs[0];
            params['token'] = pairs[1];
            return params;
        }

        const params = getQueryParams();
        const id = params['ids'];
        const token = params['token'];

        console.log(`ID: ${id}, Token: ${token}`);

        fetch("https://ela-dev.fr:3000/validated_payements", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: id, type: 'reservation', token: token })
        })
        .then(response => {
            if (response.ok) {
              
                window.location.href = `dashboard_voyageur.php?token=${token}`;
            } else {
                alert('Une erreur est survenue lors de la validation du paiement. Veuillez réessayer.');
            }
        })
        .catch(error => {
            alert(`Une erreur réseau est survenue : ${error.message}`);
        });
    </script>
</head>
<body>
    <h2>Votre Paiement a bien été reçu !, Vous pouvez dès à présent retourner sur votre dashboard !</h2>
</body>
</html>
