<?php require __DIR__ . '/../template/startSession.php'; ?>

<script>
    var userId = sessionStorage.getItem('userId');
    var subscription = sessionStorage.getItem('subscription');

    fetch("https://ela-dev.fr:3000/checkout_abonnement", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: userId, subscription: subscription })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur lors de la mise à jour de l\'abonnement');
            }
            return response.json();
        })
        .then(data => {
            console.log('Abonnement mis à jour avec succès:', data);
            window.location.href = 'dashboard_voyageur.php';
        })
        .catch(error => {
            console.error("Erreur lors de la récupération de la validation de l'API:", error);
        });
</script>
