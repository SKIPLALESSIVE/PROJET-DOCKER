<?php
require_once __DIR__ . '/recup_img_path.php'; 
require_once __DIR__ . '/../template/startSession.php';
include '../template/headerLevel2.php'; 
?>
<title>PCS - Voyageur - Réservation</title>
</head>
<body id="page-top">
    
<?php include '../template/navLevel2.php'; ?>
<section class="page-section duckBlueBg" id="navigation">
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-lg-8 col-xl-6 text-center ">
                <?php
                $data = []; 
                try {
                    $response = file_get_contents("https://ela-dev.fr:3000/show_all_biens");
                    if ($response === false) {
                        throw new Exception("Erreur lors de la récupération des données de l'API !");
                    }
                    $data = json_decode($response, true);
                    
                } catch (Exception $e) {
                    echo "Erreur : " . $e->getMessage();
                }

                foreach ($data as $item) {
                    $bien = $item['bien'];
                    $moyenne = $item['moyenne'];

                    echo "<div class=\"lunarWhiteText\">";
                    echo "<h2> Numéro du bien : {$bien['id']}</h2>";
                    echo "<p>Adresse : {$bien['address']}</p>";
                    echo "<p>Type de bien : {$bien['bien_type']}</p>";
                    echo "<p>Nombre de chambres : {$bien['chambers_nb']}</p>";
                    echo "<p>Pays : {$bien['land']}</p>";
                    echo "<p>Type de location : {$bien['location_type']}</p>";
                    echo "<p>Prix : {$bien['price']} €</p>";
                    echo "<p>Nombre d'occupants maximum : {$bien['occupants_nb']}</p>";
                    echo "<p>Moyenne : " . ($moyenne != 0 ? $moyenne : "Pas encore noté") . "</p>";


                    $pathInfo = show_path($bien['id']);

                    echo "Images : <br>";
                    foreach ($pathInfo['images'] as $image) {
                        echo "<img src='$image' style='max-width: 400px; max-height: 400px;'>";
                    }

                    echo "</div>";
                    echo "<form action='make_resa_final.php' method='POST'>";
                    echo "<input type='hidden' name='bien_id' value='{$bien['id']}'>";
                    echo "<button type='submit' class ='btn btn-primary'>Réserver</button>";
                    echo "<hr class=\"divider\" />";
                    echo "</form>";
                }
                ?>
                <script> console.log(sessionStorage.getItem('token')); </script>
            </div>
        </div>
    </div>
</section>

</body>
</html>
