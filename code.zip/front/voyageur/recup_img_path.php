<?php 
function show_path($bienId) {
    $path = "../assets/bien_$bienId";
    
    // Vérifier si le dossier existe
    if (!is_dir($path)) {
        return [
            'path' => $path,
            'images' => [] // Retourner un tableau vide s'il n'y a pas de dossier
        ];
    }

    $scandir = scandir($path);
    $images = [];

    // Vérifier s'il y a des fichiers dans le dossier
    if ($scandir !== false && count($scandir) > 2) { // 2 pour '.' et '..'
        // Supprimer '.' et '..' du tableau scandir
        $scandir = array_diff($scandir, array('.', '..'));
        
        // Ajouter le chemin complet des images au tableau $images
        foreach ($scandir as $file) {
            $images[] = $path . '/' . $file;
        }
    }

    return [
        'path' => $path,
        'images' => $images
    ];
}
?>
