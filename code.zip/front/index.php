<?php include 'template/header.php';  ?>
<?php include 'template/startSession.php';  ?>
<title>Paris Care Taker - Home</title>
</head>

<body id="page-top">
    <!-- Navigation-->
    <?php include 'template/nav.php' ?>

    <!-- Masthead-->
    <header class="masthead" id="masthead">
        <div class="container px-4 px-lg-5 h-100">
            <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
                <div class="col-lg-8 align-self-end">
                    <h1 class="text-white font-weight-bold" id="masthead_title">Votre service de conciergerie/de voyage à porté de main</h1>
                    <hr class="duckBlueHr" />
                </div>
                <div class="col-lg-8 align-self-baseline">
                    <p class="text-white-75 mb-5" id="masthead_description">Chez PCS, nous proposons tout un service de conciergerie et de gestion de voyageur pour répondre à vos attentes</p>
                    <hr class="duckBlueHr" />
                    <?php
                    if (isset($_COOKIE["token"])) {
                        if(isset($_SESSION['interface']))
                        {
                            switch($_SESSION['interface'])
                            {
                                case 'prestataire':
                                    echo '<a class="btn btn-primary btn-xl" href="dashboard_prestataire.php">Votre espace</a>';
                                    break;
                                case 'bailleur':
                                    echo '<a class="btn btn-primary btn-xl" href="bailleur/dashboard_bailleur.php">Votre espace</a>';
                                    break;
                                case 'voyageur':
                                    echo '<a class="btn btn-primary btn-xl" href="voyageur/dashboard_voyageur.php">Votre espace</a>';
                                    break;
                            }
                        } else {
                            echo '<a class="btn btn-primary btn-xl" href="register.php">Inscrivez-vous !</a>';
                        }
                    } else {
                        echo '<a class="btn btn-primary btn-xl" href="register.php">Inscrivez-vous !</a>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Demande en cas de problème -->
    <section class="page-section duckBlueBg" id="services">
        <div class="container px-4 px-lg-5">
            <h2 class="text-white font-weight-bold text-center mb-4">Vous avez un problème ?</h2>
            <hr class="divider duckBlueDarkBg" />
            <div class="row gx-4 gx-lg-5">
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="mt-3">
                        <i class="fas fa-4x fa-broom text-white mb-4"></i>
                        <h3 class="h4 mb-2 text-white">Ménage</h3>
                        <p class="text-white mb-0">Besoin d'un ménage de dernière minute ?</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="mt-3">
                        <i class="fas fa-4x fa-tools text-white mb-4"></i>
                        <h3 class="h4 mb-2 text-white">Bricolage</h3>
                        <p class="text-white mb-0">Un problème de plomberie ?</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 text-center">
                    <div class="mt-3">
                        <i class="fas fa-4x fa-utensils text-white mb-4"></i>
                        <h3 class="h4 mb-2 text-white">Cuisine</h3>
                        <p class="text-white mb-0">Un repas à préparer ?</p>
                    </div>
                </div>
            </div>
            <hr class="divider duckBlueDarkBg" />
        </div>
        <div class="text-center mt-4">
            <a class="btn btn-primary btn-xl" href="contact.php">Contacter nous</a>
        </div>
    </section>


    <style>
        .open-button {
  background-color: #555;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 23px;
  right: 28px;
  width: 280px;
}

.chat-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}


.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

.form-container textarea {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
  resize: none;
  min-height: 200px;
}

.form-container textarea:focus {
  background-color: #ddd;
  outline: none;
}

.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}


.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
    <button class="open-button" onclick="openForm()">Chat</button>

<div class="chat-popup" id="myForm">
  <div class="form-container">
  <h2> Chatbot </h2>
    <br>
    <ul id="questions">
    <li>Pour qui tu travailles ? </li>
    <hr class="divider">
    <li>Où est ce que je peux voir mes prestations ? </li>
    <hr class="divider">
    <li>Je n'arrive pas à me connecter à mon compte, j'ai un 
        message "mauvaise interface"</li>
        <hr class="divider">
    <li>Je ne trouve pas où faire une réservation</li>
    <hr class="divider">
    <li>Je voudrai ajouter un bien et vous faire confiance ! </li>
    <hr class="divider">
    
</ul>
<br>
<br>

<div id="reponses"></div>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
</div>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

    <script>
        // Récupérer les questions
var questions = document.querySelectorAll('#questions li');
questions.forEach(function(question) {
    question.addEventListener('click', function() {
        var user_message = question.textContent;
        console.log(user_message);
        fetch('http://127.0.0.1:5000/ask', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'user_message=' + encodeURIComponent(user_message),
        })
        .then(response => response.json())
        .then(data => {
            var reponseDiv = document.getElementById('reponses');
            reponseDiv.innerHTML = data.bot_response;
        });
    });
});

        function responsiveNavBar() {
            document.getElementById("navbarResponsive").classList.toggle("show");
        }
    </script>

    <!-- Footer-->
    <?php include __DIR__ . '/template/footer.php';  ?>