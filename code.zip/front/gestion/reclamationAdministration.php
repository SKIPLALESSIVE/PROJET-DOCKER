<?php include 'template/headerAdministration.php'; ?>
<title>PCS - SeePrestation</title>
</head>

<body id="page-top">

    <!-- Navigation-->
    <?php include 'template/navbarAdministrationLevel.php'; ?>

    <!-- Administration -->
    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-12 text-center">
                    <div id="prestataires-container">
                        <section>
                            <h2 class="text-uppercase mb-4">Liste des prestations demandées</h2>
                            <div class="table-responsive ">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col">Id du user</th>
                                            <th scope="col">Nom</th>
                                            <th scope="col">Prénom</th>
                                            <th scope="col">Adresse</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">téléphone</th>
                                            <th scope="col">Demande</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="liste-utilisateurs" class="lunarWhiteText">
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>

                    <div id="prestataires-list">
                        <section>
                            <h2 class="text-uppercase mb-4">Liste des prestataires</h2>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col">Id du presta</th>
                                            <th scope="col">Nom</th>
                                            <th scope="col">Prénom</th>
                                            <th scope="col">Adresse</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">téléphone</th>
                                            <th scope="col">prestation </th>
                                        </tr>
                                    </thead>
                                    <tbody id="liste-prestataire" class="lunarWhiteText">
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                    <script>
                        // Requête pour récupérer la liste des prestations demandées
                        fetch('https://ela-dev.fr:3000/show_all_asks', {
                            method: 'GET',
                            headers: {
                                'Content-type': 'application/json',
                            }
                        })
                            .then(response => response.json())
                            .then(data => {
                                const listeUtilisateurs = document.getElementById('liste-utilisateurs');
                                data.forEach(utilisateur => {
                                    const tr = document.createElement('tr');
                                    // Affichage des données de chaque utilisateur
                                    tr.innerHTML = `
                                        <td>${utilisateur.id_taker}</td>
                                        <td>${utilisateur.utilisateur.lastname}</td>
                                        <td>${utilisateur.utilisateur.firstname}</td>
                                        <td>${utilisateur.utilisateur.address}</td>
                                        <td>${utilisateur.utilisateur.email}</td>
                                        <td>${utilisateur.utilisateur.phone}</td>
                                        <td>${utilisateur.ask_taker}</td>
                                        <td>
                                            <form action="accessCalendarBien.php" method="post">
                                                <input type="hidden" name="id_taker" value="${utilisateur.id_taker}">
                                                <button type="submit" class="btn btn-primary btn-sm">Voir</button>
                                            </form>
                                            <form action="https://ela-dev.fr:3000/delete_ask_user" method="post" onsubmit="return submitForm(this);">
                                                <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                            </form>
                                        </td>
                                    `;
                                    listeUtilisateurs.appendChild(tr);
                                });
                            })
                            .catch(error => {
                                console.error('Erreur lors de la récupération des données des prestations demandées:', error);
                            });

                        // Requête pour récupérer la liste des prestataires
                        fetch('https://ela-dev.fr:3000/show_prestataire', {
                            method: 'GET',
                            headers: {
                                'Content-type': 'application/json',
                            }
                        })
                            .then(response => response.json())
                            .then(data => {
                                console.log(data);
                                const listePrestataires = document.getElementById('liste-prestataire');
                                data.forEach(prestataire => {
                                    const tr = document.createElement('tr');
                                    // Affichage des données de chaque prestataire
                                    tr.innerHTML = `
                                        <td>${prestataire.id}</td>
                                        <td>${prestataire.lastname}</td>
                                        <td>${prestataire.firstname}</td>
                                        <td>${prestataire.address}</td>
                                        <td>${prestataire.email}</td>
                                        <td>${prestataire.phone}</td>
                                        <td>${prestataire.type_prestation}</td>
                                    `;
                                    listePrestataires.appendChild(tr);
                                });
                            })
                            .catch(error => {
                                console.error('Erreur lors de la récupération des données des prestataires:', error);
                            });
                    </script>

                </div>
            </div>
        </div>
    </section>
    <script>
        function responsiveNavBar() {
            document.getElementById("navbarResponsive").classList.toggle("show");
        }
    </script>
    <!-- Footer-->
    <?php include 'template/footerAdministration.php' ?>
