<?php include 'template/headerAdministration.php'; ?>
<title>Paris CareTaker Service - Calendrier Bien Disponibilité</title>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
<link href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css' rel='stylesheet'>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/locales/fr.js'></script>
</head>

<body>
    <?php include 'template/navbarAdministrationLevel.php'; ?>

    <!-- Modal -->
    <div class="modal fade" id="availabilityModal" tabindex="-1" aria-labelledby="availabilityModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="availabilityModalLabel">Choisissez le type de prestation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <select class="form-select" name="type" id="type" required>
                        <option value="" selected disabled hidden>Choisissez le type de prestation</option>
                        <script>
                            // Récupérer les types de prestation depuis la base de données
                            fetch('https://ela-dev.fr:3000/show_type_prestation')
                                .then(response => response.json())
                                .then(data => {
                                    data.forEach(service => {
                                        console.log(service.type_prestation);
                                        var option = document.createElement('option');
                                        option.text = service.type_prestation;
                                        document.getElementById('type').appendChild(option);
                                    });
                                });
                        </script>
                    </select>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Type de prestation</th>
                                <th>Prix</th>
                                <th>Durée</th>
                                <th>Évaluation</th>
                            </tr>
                        </thead>
                        <tbody id="prestataireTable">
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Non</button>
                        <button type="submit" class="btn btn-primary" id = "confirmAdd">Oui</button>
                        <!-- Champ de formulaire invisible pour stocker la date -->
                        <input type="hidden" name="date" id="selectedDate">
                        <!-- Champ de formulaire pour stocker le type  de prestation selectionner -->
                        <input type="hidden" name="type" id="selectedType">
                        <!-- Champ de formulaire pour stocker le jeton -->
                        <input type="hidden" name="token" value="<?php echo ($_COOKIE['token']) ?>">
                </div>
            </div>
        </div>
    </div>

    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div id='calendar'></div>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            // Fonction pour récupérer les données des deux sources et les fusionner
            function getCombinedEvents() {
                // Récupérer les données du premier événement
                var firstEventSource = fetch('https://ela-dev.fr:3000/show_calendar_bien?token=<?php echo $_COOKIE['token']; ?><?php if(isset($_POST['id_taker'])){?>&id_voyageur=<?php echo $_POST['id_taker'];}else{?>&id_bien=<?php echo $_POST['id_bien'];}?>')
                    .then(response => response.json());

                // Récupérer les données du deuxième événement
                var secondEventSource = fetch('https://ela-dev.fr:3000/show_prestation_bien?token=<?php echo $_COOKIE['token']; ?><?php if(isset($_POST['id_taker'])){?>&id_voyageur=<?php echo $_POST['id_taker'];}else{?>&id_bien=<?php echo $_POST['id_bien'];}?>')
                    .then(response => response.json());

                // Fusionner les données des deux sources
                return Promise.all([firstEventSource, secondEventSource])
                    .then(([firstEvents, secondEvents]) => {
                        // Combiner les événements des deux sources
                        var combinedEvents = firstEvents.concat(secondEvents);
                        return combinedEvents;
                    });
            }

            var calendar = new FullCalendar.Calendar(calendarEl, {
                displayEventTime: false,
                selectable: true,
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                dateClick: function(info) {
                    document.getElementById('selectedDate').value = info.dateStr;
                    $('#availabilityModal').modal('show');
                },
                eventColor: '#FF0000',
                eventTextColor: '#FFFFFF',
                eventDisplay: 'block',
                eventOverlap: false,
                events: function(info, successCallback, failureCallback) {
                    // Appeler la fonction pour récupérer les événements combinés
                    getCombinedEvents()
                        .then(combinedEvents => {
                            // Passer les événements combinés à FullCalendar
                            successCallback(combinedEvents);
                        })
                        .catch(error => {
                            // Gérer les erreurs
                            console.error('Erreur lors de la récupération des événements:', error);
                            failureCallback(error);
                        });
                },
            });
            calendar.render();

            document.getElementById('type').addEventListener('change', function() {
                console.log("Type de prestation sélectionné");
                var selectedType = this.value; // Récupérer le type de prestation sélectionné
                var selectedDate = document.getElementById('selectedDate').value; // Récupérer la date sélectionnée

                // Récupérer les prestataires disponibles depuis la base de données
                fetch('https://ela-dev.fr:3000/show_board_presta?type_prestation=' + selectedType + '&date=' + selectedDate)
                    .then(response => response.json())
                    .then(data => {
                        var tableBody = document.getElementById('prestataireTable');
                        tableBody.innerHTML = ''; // Réinitialiser le contenu du tableau
                        console.log(data);
                        data.forEach(item => {
                            console.log(item);
                            //si item.lastname est undefined alors on saute une iteration
                            if (item.lastname === undefined) {
                                return;
                            }
                            var row = document.createElement('tr');

                            // Ajouter la cellule pour le nom de l'utilisateur
                            var userCell = document.createElement('td');
                            userCell.textContent = item.lastname + ' ' + item.firstname; // Ajouter le nom complet de l'utilisateur
                            row.appendChild(userCell);
                            //sauter une iteration dans item
                            item = data[1];


                            // Ajouter la cellule pour le type de prestation
                            var typeCell = document.createElement('td');
                            typeCell.textContent = item.type_prestation; // Ajouter le type de prestation
                            row.appendChild(typeCell);

                            // Ajouter la cellule pour le prix de la prestation
                            var priceCell = document.createElement('td');
                            priceCell.textContent = item.price + ' €'; // Ajouter le prix de la prestation
                            row.appendChild(priceCell);

                            // Ajouter la cellule pour la durée de la prestation
                            var durationCell = document.createElement('td');
                            durationCell.textContent = item.duration + ' heures'; // Ajouter la durée de la prestation
                            row.appendChild(durationCell);

                            // Ajouter la cellule pour l'évaluation de la prestation
                            var evaluationCell = document.createElement('td');
                            evaluationCell.textContent = item.evaluation + '/5'; // Ajouter l'évaluation de la prestation
                            row.appendChild(evaluationCell);

                            //ajouter la cellule pour la selection
                            var selectionCell = document.createElement('td');
                            var radio = document.createElement('input');
                            radio.type = 'radio';
                            radio.name = 'id_presta';
                            radio.value = item.id;
                            console.log(radio.value);
                            selectionCell.appendChild(radio);
                            row.appendChild(selectionCell);

                            tableBody.appendChild(row);
                        });
                    });
                });
                document.getElementById('availabilityModal').addEventListener('click', function(event) {
                    if (event.target.id === 'confirmAdd') { // Assuming the "Oui" button has an id "confirmAdd"
                        var selectedDate = document.getElementById('selectedDate').value;
                        var selectedType = document.getElementById('type').value;
                        var selectedPrestataire = document.querySelector('input[name="id_presta"]:checked').value;
                        var selectedPrice = document.querySelector('input[name="id_presta"]:checked').parentNode.parentNode.childNodes[2].textContent;
                        var selectedDuration = document.querySelector('input[name="id_presta"]:checked').parentNode.parentNode.childNodes[3].textContent;

                        // Effectuer la requête POST vers la route "/add_prestation"
                        fetch('https://ela-dev.fr:3000/add_prestation?date=' + selectedDate + '&id_voyageur=<?php echo $_POST['id_taker']; ?>', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                id_prestataire: selectedPrestataire,
                                type_prestation: selectedType,
                                price : selectedPrice,
                                duration : selectedDuration,
                            })
                        })
                        .then(response => response.json())
                        .then(data => {
                            // Gérer la réponse de la route "/add_prestation"
                            console.log(data.message); // Afficher un message de succès ou d'erreur
                        })
                        .catch(error => {
                            console.error('Erreur lors de la requête POST:', error);
                        });
                    }
                });
            });
            
    </script>

    <?php include 'template/footerAdministration.php'; ?>

</body>

</html>
