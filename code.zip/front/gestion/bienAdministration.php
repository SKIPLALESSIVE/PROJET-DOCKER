<?php include 'template/headerAdministration.php'; ?>
<title>PCS - Bailleur - Gestion Bien</title>
</head>

<body id="page-top">
    <!-- Navigation-->
    <?php include 'template/navbarAdministrationLevel.php'; ?>
    <!-- Nav Section -->
    <section class="page-section duckBlueBg" id="navigation">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-12 text-center">
                    <h2 class="mt-0 lunarWhiteText">Liste des biens</h2>
                    <hr class="divider" />
                    <div class="row" id="bienList"></div>
                    <script>
                        fetch('https://ela-dev.fr:3000/show_all_bien')
                            .then(response => response.json())
                            .then(data => {
                                console.log(data); 
                                let cardHTML = ''; // Variable pour stocker le HTML des cartes
                                data.forEach(bien => {
                                    cardHTML += `
                <div class="col-lg-2 col-md-4 col-sm-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">${bien.id}</h5>
                            <p class="card-text">Land: ${bien.land}</p>
                            <p class="card-text">Type: ${bien.bien_type}</p>
                            <p class="card-text">Address: ${bien.address}</p>
                            <p class="card-text">Moyenne: ${moyenne}</p>
                            <div class="card-footer">
                                <form action="accessCalendarBien.php" method="POST">
                                    <input type="hidden" name="id_bien" value="${bien.id}">
                                    <button class="btn btn-primary" type="submit">Administrer</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });

                                document.getElementById('bienList').innerHTML = cardHTML;
                            });
                    </script>
                    <hr class="divider" />
                </div>
            </div>
        </div>
    </section>
    <!-- Footer-->
    <?php include '../template/footer.php' ?>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
    <script>
        function responsiveNavBar() {
            document.getElementById("navbarResponsive").classList.toggle("show");
        }
    </script>
</body>

</html>