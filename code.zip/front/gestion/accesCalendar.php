<?php include 'template/headerAdministration.php'; ?>
<title>Paris CareTaker Service - Calendrier Bien Disponibilité</title>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
<link href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css' rel='stylesheet'>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/locales/fr.js'></script>
</head>

<body>
    <?php include 'template/navbarAdministrationLevel.php'; ?>

    <!-- Modal -->
    <div class="modal fade" id="availabilityModal" tabindex="-1" aria-labelledby="availabilityModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="availabilityModalLabel">Choisissez le type de prestation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <select class="form-select" name="type" id="type" required>
                        <option value="" selected disabled hidden>Choisissez le type de prestation</option>
                        <script>
                            // Récupérer les types de prestation depuis la base de données
                            fetch('https://ela-dev.fr:3000/show_type_prestation')
                                .then(response => response.json())
                                .then(data => {
                                    data.forEach(service => {
                                        console.log(service.type_prestation);
                                        var option = document.createElement('option');
                                        option.text = service.type_prestation;
                                        document.getElementById('type').appendChild(option);
                                    });
                                });
                        </script>
                    </select>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Type de prestation</th>
                                <th>Prix</th>
                                <th>Durée</th>
                                <th>Évaluation</th>
                            </tr>
                        </thead>
                        <tbody id="prestataireTable">
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Non</button>
                    <form action="https://ela-dev.fr:3000/add_disponibility" method="post" id="formulaireDisponibility" class="needs-validation" novalidate>
                        <button type="submit" class="btn btn-primary">Oui</button>
                        <!-- Champ de formulaire invisible pour stocker la date -->
                        <input type="hidden" name="date" id="selectedDate">
                        <!-- Champ de formulaire pour stocker le type  de prestation selectionner -->
                        <input type="hidden" name="type" id="selectedType">
                        <!-- Champ de formulaire pour stocker le jeton -->
                        <input type="hidden" name="token" value="<?php echo ($_COOKIE['token']) ?>">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <section class="page-section duckBlueBg">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div id='calendar'></div>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                displayEventTime: false,
                selectable: true,
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                dateClick: function(info) {
                    // Mettre à jour la valeur du champ de formulaire avec la date sélectionnée
                    document.getElementById('selectedDate').value = info.dateStr;
                    $('#availabilityModal').modal('show'); // Afficher la modal au clic sur une date
                },
                eventColor: '#FF0000', // Couleur des événements indisponibles
                eventTextColor: '#FFFFFF', // Couleur du texte des événements
                eventDisplay: 'block', // Afficher les événements sur une seule ligne
                eventOverlap: false, // Empêcher le chevauchement des événements
                events: {
                    url: 'https://ela-dev.fr:3000/show_calendar_bien?token=<?php echo $_COOKIE['token']; ?>&id_voyageur=<?php echo $_POST['id_taker']; ?>',
                    method: 'GET',
                    failure: function() {
                        alert('Erreur lors du chargement des disponibilités.');
                    }
                }
            });

            calendar.render();

            document.getElementById('type').addEventListener('change', function() {
                console.log("Type de prestation sélectionné");
                var selectedType = this.value; // Récupérer le type de prestation sélectionné
                var selectedDate = document.getElementById('selectedDate').value; // Récupérer la date sélectionnée

                // Récupérer les prestataires disponibles depuis la base de données
                fetch('https://ela-dev.fr:3000/show_board_presta?type_prestation=' + selectedType + '&date=' + selectedDate)
                    .then(response => response.json())
                    .then(data => {
                        var tableBody = document.getElementById('prestataireTable');
                        tableBody.innerHTML = ''; // Réinitialiser le contenu du tableau
                        console.log(data);
                        data.forEach(item => {
                            console.log(item);
                            var row = document.createElement('tr');

                            // Ajouter la cellule pour le nom de l'utilisateur
                            var userCell = document.createElement('td');
                            userCell.textContent = item.lastname + ' ' + item.firstname; // Ajouter le nom complet de l'utilisateur
                            row.appendChild(userCell);

                            // Ajouter la cellule pour le type de prestation
                            var typeCell = document.createElement('td');
                            typeCell.textContent = item.type; // Ajouter le type de prestation
                            row.appendChild(typeCell);

                            // Ajouter la cellule pour le prix de la prestation
                            var priceCell = document.createElement('td');
                            priceCell.textContent = item.price + ' €'; // Ajouter le prix de la prestation
                            row.appendChild(priceCell);

                            // Ajouter la cellule pour la durée de la prestation
                            var durationCell = document.createElement('td');
                            durationCell.textContent = item.duration + ' heures'; // Ajouter la durée de la prestation
                            row.appendChild(durationCell);

                            // Ajouter la cellule pour l'évaluation de la prestation
                            var evaluationCell = document.createElement('td');
                            evaluationCell.textContent = item.evaluation + '/5'; // Ajouter l'évaluation de la prestation
                            row.appendChild(evaluationCell);

                            tableBody.appendChild(row);
                        });
                    });
            });
        });
    </script>

    <?php include 'template/footerAdministration.php'; ?>

</body>

</html>
