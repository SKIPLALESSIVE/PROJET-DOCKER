<?php include 'template/headerAdministration.php'; ?>
<title>PCS - Bailleur - Gestion</title>
</head>

<body id="page-top">
    <!-- Navigation-->
    <?php include 'template/navbarAdministrationLevel.php'; ?>
    <!-- Nav Section -->
    <section class="page-section duckBlueBg" id="navigation">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8 col-xl-6 text-center">
                    <h2 class="mt-0 textLunarWhite">Accueil des pages de gestion</h2>
                    <hr class="divider" />
                    <a href="bienAdministration.php"><button class="btn btn-primary">Bien</button></a>
                    <a href="reclamationAdministration.php"><button class="btn btn-primary">Réclamation</button></a>
                    <hr class="divider" />
                </div>
            </div>
        </div>
    </section>
    <!-- Footer-->
    <?php include '../template/footer.php' ?>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
    <script>
        function responsiveNavBar() {
            document.getElementById("navbarResponsive").classList.toggle("show");
        }
    </script>
</body>

</html>