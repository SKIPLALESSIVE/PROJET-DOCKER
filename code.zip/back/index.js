const mysql = require("mysql");
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const path = require("path");
const fs = require("fs");
const configPath = path.join(__dirname, '..', 'config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
const jsonData = fs.readFileSync("config.json", "utf-8");
const emailData = fs.readFileSync("configEmail.json", "utf-8");
const nodemailer = require("nodemailer");
API_KEY_SECRET = JSON.parse(jsonData).API_KEY_SECRET;
HOST = JSON.parse(emailData).HOST;
SERVICE = JSON.parse(emailData).SERVICE;
EMAIL = JSON.parse(emailData).EMAIL;
PASSWORD = JSON.parse(emailData).PASSWORD;
const { escape } = require("querystring");
const { connect } = require("http2");

const stripe = require("stripe")(API_KEY_SECRET);

const saltRounds = 10;

var transporter = nodemailer.createTransport({
  host: HOST,
  port: 465,
  secure: false,
  service: SERVICE,
  auth: {
    user: EMAIL,
    pass: PASSWORD,
  },
  tls: {
    rejectUnauthorized: false,
  },
});

const connection = mysql.createConnection({
  host: config.host,
  user: config.user,
  password: config.password,
  database: config.database,
});

function generateToken(user, interface) {
  const token = jwt.sign(
    {
      id: user[0].id,
      email: user[0].email,
      role: user[0].role,
      interface: interface,
    },
    config.secretKey,
    {
      expiresIn: "1h",
    }
  );
  return token;
}

app.use(cors({ origin: "http://localhost", methods: "POST" }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//##########################################
//#             PRESTATAIRE                #
//##########################################

app.get("/show_prestataire", (req, res) => {
  let query = `
      SELECT p.*, u.lastname, u.firstname, u.address, u.phone, u.email
      FROM paristakecare_prestataire AS p
      INNER JOIN paristakecare_user AS u ON p.id = u.id
    `;

  connection.query(query, (error, results, _fields) => {
    if (error) {
      console.error("Erreur lors de la requête SQL :", error);
      res.status(500).json({
        message: "Erreur serveur lors de la récupération des prestataires",
      });
      return;
    }

    res.json(results);
  });
});

app.get("/show_prestataire/:id", (req, res) => {
  // Vérifier si le token existe dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Récupérer le token de l'en-tête Authorization
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Récupérer l'ID à partir des paramètres de l'URL
  const id = req.params.id;

  // Vérifier le token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userId = decoded.id;
    const userEmail = decoded.email;
    const userRole = decoded.role;
    const userInterface = decoded.interface;

    if (userInterface != "prestataire") {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
      return;
    }

    // Vérifier si l'utilisateur est administrateur (rôle différent de -1)
    if (userRole !== -1) {
      // L'utilisateur est administrateur, récupérer le prestataire avec l'ID spécifié
      connection.query(
        "SELECT * FROM paristakecare_prestataire WHERE id = ?",
        [id],
        (error, results, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message: "Erreur serveur lors de la récupération du prestataire",
            });
            return;
          }
          res.json(results);
        }
      );
    } else {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
    }
  });
});

app.post("/update_prestataire", (req, res) => {
  // Vérification du token d'authentification
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Vérification de la présence de l'ID de l'utilisateur à mettre à jour
  if (typeof req.body.id === "undefined" || req.body.id === "") {
    res.status(400).json({ message: "Erreur : le paramètre id est requis" });
    return;
  }

  const data = req.body;
  const id = data.id;

  // Extraction du token d'authentification
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérification de la validité du token
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérification du token et des autorisations de l'utilisateur
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Récupération des informations de l'utilisateur à partir du token décodé
    const userId = decoded.id;
    const userEmail = decoded.email;
    const userRole = decoded.role;
    const userInterface = decoded.interface;

    // Vérification des autorisations de l'utilisateur
    if (userInterface !== "prestataire") {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
      return;
    }

    // Vérification supplémentaire des autorisations de l'utilisateur si nécessaire

    // Vérification du rôle de l'utilisateur
    if (userRole !== -1) {
      // Vérification si le champ du mot de passe est vide
      if (!data.password || data.password === "") {
        // Si le mot de passe est vide, supprimer le champ du mot de passe des données à mettre à jour
        delete data.password;

        // Mise à jour de l'utilisateur dans la base de données sans modifier le mot de passe
        connection.query(
          "UPDATE paristakecare_prestataire SET ? WHERE id = ?",
          [data, id],
          (error, _results, _fields) => {
            if (error) {
              console.error("Erreur lors de la requête SQL :", error);
              res.status(500).json({
                message: "Erreur serveur lors de la mise à jour du prestataire",
              });
              return;
            }
            res.json({ message: "Prestataire mis à jour avec succès" });
          }
        );
      } else {
        // Si le mot de passe est fourni, hacher le mot de passe avant de le stocker dans la base de données
        bcrypt.hash(data.password, 10, (err, hash) => {
          if (err) {
            console.error("Erreur lors du hachage du mot de passe :", err);
            res.status(500).json({
              message: "Erreur serveur lors de la mise à jour du prestataire",
            });
            return;
          }
          // Remplacement du mot de passe en clair par le hash dans les données
          data.password = hash;

          // Mise à jour de l'utilisateur dans la base de données
          connection.query(
            "UPDATE paristakecare_prestataire SET ? WHERE id = ?",
            [data, id],
            (error, _results, _fields) => {
              if (error) {
                console.error("Erreur lors de la requête SQL :", error);
                res.status(500).json({
                  message:
                    "Erreur serveur lors de la mise à jour du prestataire",
                });
                return;
              }
              res.json({ message: "Prestataire mis à jour avec succès" });
            }
          );
        });
      }
    } else {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
    }
  });
});

app.get("/show_prestataire_not_validated", (req, res) => {
  const userRole = 5;

  if (userRole !== -1) {
    connection.query(
      "SELECT * FROM paristakecare_prestataire WHERE is_validated = -1",
      (error, prestataires, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur serveur lors de la récupération des prestataires",
          });
          return;
        }

        // Liste pour stocker les résultats finaux
        const results = [];
        prestataires.forEach((prestataire) => {
          connection.query(
            "SELECT * FROM paristakecare_user WHERE id = ?",
            [prestataire.id],
            (error, user, _fields) => {
              if (error) {
                console.error("Erreur lors de la requête SQL :", error);
                res.status(500).json({
                  message:
                    "Erreur serveur lors de la récupération des informations de l'utilisateur",
                });
                return;
              }

              // Ajouter l'utilisateur et le prestataire associé aux résultats
              results.push({ user: user[0], prestataire });

              // Vérifier si c'est la dernière itération
              if (results.length === prestataires.length) {
                // Si oui, envoyer les résultats
                res.json(results);
              }
            }
          );
        });
      }
    );
  } else {
    // Si l'utilisateur n'a pas de rôle valide, renvoyer une erreur ou effectuer une autre action appropriée
    res.status(403).json({
      message: "Accès non autorisé",
    });
  }
});

app.post("/validate_prestataire", (req, res) => {
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  if (typeof req.body.id === "undefined" || req.body.id === "") {
    res.status(400).json({ message: "Erreur : le paramètre id est requis" });
    return;
  }

  // Récupérer le token de l'en-tête Authorization
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Récupérer l'ID à partir des paramètres de l'URL
  const id = req.body.id;
  const userRole = 5;

  // Vérifier le token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userId = decoded.id;
    const userInterface = decoded.interface;

    if (userInterface !== "prestataire") {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
      return;
    }

    if (userRole !== -1) {
      connection.query(
        "UPDATE paristakecare_prestataire SET is_validated = 1 WHERE id = ?",
        [id],
        (error, results, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message: "Erreur serveur lors de la validation du prestataire",
            });
            return;
          }
          // Récupérer l'email du prestataire validé
          connection.query(
            "SELECT email FROM paristakecare_user WHERE id = ?",
            [id],
            (error, userResults, _fields) => {
              if (error) {
                console.error("Erreur lors de la requête SQL :", error);
                res.status(500).json({
                  message:
                    "Erreur serveur lors de la validation du prestataire",
                });
                return;
              }

              const emailPrestataire = userResults[0].email;
              const mailOptions = {
                from: EMAIL,
                to: emailPrestataire,
                subject: "VOTRE COMPTE EST VALIDE",
                text: `Félicitations votre compte est validé, vous pouvez maintenant accéder à votre espace personnel sur ParisTakeCare.`,
              };

              transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                  console.error(error);
                } else {
                  console.log("Email sent: " + info.response);
                }
              });

              res.json({ message: "Prestataire validé avec succès" });
            }
          );
        }
      );
    } else {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
    }
  });
});


app.get("/show_ask_presta", (req, res) => {
  connection.query(
    "SELECT * FROM paristakecare_réserve_presta",
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des demandes",
        });
        return;
      }
      res.json(results);
    }
  );
});

app.get("/show_board_presta", (req, res) => {
  const type_prestation = req.query.type_prestation;
  const date = req.query.date;
  connection.query(
    "SELECT id, type_prestation, price, duration FROM paristakecare_prestataire WHERE type_prestation = ? AND is_validated != -1 AND id IN (SELECT id_prestataire FROM paristakecare_disponibility WHERE FIND_IN_SET(?, REPLACE(REPLACE(disponibility, '$', ','), 'T', ',')) > 0);",
    [type_prestation, date],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des demandes",
        });
        return;
      }
      connection.query(
        "SELECT lastname, firstname FROM paristakecare_user WHERE id = ?",
        [results[0].id],
        (error1, userResults, _fields1) => {
          if (error1) {
            console.error("Erreur lors de la requête SQL pour l'utilisateur :", error1);
            return;
          }
          //ajouter lastname et firstname à presta_tab et envoyer le tout
          let presta_tab = [];
          presta_tab.push(userResults[0]);
          presta_tab.push(results[0]);
          res.json(presta_tab);
        }
      );
    }
  );
});
//add prestation dans la table paristakecare_prestataire
app.post("/add_prestation", (req, res) => {
  const data = req.body;
  const date = req.query.date;
  if (
    typeof data.id_prestataire === "undefined" ||
    typeof data.type_prestation === "undefined" ||
    typeof data.price === "undefined" ||
    typeof data.duration === "undefined"
  ) {
    res.status(400).json({
      message:
        "Erreur : les paramètres id_prestataire, type_prestation, price et duration sont requis",
    });
    return;
  }
  const id_voyageur = req.query.id_voyageur;
  console.log("ID du voyageur :", id_voyageur);
      connection.query(
          "SELECT id_bien FROM paristakecare_reserve WHERE id_voyageur = ?",
          [id_voyageur], // Utiliser id_voyageur au lieu de id_prestataire
          (error, id_bien, _fields) => {
              if (error) {
                  console.error("Erreur lors de la requête SQL :", error);
                  res.status(500).json({
                      message: "Erreur lors de la récupération des disponibilités",
                  });
                  return;
              }
  connection.query(
    "INSERT INTO paristakecare_prestation (id_prestataire, type, price, duration, date, id_bien) VALUES (?, ?, ?, ?, ?, ?)",
    [data.id_prestataire, data.type_prestation, data.price, data.duration, date, id_bien[0].id_bien],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de l'ajout de la prestation",
        });
        return;
      }
      res.json({ message: "Prestation ajoutée avec succès" });
    }
  );
});
});
app.get("/show_prestation_bien", (req, res) => {
  const token = req.query.token; // Récupérer le token depuis la requête

  // Vérifier le token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }
    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    if (typeof req.query.id_voyageur != "undefined") {
      const id_voyageur = req.query.id_voyageur;

  console.log('test api route');
  console.log("ID du voyageur2 :", id_voyageur);

  connection.query(
      "SELECT id_bien FROM paristakecare_reserve WHERE id_voyageur = ?",
      [id_voyageur],
      (error, results, _fields) => {
          if (error) {
              console.error("Erreur lors de la requête SQL :", error);
              res.status(500).json({
                  message: "Erreur lors de la récupération des disponibilités",
              });
              return;
          }
          console.log(results);

          if (results.length === 0) {
              res.json([]);
              return;
          }

          const id_bien = results[0].id_bien;
          console.log("ID du bien :", id_bien);

          connection.query(
              "SELECT * FROM paristakecare_prestation WHERE id_bien = ?",
              [id_bien],
              (error, results, _fields) => {
                  if (error) {
                      console.error("Erreur lors de la requête SQL :", error);
                      res.status(500).json({
                          message: "Erreur serveur lors de la récupération des prestations",
                      });
                      return;
                  }
                  console.log(results);
                  let events = [];
                  results.forEach(result => {
                      events.push({
                          title: "Prestation :" + result.type,
                          start: result.date,
                          end: result.date,
                          color: "yellow",
                          textColor: "white",
                      });
                  });
                  console.log(events);
                  res.json(events);
              }
          );
      }
  );
}
});
});

//##########################################
//#             DISPONIBILITE              #
//##########################################

// Route pour récupérer les disponibilités depuis la base de données
app.get("/get_disponibilities", (req, res) => {
  const token = req.query.token; // Récupérer le token depuis la requête

  // Vérifier le token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }
    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const id_prestataire = decoded.id;

    // Effectuer une requête SQL pour récupérer les disponibilités depuis la base de données
    connection.query(
      "SELECT disponibility FROM paristakecare_disponibility WHERE id_prestataire = ?",
      [id_prestataire],
      (error, results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur lors de la récupération des disponibilités",
          });
          return;
        }
        // Initialiser un tableau pour stocker les événements
        let events = [];

        // Parcourir chaque entrée de disponibilité
        results.forEach((row) => {
          // Séparer les dates en utilisant le délimiteur $
          const dates = row.disponibility.split("$");

          // Pour chaque date, créer un événement et l'ajouter au tableau d'événements
          dates.forEach((date) => {
            // Formater la date pour qu'elle soit compatible avec FullCalendar (ISO 8601)
            const formattedDate = new Date(date).toISOString();
            events.push({
              title: "Disponible",
              start: formattedDate,
              color: "green", // Couleur de fond de l'événement
              textColor: "white", // Couleur du texte de l'événement
            });
          });
        });

        // Renvoyer les événements au client
        res.json(events);
      }
    );
  });
});

app.post("/add_disponibility", (req, res) => {
  const data = req.body;
  const token = data.token;
  const date = data.date;
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }
    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const id = decoded.id;

    connection.query(
      "SELECT * FROM paristakecare_disponibility WHERE id_prestataire = ?",
      [id],
      (error, results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur lors de la récupération de la disponibilité",
          });
          return;
        }

        if (results.length === 0) {
          // Aucune disponibilité trouvée, nous devons l'insérer pour ce prestataire
          connection.query(
            "INSERT INTO paristakecare_disponibility (id_prestataire, disponibility) VALUES (?, ?)",
            [id, date],
            (error, _insertResults, _insertFields) => {
              if (error) {
                console.error(
                  "Erreur lors de l'insertion de la disponibilité :",
                  error
                );
                res
                  .status(500)
                  .json({ message: "Erreur lors de l'ajout de la date" });
                return;
              }
              res.writeHead(302, {
                Location: `http://localhost/2A3-EJH-PA/calendrier_presta.php`,
              });
              res.end();
            }
          );
          return;
        }

        const allDates = results[0].disponibility;
        const isDateInAllDates = allDates.split("-").includes(date);

        if (isDateInAllDates) {
          res.status(409).json({ message: "La date est déjà ajoutée" });
          return;
        }

        const newAllDates = [...allDates.split("$"), date].join("$");
        connection.query(
          "UPDATE paristakecare_disponibility SET disponibility = ? WHERE id_prestataire = ?",
          [newAllDates, id],
          (error, _updateResults, _updateFields) => {
            if (error) {
              console.error(
                "Erreur lors de la mise à jour de la disponibilité :",
                error
              );
              res
                .status(500)
                .json({ message: "Erreur lors de l'ajout de la date" });
              return;
            }
            res.writeHead(302, {
              Location: `http://localhost/2A3-EJH-PA/calendrier_presta.php`,
            });
            res.end();
          }
        );
      }
    );
  });
});

//##########################################
//#              PRESTATION                #
//##########################################

app.post("/show_prestation", (req, res) => {
  data = req.body;
  userId = data.id;
  var interfaceVal = data.interface;

  connection.query(
    "SELECT * FROM paristakecare_prestation WHERE id_taker = ? AND interface = ?",
    [userId, interfaceVal],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des prestations",
        });
        return;
      }
      res.json(results);
    }
  );
});

app.get("/show_type_prestation", (req, res) => {
  connection.query(
    "SELECT DISTINCT type_prestation FROM paristakecare_prestataire",
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des prestations",
        });
        return;
      }
      res.json(results);
    }
  );
});

app.post("/add_type_presta", async (req, res) => {
  const data = req.body;
  const id = data.id;
  const type = data.type;
  const price = data.price;

  connection.query(
    "SELECT all_id FROM paristakecare_type_presta WHERE type_prestation = ?",
    [type],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res
          .status(500)
          .json({ message: "Erreur lors de la récupération du all_id" });
        return;
      }

      if (results.length === 0) {
        res.status(404).json({ message: "Prestation inexistante" });
        return;
      }
      let allIds = results[0].all_id || ""; // Assurez-vous que allIds a une valeur par défaut

      // Parse la chaîne allIds et crée un objet pour simplifier la gestion des identifiants et des prix
      const allIdsObj = {};
      if (allIds) {
        allIds.split(".").forEach((entry) => {
          const [entryId, entryPrice] = entry.split(":");
          if (entryId && entryPrice) {
            allIdsObj[entryId] = entryPrice;
          }
        });
      }

      // Vérifie si l'utilisateur a déjà accès à cette prestation
      if (id in allIdsObj) {
        res
          .status(409)
          .json({ message: "L'utilisateur a déjà accès à cette prestation" });
        return;
      }

      // Ajoute l'utilisateur à la prestation avec son prix
      allIdsObj[id] = price;

      // Re-construit la chaîne allIds à partir de l'objet
      const newAllIds = Object.entries(allIdsObj)
        .map(([entryId, entryPrice]) => `${entryId}:${entryPrice}`)
        .join(".");

      // Ajoute un point à la fin de la chaîne s'il y a des identifiants
      const finalAllIds = newAllIds ? newAllIds + "." : "";

      connection.query(
        "UPDATE paristakecare_type_presta SET all_id = ? WHERE type_prestation = ?",
        [finalAllIds, type],
        (error, _updateResults, _updateFields) => {
          if (error) {
            console.error("Erreur lors de la mise à jour du all_id :", error);
            res.status(500).json({
              message:
                "Erreur lors de l'ajout de l'utilisateur à la prestation",
            });
            return;
          }

          res.status(200).json({
            message: "Prestation ajoutée avec succès à l'utilisateur",
          });
        }
      );
    }
  );
});

app.get("/show_prestation/:id", (req, res) => {
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Récupérer le token de l'en-tête Authorization
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Récupérer l'ID à partir des paramètres de l'URL
  const id = req.params.id;

  // Vérifier le token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userId = decoded.id;
    const userEmail = decoded.email;
    const userRole = decoded.role;
    const userInterface = decoded.interface;

    if (userInterface != "prestataire") {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
      return;
    }

    // Vérifier si l'utilisateur est administrateur (rôle différent de -1)
    if (userRole !== -1) {
      // L'utilisateur est administrateur, récupérer la prestation avec l'ID spécifié
      connection.query(
        "SELECT * FROM paristakecare_prestation WHERE id = ?",
        [id],
        (error, results, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message:
                "Erreur serveur lors de la récupération de la prestation",
            });
            return;
          }
          res.json(results);
        }
      );
    } else {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
    }
  });
});

app.post("/add_prestation", (req, res) => {
  const data = req.body;
  if (
    typeof data.id_prestataire === "undefined" ||
    typeof data.id_taker === "undefined" ||
    typeof data.id_bien === "undefined" ||
    typeof data.type === "undefined" ||
    typeof data.date === "undefined" ||
    typeof data.duration === "undefined" ||
    typeof data.prix === "undefined" ||
    typeof data.interface === "undefined" ||
    data.id_prestataire === "" ||
    data.id_taker === "" ||
    data.id_bien === "" ||
    data.type === "" ||
    data.date === "" ||
    data.duration === "" ||
    data.prix === "" ||
    data.interface === ""
  ) {
    res.status(400).json({
      message:
        "Erreur : les paramètres id_prestataire, id_taker, id_bien, type, date, duration et price sont requis",
    });
    return;
  } else {
    connection.query(
      "INSERT INTO paristakecare_prestation (id_prestataire, id_taker, id_bien, type, date, duration, price, interface) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      [
        data.id_prestataire,
        data.id_taker,
        data.id_bien,
        data.type,
        data.date,
        data.duration,
        data.prix,
        data.interface,
      ],
      (error, results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur serveur lors de l'ajout de la prestation",
          });
          return;
        }
        // Récupérer l'ID de la prestation nouvellement insérée
        const prestationId = results.insertId;

        // Rediriger l'utilisateur vers la page de paiement avec l'ID et le prix
        res.writeHead(302, {
          Location: `http://localhost/2A3-EJH-PA/voyageur/pay.php?prix=${data.prix}&id=${prestationId}`,
        });
        res.end();
      }
    );
  }
});

function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
app.post("/validated_payements", (req, res) => {
  const id = parseInt(req.body.id, 10);
  const type = req.body.type;
  const date = new Date();
  const formattedDate = formatDate(date);

  if (type === "prestation") {
    connection.query(
      "UPDATE paristakecare_prestation SET is_paid = 1 WHERE id = ?",
      [id],
      (error, _results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur serveur lors de la validation de la prestation",
          });
          return;
        }
        res.json({ message: "Prestation validée avec succès" });
      }
    );
  } else if (type === "reservation") {
    connection.query(
      "UPDATE paristakecare_reserve SET is_paid = 1, is_validated = 1 WHERE id = ?",
      [id],
      (error, _results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur serveur lors de la validation de la réservation",
          });
          return;
        }

        res.json({ message: "Réservation validée avec succès" });
      }
    );
  } else if (type === "subscription") {
    connection.query(
      "UPDATE paristakecare_bien SET subscription_paid = 1, subscription_date = ?, is_validated = 1 WHERE id = ?",
      [formattedDate, id],
      (error, _results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur serveur lors de la validation de la réservation",
          });
          return;
        }
        res.json({ message: "Subscription payée validée avec succès" });
      }
    );
  } else {
    res.status(400).json({ message: "Type de paiement non valide" });
  }
});

app.post("/delete_voyageur", (req, res) => {
  const id = req.body.id;

  connection.query(
    "SELECT COUNT(*) AS count FROM paristakecare_bailleur WHERE id = ?",
    [id],
    (error, bailleurResults, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la vérification de l'existence du bailleur",
        });
        return;
      }


      connection.query(
        "SELECT COUNT(*) AS count FROM paristakecare_prestataire WHERE id = ?",
        [id],
        (error, prestataireResults, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message: "Erreur serveur lors de la vérification de l'existence du prestataire",
            });
            return;
          }           
              connection.query(
                "DELETE FROM paristakecare_voyageur WHERE id = ?",
                [id],
                (error, deleteVoyageurResults, _fields) => {
                  if (error) {
                    console.error("Erreur lors de la requête SQL :", error);
                    res.status(500).json({
                      message: "Erreur serveur lors de la suppression du voyageur",
                    });
                    return;
                  }

                
                  if (bailleurResults[0].count === 0 && prestataireResults[0].count === 0) {
                    connection.query(
                      "DELETE FROM paristakecare_user WHERE id = ?",
                      [id],
                      (error, deleteUserResults, _fields) => {
                        if (error) {
                          console.error("Erreur lors de la requête SQL :", error);
                          res.status(500).json({
                            message: "Erreur serveur lors de la suppression de l'utilisateur",
                          });
                          return;
                        }
                        res.json({ message: "Voyageur et utilisateur supprimés avec succès" });
                      }
                    );
                  } else {
                    res.json({ message: "Voyageur supprimé avec succès" });
                  }
                }
              );
            }
          );
        }
      );
    }
  );



app.post("/delete_prestataire", (req, res) => {
  const id = req.body.id;


  connection.query(
    "SELECT COUNT(*) AS count FROM paristakecare_bailleur WHERE id = ?",
    [id],
    (error, bailleurResults, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la vérification de l'existence du bailleur",
        });
        return;
      }

   
      connection.query(
        "SELECT COUNT(*) AS count FROM paristakecare_voyageur WHERE id = ?",
        [id],
        (error, voyageurResults, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message: "Erreur serveur lors de la vérification de l'existence du voyageur",
            });
            return;
          }
             
              connection.query(
                "DELETE FROM paristakecare_prestataire WHERE id = ?",
                [id],
                (error, deletePrestataireResults, _fields) => {
                  if (error) {
                    console.error("Erreur lors de la requête SQL :", error);
                    res.status(500).json({
                      message: "Erreur serveur lors de la suppression du prestataire",
                    });
                    return;
                  }

                 
                  if (bailleurResults[0].count === 0 && voyageurResults[0].count === 0) {
                    connection.query(
                      "DELETE FROM paristakecare_user WHERE id = ?",
                      [id],
                      (error, deleteUserResults, _fields) => {
                        if (error) {
                          console.error("Erreur lors de la requête SQL :", error);
                          res.status(500).json({
                            message: "Erreur serveur lors de la suppression de l'utilisateur",
                          });
                          return;
                        }
                        res.json({ message: "Prestataire et utilisateur supprimés avec succès" });
                      }
                    );
                  } else {
                    res.json({ message: "Prestataire supprimé avec succès" });
                  }
                }
              );
            }
          );
        }
      );
    }
  );



app.post("/delete_bailleur", (req, res) => {
  const id = req.body.id;

 
  connection.query(
    "SELECT COUNT(*) AS count FROM paristakecare_prestataire WHERE id = ?",
    [id],
    (error, prestataireResults, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la vérification de l'existence du prestataire",
        });
        return;
      }

      
      connection.query(
        "SELECT COUNT(*) AS count FROM paristakecare_voyageur WHERE id = ?",
        [id],
        (error, voyageurResults, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message: "Erreur serveur lors de la vérification de l'existence du voyageur",
            });
            return;
          }

              connection.query(
                "DELETE FROM paristakecare_bailleur WHERE id = ?",
                [id],
                (error, deleteBailleurResults, _fields) => {
                  if (error) {
                    console.error("Erreur lors de la requête SQL :", error);
                    res.status(500).json({
                      message: "Erreur serveur lors de la suppression du bailleur",
                    });
                    return;
                  }

                  if (prestataireResults[0].count === 0 && voyageurResults[0].count === 0 ) {
                    connection.query(
                      "DELETE FROM paristakecare_user WHERE id = ?",
                      [id],
                      (error, deleteUserResults, _fields) => {
                        if (error) {
                          console.error("Erreur lors de la requête SQL :", error);
                          res.status(500).json({
                            message: "Erreur serveur lors de la suppression de l'utilisateur",
                          });
                          return;
                        }
                        res.json({ message: "Bailleur et utilisateur supprimés avec succès" });
                      }
                    );
                  } else {
                    res.json({ message: "Bailleur supprimé avec succès" });
                  }
                }
              );
            }
          );
        }
      );
    }
  );

  

app.post("/user_all_reservation", (req, res) => {
  const id = req.body.id;
  connection.query(
    "SELECT * FROM paristakecare_reserve WHERE id_voyageur = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des réservations",
        });
        return;
      }
      res.json(results);
    }
  );
});

app.post("/afficher_presta_dates", (req, res) => {
  const { datePrestation, prestationSelectionnee } = req.body;
  console.log("Date de prestation :", datePrestation);
  console.log("Prestation sélectionnée :", prestationSelectionnee);

  connection.query(
    "SELECT all_id FROM paristakecare_type_presta WHERE type_prestation = ?",
    [prestationSelectionnee],
    (error, results) => {
      if (error) {
        console.error("Erreur lors de l'exécution de la requête :", error);
        res
          .status(500)
          .json({ message: "Erreur lors de l'exécution de la requête SQL" });
      } else {
        // Récupération des IDs des prestataires
        const prestatairesIds = results.map((result) => result.all_id);
        const ids = [];
        prestatairesIds.forEach((prestataireIds) => {
          const pairs = prestataireIds.split(".");
          pairs.forEach((pair) => {
            const [id, prix] = pair.split(":");
            if (id && id.length > 0) {
              // Exclusion des IDs vides
              const idInt = parseInt(id);
              ids.push(idInt);
              console.log("ID prestataire :", idInt);
            }
          });
        });

        const placeholders = ids.map((id) => "?").join(", ");

        // Construction de la requête SQL avec la clause IN dynamique
        const sqlQuery = `
          SELECT * FROM paristakecare_disponibility 
          WHERE id_prestataire IN (${placeholders}) 
          AND disponibility = ? 
          AND id_prestataire IN (SELECT id_prestataire FROM paristakecare_disponibility)
        `;

        const queryArgs = [...ids, datePrestation];
        console.log(queryArgs);
        connection.query(sqlQuery, queryArgs, (error, disponibilities) => {
          if (error) {
            console.error(
              "Erreur lors de l'exécution de la requête SQL pour récupérer les disponibilités :",
              error
            );
            res.status(500).json({
              message:
                "Erreur lors de l'exécution de la requête SQL pour récupérer les disponibilités",
            });
          } else {
            console.log("Disponibilités trouvées :", disponibilities);
            const disponibiliteFiltree = disponibilities.map(
              (disponibilite) => {
                return {
                  id: disponibilite.id_prestataire,
                  prix: disponibilite.prix,
                };
              }
            );

            res.status(200).json({ disponibilities: disponibiliteFiltree });
          }
        });
      }
    }
  );
});

app.post("/all_reservations", (req, res) => {
  connection.query(
    "SELECT * FROM paristakecare_reserve",
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des réservations",
        });
        return;
      }
      res.json(results);
    }
  );
});

app.post("/delete_reservation", (req, res) => {
  const id = req.body.id;

  connection.query(
    "DELETE FROM paristakecare_reserve WHERE id = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la suppression de la réservation",
        });
        return;
      }
      res.json({ message: "Réservation supprimée avec succès" });
    }
  );
});

app.post("/validate_reservation", (req, res) => {
  const id = req.body.id;
  connection.query(
    "UPDATE paristakecare_reserve SET is_validated = 1 WHERE id = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la validation de la réservation",
        });
        return;
      }
      res.json({ message: "Réservation validée avec succès" });
    }
  );
});

app.post("/all_voyageurs", (req, res) => {
  connection.query(
    "SELECT * FROM paristakecare_voyageur",
    (error, voyageurResults, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des voyageurs",
        });
        return;
      }

      // Liste pour stocker les résultats finaux
      const results = [];

      voyageurResults.forEach((voyageur) => {
        connection.query(
          "SELECT * FROM paristakecare_user WHERE id = ?",
          [voyageur.id],
          (error, userResults, _fields) => {
            if (error) {
              console.error("Erreur lors de la requête SQL :", error);
              res.status(500).json({
                message:
                  "Erreur serveur lors de la récupération des informations de l'utilisateur",
              });
              return;
            }

            results.push({ user: userResults[0], voyageur });

            if (results.length === voyageurResults.length) {
              res.json(results);
            }
          }
        );
      });
    }
  );
});

app.post("/delete_voyageur", (req, res) => {
  const id = req.body.id;

  connection.query(
    "DELETE FROM paristakecare_voyageur WHERE id = ?",
    [id],
    (error, _results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la suppression du voyageur",
        });
        return;
      }

      connection.query(
        "SELECT * FROM paristakecare_bailleur WHERE id = ?",
        [id],
        (error, bailleurResults, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message: "Erreur serveur lors de la vérification du bailleur",
            });
            return;
          }

          // Vérifier si le prestataire est également un voyageur
          connection.query(
            "SELECT * FROM paristakecare_prestataire WHERE id = ?",
            [id],
            (error, prestataireResults, _fields) => {
              if (error) {
                console.error("Erreur lors de la requête SQL :", error);
                res.status(500).json({
                  message: "Erreur serveur lors de la vérification du voyageur",
                });
                return;
              }
              if (
                bailleurResults.length === 0 &&
                prestataireResults.length === 0
              ) {
                connection.query(
                  "DELETE FROM paristakecare_user WHERE id = ?",
                  [id],
                  (error, _results, _fields) => {
                    if (error) {
                      console.error("Erreur lors de la requête SQL :", error);
                      res.status(500).json({
                        message:
                          "Erreur serveur lors de la suppression de l'utilisateur",
                      });
                      return;
                    }
                    res.json({ message: "Prestataire supprimé avec succès" });
                  }
                );
              } else {
                res.status(400).json({
                  message:
                    "Ce prestataire est également un bailleur ou un voyageur, il ne peut pas être supprimé",
                });
              }
            }
          );
        }
      );
    }
  );
});

app.post("/facturation_presta", (req, res) => {
  const id = req.body.id;
  connection.query(
    "SELECT * FROM paristakecare_prestation WHERE id_prestataire = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des prestations",
        });
        return;
      }
      res.json(results);
    }
  );
});
//##########################################
//#              BAILLEURS                 #
//##########################################

app.get("/show_bailleur", (req, res) => {
  let query = `
    SELECT p.*, u.lastname, u.firstname, u.address, u.phone, u.email
    FROM paristakecare_bailleur AS p
    INNER JOIN paristakecare_user AS u ON p.id = u.id
  `;

  connection.query(query, (error, results, fields) => {
    if (error) {
      console.error("Erreur lors de la requête SQL :", error);
      res.status(500).json({
        message: "Erreur serveur lors de la récupération des bailleurs",
      });
      return;
    }

    res.json(results);
  });
});

  
app.get("/show_bailleur/:id", (req, res) => {
  // Vérifier si le token existe dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Récupérer le token de l'en-tête Authorization
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Récupérer l'ID à partir des paramètres de l'URL
  const id = req.params.id;

  // Vérifier le token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userId = decoded.id;
    const userEmail = decoded.email;
    const userRole = decoded.role;
    const userInterface = decoded.interface;

    if (userInterface != "bailleur") {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
      return;
    }

    // Vérifier si l'utilisateur est administrateur (rôle différent de -1)
    if (userRole !== -1) {
      // L'utilisateur est administrateur, récupérer la prestation avec l'ID spécifié
      connection.query(
        "SELECT * FROM paristakecare_bailleur WHERE id = ?",
        [id],
        (error, results, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message:
                "Erreur serveur lors de la récupération de la prestation",
            });
            return;
          }
          res.json(results);
        }
      );
    } else {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
    }
  });
});

//##########################################
//#                 BIEN                   #
//##########################################



app.post("/show_bien", (req, res) => {
  const id = req.body.id;
  connection.query(
    "SELECT * FROM paristakecare_bien WHERE id = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de la récupération du bien",
        });
      }
      res.json(results);
    }
  );
});

app.get("/show_all_biens", (req, res) => {
  connection.query(
    "SELECT * FROM paristakecare_bien WHERE is_validated = 1",
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de la récupération des biens",
        });
      }

      const queryResults = [];

      let completedRequests = 0; // Compteur pour suivre les requêtes terminées
      console.log(results); 
      results.forEach((result, index) => {
        console.log("Résultat :", result.id); 
        connection.query(
          "SELECT note FROM paristakecare_reserve WHERE id_bien = ?",
          [result.id],
          (error, notes, _fields) => {
            completedRequests++; // Incrémenter le compteur des requêtes terminées

            if (error) {
              console.error("Erreur lors de la requête SQL pour les notes :", error);
              return res.status(500).json({
                message: "Erreur serveur lors de la récupération des notes",
              });
            }

            let sumnotes = 0;
            for (let i = 0; i < notes.length; i++) {
              sumnotes += notes[i].note;
            }

            const average = notes.length > 0 ? sumnotes / notes.length : 0;
            console.log("Moyenne :", average);
            queryResults.push({ bien: result, moyenne: average });

            if (completedRequests === results.length ) {
              res.json(queryResults);
            }
          }
        );
      });
    }
  );
});


app.get("/show_bien_admin", (req, res) => {
  const id = req.body.id;
  connection.query(
    "SELECT * FROM paristakecare_bien WHERE is_validated = 0",
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de la récupération du bien",
        });
      }
      res.json(results);
    }
  );
});

app.post("/show_bien_bailleur", (req, res) => {
  const id = req.body.id;
  connection.query(
    "SELECT * FROM paristakecare_bien WHERE id_bailleur = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de la récupération du bien",
        });
      }

      const queryResults = [];

      let completedRequests = 0; // Compteur pour suivre les requêtes terminées

      
      results.forEach((result, index) => {
        
        connection.query(
          "SELECT note FROM paristakecare_reserve WHERE id_bien = ?",
          [result.id],
          (error, notes, _fields) => {
            completedRequests++; // Incrémenter le compteur des requêtes terminées

            if (error) {
              console.error("Erreur lors de la requête SQL pour les notes :", error);
              return res.status(500).json({
                message: "Erreur serveur lors de la récupération des notes",
              });
            }
            console.log("Notes :", notes);

            let sumNotes = 0;
            for (let i = 0; i < notes.length; i++) {
              sumNotes += notes[i].note;
            }

            const average = notes.length > 0 ? sumNotes / notes.length : 0; 

            queryResults.push({ bien: result, moyenne: average });

            if (completedRequests === results.length) {
              res.json(queryResults);
            }
          }
        );
      });
    }
  );
});


app.get("/show_all_bien", (req, res) => {
  connection.query(
    "SELECT * FROM paristakecare_bien",
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de la récupération des biens",
        });
      }

      const queryResults = [];

      let completedRequests = 0; // Compteur pour suivre les requêtes terminées

      results.forEach((result, index) => {
        connection.query(
          "SELECT note FROM paristakecare_reserve WHERE id_bien = ?",
          [result.id_bien],
          (error, notes, _fields) => {
            completedRequests++; // Incrémenter le compteur des requêtes terminées

            if (error) {
              console.error("Erreur lors de la requête SQL pour les notes :", error);
              return res.status(500).json({
                message: "Erreur serveur lors de la récupération des notes",
              });
            }

            let sumNotes = 0;
            for (let i = 0; i < notes.length; i++) {
              sumNotes += notes[i].note;
            }

            const average = notes.length > 0 ? sumNotes / notes.length : 0;

            queryResults.push({ bien: result, moyenne: average });

            if (completedRequests === results.length) {
              res.json(queryResults);
            }
          }
        );
      });
    }
  );
});


app.post("/add_bien", (req, res) => {
  const data = req.body;
  console.log(data);
  var id_bailleur = data.userId;
  var type_gestion = data.type_gestion;
  var type_bien = data.type;
  var adresse = data.adresse;

  var pays = data.land;
  if (pays == null) {
    pays = "FR";
  }
  var price = parseInt(data.prix, 10);
  var location_type = data.location;
  var nb_chambres = data.chambres;
  var capacite = parseInt(data.capacite, 10);
  const is_validated = 0;
  const subscription_paid = 0;

  connection.query(
    "INSERT INTO paristakecare_bien (id_bailleur, is_validated, subscription_paid, land, bien_type, location_type, address, chambers_nb, occupants_nb, price, id_docs) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    [
      id_bailleur,
      is_validated,
      subscription_paid,
      pays,
      type_bien,
      type_gestion,
      adresse,
      nb_chambres,
      capacite,
      price,
      id_bailleur,
    ],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de l'ajout du bien",
        });
      }
      res.json({ message: "Bien ajouté avec succès" });
    }
  );
});

app.post("/validate_bien", (req, res) => { 
  data = req.body;
  const id = data.id;
  connection.query(
    "UPDATE paristakecare_bien SET is_validated = 1 WHERE id = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de la validation du bien",
        });
      }
      res.json({ message: "Bien validé avec succès" });
    }
  );
});


app.get("/show_calendar_bien", (req, res) => {
  const token = req.query.token; // Récupérer le token depuis la requête

  // Vérifier le token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }
    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    if (typeof req.query.id_voyageur != "undefined") {
      const id_voyageur = req.query.id_voyageur;

      // Effectuer une requête SQL pour récupérer les disponibilités depuis la base de données
      connection.query(
        "SELECT id_bien, start_date, end_date FROM paristakecare_reserve WHERE id_voyageur = ?",
        [id_voyageur], // Utiliser id_voyageur au lieu de id_prestataire
        (error, results, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message: "Erreur lors de la récupération des disponibilités",
            });
            return;
          }
          // Initialiser un tableau pour stocker les événements
          let events = [];

          //recuperer l'id du bien qui correspond à la date actuelle et à l'id du voyageur
          let id_bien; // Déclarer la variable id_bien ici
          for (let i = 0; i < results.length; i++) {
            if (
              new Date(results[i].start_date) <= new Date() &&
              new Date(results[i].end_date) >= new Date()
            ) {
              id_bien = results[i].id_bien;
            }
          }

          // Effectuer une requête SQL pour récupérer les disponibilités depuis la base de données
          connection.query(
            "SELECT start_date, end_date FROM paristakecare_reserve WHERE id_bien = ?",
            [id_bien],
            (error, results, _fields) => {
              if (error) {
                console.error("Erreur lors de la requête SQL :", error);
                res.status(500).json({
                  message: "Erreur lors de la récupération des disponibilités",
                });
                return;
              }

              // Parcourir chaque entrée de disponibilité
              results.forEach((row) => {
                // Séparer les dates en utilisant le délimiteur $
                const start_date = new Date(row.start_date);
                const end_date = new Date(row.end_date);

                // Générer les dates entre start_date et end_date
                const currentDate = new Date(start_date);
                while (currentDate <= end_date) {
                  // Formater la date pour qu'elle soit compatible avec FullCalendar (ISO 8601)
                  const formattedDate = currentDate.toISOString();

                  // Ajouter l'événement au tableau d'événements
                  events.push({
                    title: "Réservation en cours",
                    start: formattedDate,
                    color: "red", // Couleur de fond de l'événement
                    textColor: "white", // Couleur du texte de l'événement
                  });

                  // Passer à la prochaine date
                  currentDate.setDate(currentDate.getDate() + 1);
                }
              });

              // Renvoyer les événements au client
              res.json(events);
            }
          );
        }
      );
    } else {
      const id_bien = req.query.id_bien;

      // Effectuer une requête SQL pour récupérer les disponibilités depuis la base de données
      connection.query(
        "SELECT start_date, end_date FROM paristakecare_reserve WHERE id_bien = ?",
        [id_bien],
        (error, results, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res.status(500).json({
              message: "Erreur lors de la récupération des disponibilités",
            });
            return;
          }

          // Initialiser un tableau pour stocker les événements
          let events = [];

          // Parcourir chaque entrée de disponibilité
          results.forEach((row) => {
            // Séparer les dates en utilisant le délimiteur $
            const start_date = new Date(row.start_date);
            const end_date = new Date(row.end_date);

            // Générer les dates entre start_date et end_date
            const currentDate = new Date(start_date);
            while (currentDate <= end_date) {
              // Formater la date pour qu'elle soit compatible avec FullCalendar (ISO 8601)
              const formattedDate = currentDate.toISOString();

              // Ajouter l'événement au tableau d'événements
              events.push({
                title: "Réservation en cours",
                start: formattedDate,
                color: "red", // Couleur de fond de l'événement
                textColor: "white", // Couleur du texte de l'événement
              });

              // Passer à la prochaine date
              currentDate.setDate(currentDate.getDate() + 1);
            }
          });

          // Renvoyer les événements au client
          res.json(events);
        }
      );
    }
  });
});

//##########################################
//#              VOYAGEURS                 #
//##########################################


app.post("/user_abonnement", (req, res) => {
  const data = req.body;
  const id = data.id;

  connection.query(
    "SELECT * FROM paristakecare_voyageur WHERE id = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des réservations",
        });
        return;
      }

      if (results.length === 0) {
        res.status(404).json({
          message: "Aucune réservation trouvée pour cet utilisateur",
        });
        return;
      }

      res.json(results);
    }
  );
});

app.post("/show_reservation_voyageur", (req, res) => {
  const data = req.body;
 
  const id = data.id;


  connection.query(
    "SELECT * FROM paristakecare_reserve WHERE id_voyageur = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des réservations",
        });
        return;
      }

      if (results.length === 0) {
        res.status(404).json({
          message: "Aucune réservation trouvée pour cet utilisateur",
        });
        return;
      }
      console.log(results);
      res.json(results);
    }
  );
});
app.post("/show_reservation_voyageur_android", (req, res) => {
  const data = req.body;
  const id = data.id;

  connection.query(
    "SELECT * FROM paristakecare_reserve WHERE id_voyageur = ?",
    [id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des réservations",
        });
        return;
      }

      if (results.length === 0) {
        res.status(404).json({
          message: "Aucune réservation trouvée pour cet utilisateur",
        });
        return;
      }

      console.log(results);
      res.json({ data: results });
    }
  );
});

app.get("/recup_token_voyageur", (req, res) => {
  // Vérifier si le token est présent dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérifier la validité du token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    const userEmail = decoded.email;
    const userInterface = decoded.interface;
    connection.query(
      "SELECT id FROM paristakecare_user WHERE email = ?",
      [userEmail],
      (error, results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message:
              "Erreur lors de la récupération de l'identifiant de l'utilisateur",
          });
          return;
        }
        if (results.length === 0) {
          res.status(404).json({ message: "Utilisateur inexistant" });
          return;
        }

        const userId = results[0].id;

        connection.query(
          "SELECT is_vip FROM paristakecare_voyageur WHERE id = ?",
          [userId],
          (error, voyageurResults, _fields) => {
            if (error) {
              console.error("Erreur lors de la requête SQL :", error);
              res.status(500).json({
                message:
                  "Erreur lors de la récupération du rôle du prestataire",
              });
              return;
            }
            if (voyageurResults.length === 0) {
              res.status(404).json({
                message: "Utilisateur inexistant en tant que prestataire",
              });
              return;
            }

            const is_vip = voyageurResults[0].is_vip;

            const data_return = {
              token: token,
              id: userId,
              email: userEmail,
              interface: userInterface,
              is_vip: is_vip,
            };
            res.json(data_return);
          }
        );
      }
    );
  });
});

app.post("/send_resa", (req, res) => {
  var { start_date, end_date, user_id, id_bien, price, nb_personnes } = req.body;
  const is_paid = 0;
  const is_validated = 0;
  user_id = parseInt(user_id, 10);
  nb_personnes = parseInt(nb_personnes, 10);
  
  const startDate = new Date(start_date);
  const endDate = new Date(end_date);
  const currentDate = new Date();

  if (startDate < currentDate) {
    return res.status(400).json({
      message: "La date de début ne peut pas être dans le passé",
    });
  }


  if (endDate <= startDate) {
    return res.status(400).json({
      message: "La date de fin doit être supérieure à la date de début",
    });
  }

  const nb_nuits = (endDate - startDate) / (1000 * 60 * 60 * 24);

  connection.query(
    "SELECT * FROM paristakecare_reserve WHERE id_bien = ? AND ((start_date >= ? AND start_date < ?) OR (end_date > ? AND end_date <= ?))",
    [id_bien, start_date, end_date, start_date, end_date],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de la vérification des réservations",
        });
      }
      if (results.length > 0) {
        return res.status(400).json({
          message: "Ce bien est déjà réservé pour la période spécifiée",
        });
      }
      connection.query(
        "INSERT INTO paristakecare_reserve (id_voyageur, nb_personnes, id_bien, start_date, end_date, is_validated, price, is_paid) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [
          user_id,
          nb_personnes,
          id_bien,
          start_date,
          end_date,
          is_validated,
          price,
          is_paid,
        ],
        (error, _insertResults, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            return res.status(500).json({
              message: "Erreur serveur lors de l'ajout de la réservation",
            });
          }

          connection.query(
            "SELECT LAST_INSERT_ID() as id",
            (error, results, _fields) => {
              if (error) {
                console.error("Erreur lors de la requête SQL :", error);
                return res.status(500).json({
                  message:
                    "Erreur serveur lors de la récupération de l'ID de la réservation",
                });
              }
              const insertedId = results[0].id;
              return res.status(200).json({
                message: "Réservation ajoutée avec succès",
                id: insertedId,
                nb_nuits: nb_nuits 
              });
            }
          );
        }
      );
    }
  );
});

//##########################################
//#               TICKETING                #
//##########################################

app.post("/login_ticketing", (req, res) => {
  const data = req.body;

  // Vérification des champs requis
  if (
    typeof data.email === "undefined" ||
    typeof data.password === "undefined" ||
    data.email === "" ||
    data.password === ""
  ) {
    res.status(400).json({
      message: "Erreur : les paramètres email et password sont requis",
    });
    return;
  }

  // Vérification de l'email
  if (data.email.indexOf("@") === -1) {
    res.status(400).json({ message: "Adresse email invalide" });
    return;
  }

  // Vérification de la longueur du mot de passe
  if (data.password.length < 8) {
    res.status(400).json({
      message: "Le mot de passe doit contenir au moins 8 caractères",
    });
    return;
  }

  // Conversion de l'email en minuscules
  data.email = data.email.toLowerCase();

  // Recherche de l'utilisateur dans la base de données
  connection.query(
    "SELECT * FROM paristakecare_user WHERE email = ? AND role > -1",
    [data.email],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la vérification du login",
        });
        return;
      }

      if (results.length > 0) {
        const user = results[0];
        bcrypt.compare(data.password, user.password, (err, bcryptResult) => {
          if (err) {
            console.error(
              "Erreur lors de la comparaison des mots de passe :",
              err
            );
            res.status(500).json({
              message: "Erreur serveur lors de la vérification du mot de passe",
            });
            return;
          }
          if (bcryptResult) {
            const token = generateToken(results, data.interface);

            // Mise à jour du token en base de données
            connection.query(
              "UPDATE paristakecare_user SET token = ? WHERE id = ?",
              [token, user.id],
              (updateError, _updateResults) => {
                if (updateError) {
                  console.error(
                    "Erreur lors de la mise à jour du token en base de données :",
                    updateError
                  );
                  res.status(500).json({
                    message:
                      "Erreur serveur lors de la mise à jour du token en base de données",
                  });
                  return;
                }

                res.json({
                  token,
                  message: `Vous êtes connecté avec l'adresse email ${data.email}`,
                });
              }
            );
          } else {
            res.status(401).json({
              message:
                "Vous n'avez pas les droits nécessaire ou votre adresse email et/ou mot de passe sont incorrect",
            });
          }
        });
      } else {
        res.status(401).json({
          message:
            "Vous n'avez pas les droits nécessaire ou votre adresse email et/ou mot de passe sont incorrect",
        });
      }
    }
  );
});

app.get("/get_tickets", (req, res) => {
  // Vérifier si le token est présent dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Extraire le token des en-têtes de la requête
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérifier la validité du token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userRole = decoded.role;

    if (userRole != -1) {
      // Exécuter la requête SQL pour récupérer les tickets de la catégorie correspondante
      connection.query(
        `SELECT * FROM paristakecare_tickets`,
        (error, results, _fields) => {
          if (error) {
            console.error("Erreur lors de la requête SQL :", error);
            res
              .status(500)
              .json({ message: "Erreur lors de la récupération des tickets" });
            return;
          }
          res.json(results);
        }
      );
    } else {
      res.status(403).json({
        message:
          "Accès refusé : vous n'êtes pas autorisé à accéder à cette ressource",
      });
    }
  });
});

app.post("/add_ticket", (req, res) => {
  const data = req.body;
  const { title, content, email, category } = data;
  connection.query(
    "INSERT INTO paristakecare_tickets (title, content, email, category) VALUES (?, ?, ?, ?)",
    [title, content, email, category],
    (error, _results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de l'ajout du ticket",
        });
        return;
      }
      res.json({ message: "Ticket ajouté avec succès" });
    }
  );
});

//##########################################
//#                 PWD                    #
//##########################################

app.post("/reset_password", (req, res) => {
  const data = req.body;

  // Vérification des champs requis
  if (typeof data.email === "undefined" || data.email === "") {
    //ICI REPONSE EN POST VERS LE FRONT
    res.status(400).json({
      message: "Erreur : le paramètre email est requis",
    });
    return;
  }

  // Vérification de l'email
  if (data.email.indexOf("@") === -1) {
    res.status(400).json({ message: "Adresse email invalide" });
    return;
  }

  // Conversion de l'email en minuscules
  data.email = data.email.toLowerCase();

  // Genération code aléatoire 8 chiffres
  const code = Math.floor(10000000 + Math.random() * 90000000);

  // Envoi du code par email
  const transporter = nodemailer.createTransport({
    host: HOST,
    service: SERVICE,
    auth: {
      user: EMAIL,
      pass: PASSWORD,
    },
  });

  const mailOptions = {
    from: EMAIL,
    to: data.email,
    subject: "Code de réinitialisation de mot de passe",
    text: `Votre code de réinitialisation de mot de passe est : ${code}`,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("Erreur lors de l'envoi du mail :", error);
      res.status(500).json({
        message:
          "Erreur lors de l'envoi du code de réinitialisation de mot de passe",
      });
      return;
    }
    console.log("Email sent: " + info.response);
    res.writeHead(302, {
      Location: `http://localhost/2A3-EJH-PA/passwordCode.php`,
    });
    res.end();
  });

  // Créer un fichier JSON pour stocker le code de réinitialisation
  fs.writeFile("dataCode/dataCode" + code + ".json", JSON.stringify(data), (err) => {
    if (err) {
      console.error("Erreur lors de la création du fichier :", err);
      res.status(500).json({
        message: "Erreur serveur lors de la création du fichier de code",
      });
      return;
    }
    console.log("Fichier créé avec succès");
  });
});

app.post("/change_password", (req, res) => {
  const data = req.body;

  // Vérification des champs requis
  if (
    typeof data.password === "undefined" ||
    typeof data.code === "undefined" ||
    data.password === "" ||
    data.code === ""
  ) {
    res.status(400).json({
      message: "Erreur : les paramètres password et code sont requis",
    });
    return;
  }

  // Vérification de la longueur du mot de passe
  if (data.password.length < 8) {
    res.status(400).json({
      message: "Le mot de passe doit contenir au moins 8 caractères",
    });
    return;
  }

  // Vérification du code de réinitialisation
  fs.readFile("dataCode/dataCode" + data.code + ".json", (err, fileData) => {
    if (err) {
      console.error("Erreur lors de la lecture du fichier :", err);
      res.status(500).json({
        message: "Le code n'existe pas ou a expiré",
      });
      return;
    }
    email = JSON.parse(fileData).email;
  });

  // Suppression du fichier de code
  fs.unlink("dataCode/dataCode" + data.code + ".json", (err) => {
    if (err) {
      console.error("Erreur lors de la suppression du fichier :", err);
      res.status(500).json({
        message: "Erreur serveur lors de la suppression du fichier de code",
      });
      return;
    }
    console.log("Fichier supprimé avec succès");
  });

  // Hashage du mot de passe
  bcrypt.hash(data.password, 10, (err, hash) => {
    if (err) {
      console.error("Erreur lors du hashage du mot de passe :", err);
      res.status(500).json({
        message: "Erreur serveur lors du hashage du mot de passe",
      });
      return;
    }

    // Mise à jour du mot de passe en base de données
    connection.query(
      "UPDATE paristakecare_user SET password = ? WHERE email = ?",
      [hash, email],
      (error, _results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur serveur lors de la mise à jour du mot de passe",
          });
          return;
        }
        res.writeHead(302, {
          Location: `http://localhost/2A3-EJH-PA/login.php`,
        });
        res.end();
      }
    );
  });
});

//##########################################
//#           ROUTES COMMUNNES             #
//##########################################

app.post("/ask_presta", (req, res) => {
  const data = req.body;
  const interface = data.interface;
  const userId = parseInt(data.userId, 10);
  const text = data.asking;

  connection.query(
    "INSERT INTO paristakecare_réserve_presta (id_taker, ask_taker) VALUES (?, ?)",
    [userId, text],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur lors de l'insertion de la demande de prestation",
        });
        return;
      }

      if (interface === "voyageur") {
        res.redirect(
          "http://localhost/2A3-EJH-PA/voyageur/dashboard_voyageur.php"
        );
      } else if (interface === "bailleur") {
        res.redirect(
          "http://localhost/2A3-EJH-PA/bailleur/dashboard_bailleur.php"
        );
      } else {
        res.redirect("/");
      }
    }
  );
});

app.get("/show_all_asks", (req, res) => {
  connection.query(
    "SELECT * FROM paristakecare_réserve_presta",
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des demandes",
        });
        return;
      }
      results.forEach((demande) => {
        // Effectuer une deuxième requête pour récupérer les informations de l'utilisateur correspondant
        connection.query(
          "SELECT * FROM paristakecare_user WHERE id = ?",
          [demande.id_taker],
          (error, userResults, _fields) => {
            if (error) {
              console.error(
                "Erreur lors de la requête SQL pour récupérer l'utilisateur :",
                error
              );
              res.status(500).json({
                message:
                  "Erreur serveur lors de la récupération des informations de l'utilisateur",
              });
              return;
            }

            // Ajouter les informations de l'utilisateur à la demande de prestation
            demande.utilisateur = userResults[0];

            // Si toutes les demandes ont été traitées, renvoyer les résultats
            if (results.indexOf(demande) === results.length - 1) {
              res.json(results);
            }
          }
        );
      });
    }
  );
});

app.get("/recup_token", (req, res) => {
  // Vérifier si le token est présent dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérifier la validité du token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    const userEmail = decoded.email;
    const userInterface = decoded.interface;
    connection.query(
      "SELECT id FROM paristakecare_user WHERE email = ?",
      [userEmail],
      (error, results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message:
              "Erreur lors de la récupération de l'identifiant de l'utilisateur",
          });
          return;
        }
        if (results.length === 0) {
          res.status(404).json({ message: "Utilisateur inexistant" });
          return;
        }

        const userId = results[0].id;

        connection.query(
          "SELECT is_validated FROM paristakecare_prestataire WHERE id = ?",
          [userId],
          (error, prestataireResults, _fields) => {
            if (error) {
              console.error("Erreur lors de la requête SQL :", error);
              res.status(500).json({
                message:
                  "Erreur lors de la récupération du rôle du prestataire",
              });
              return;
            }
            if (prestataireResults.length === 0) {
              res.status(404).json({
                message: "Utilisateur inexistant en tant que prestataire",
              });
              return;
            }

            const is_validated = prestataireResults[0].is_validated;

            // Retourner les informations de l'utilisateur, y compris le token, le rôle et l'état de validation
            const data_return = {
              token: token,
              id: userId,
              email: userEmail,
              interface: userInterface,
              is_validated: is_validated,
            };
            res.json(data_return);
          }
        );
      }
    );
  });
});

app.post("/create-payment-intent-bailleur", async (req, res) => {
  const { items } = req.body;
  console.log(items);
  prix = items[0].price;
  console.log(prix);

  const paymentIntent = await stripe.paymentIntents.create({
    amount: calculateOrderAmount(prix),
    currency: "eur",

    automatic_payment_methods: {
      enabled: true,
    },
  });

  res.send({
    clientSecret: paymentIntent.client_secret,
  });
});

app.get("/recup_token_bailleur", (req, res) => {
  // Vérifier si le token est présent dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérifier la validité du token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    const userEmail = decoded.email;
    const userInterface = decoded.interface;
    connection.query(
      "SELECT id FROM paristakecare_user WHERE email = ?",
      [userEmail],
      (error, results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message:
              "Erreur lors de la récupération de l'identifiant de l'utilisateur",
          });
          return;
        }
        if (results.length === 0) {
          res.status(404).json({ message: "Utilisateur inexistant" });
          return;
        }

        const userId = results[0].id;

        connection.query(
          "SELECT phoneWork FROM paristakecare_bailleur WHERE id = ?",
          [userId],
          (error, prestataireResults, _fields) => {
            if (error) {
              console.error("Erreur lors de la requête SQL :", error);
              res.status(500).json({
                message: "Erreur lors de la récupération du rôle du bailleur",
              });
              return;
            }
            if (prestataireResults.length === 0) {
              res.status(404).json({
                message: "Utilisateur inexistant en tant que bailleur",
              });
              return;
            }

            const phoneWork = prestataireResults[0].phoneWork;

            // Retourner les informations de l'utilisateur, y compris le token, le rôle et l'état de validation
            const data_return = {
              token: token,
              id: userId,
              email: userEmail,
              interface: userInterface,
              phoneWork: phoneWork,
            };
            res.json(data_return);
          }
        );
      }
    );
  });
});

app.post("/update_rating", (req, res) => {
  const data = req.body;
  const id = data.id;
  const rating = data.rating;
  const interface_post = data.interface;

  if (interface_post === "reservation") {
    connection.query(
      "UPDATE paristakecare_reserve SET note = ? WHERE id = ?",
      [rating, id],
      (error, _results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur serveur lors de la mise à jour de la note",
          });
          return;
        }
        res.json({ message: "Note de réservation mise à jour avec succès" });
      }
    );
  } else if (interface_post === "prestation") {
    connection.query(
      "UPDATE paristakecare_prestation SET evaluation = ? WHERE id = ?",
      [rating, id],
      (error, _results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res.status(500).json({
            message: "Erreur serveur lors de la mise à jour de la note",
          });
          return;
        }
        res.json({ message: "Note de prestation mise à jour avec succès" });
      }
    );
  } else {
    res.status(400).json({ message: "Interface non reconnue" });
  }
});

app.get("/get_user", (req, res) => {
  // Vérifier si le token est présent dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Extraire le token des en-têtes de la requête
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérifier la validité du token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userId = decoded.id;
    const userEmail = decoded.email;
    const userInterface = decoded.interface;

    // Exécuter la requête SQL pour récupérer le prénom de l'utilisateur
    connection.query(
      "SELECT firstname FROM paristakecare_user WHERE id = ?",
      [userId],
      (error, results, _fields) => {
        if (error) {
          console.error("Erreur lors de la requête SQL :", error);
          res
            .status(500)
            .json({ message: "Erreur lors de la récupération du prénom" });
          return;
        }
        if (results.length === 0) {
          res.status(404).json({ message: "Utilisateur inexistant" });
          return;
        }

        // Récupérer le prénom de l'utilisateur à partir des résultats de la requête SQL
        const userFirstname = results[0].firstname;

        // Retourner les informations de l'utilisateur, y compris le prénom
        const data_return = {
          id: userId,
          email: userEmail,
          firstname: userFirstname,
          interface: userInterface,
        };
        res.json(data_return);
      }
    );
  });
});

app.get("/is_admin", (req, res) => {
  const data = req.body;

  if (typeof data.id === "undefined" || data.id === "") {
    res.status(400).json({ message: "Erreur : le paramètre id est requis" });
    return;
  }

  connection.query(
    "SELECT role FROM paristakecare_prestataire WHERE id = ?",
    [data.id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res
          .status(500)
          .json({ message: "Erreur lors de la récupération du rôle" });
        return;
      }

      if (results.length === 0) {
        res.status(404).json({ message: "Utilisateur inexistant" });
        return;
      }

      res.json({ role: results[0].role });
    }
  );
});

app.post("/is_admin_cookie_administration", (req, res) => {
  // Vérifier si le token est présent dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Extraire le token des en-têtes de la requête
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérifier la validité du token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userRole = decoded.role;

    if (userRole != -1) {
      res.json({ isAdmin: true });
    } else {
      res.writeHead(302, {
        Location: `http://localhost/2A3-EJH-PA/login.php?message=Vous n'êtes pas autorisé à accéder à cette ressource`,
      });
      res.end();
    }
  });
});

app.post("/redirect_dashboard", (req, res) => {
  // Vérifier si le token est présent dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Extraire le token des en-têtes de la requête
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérifier la validité du token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userInterface = decoded.interface;

    console.log(decoded);

    switch (userInterface) {
      case "bailleur":
        res.writeHead(302, {
          Location: `http://localhost/2A3-EJH-PA/dashboard_bailleur.php`,
        });
        res.end();
        break;
      case "prestataire":
        res.writeHead(302, {
          Location: `http://localhost/2A3-EJH-PA/dashboard_prestataire.php`,
        });
        res.end();
        break;
      case "voyageur":
        res.writeHead(302, {
          Location: `http://localhost/2A3-EJH-PA/dashboard_voyageur.php`,
        });
        res.end();
        break;
      default:
        res.status(400).json({ message: "Interface non reconnue" });
    }
  });
});

app.post("/is_admin_cookie_navbar", (req, res) => {
  // Vérifier si le token est présent dans les en-têtes de la requête
  if (typeof req.headers.authorization === "undefined") {
    res.status(401).json({ message: "Erreur : le token est manquant" });
    return;
  }

  // Extraire le token des en-têtes de la requête
  const tokenGrab = req.headers.authorization;
  const token = tokenGrab.substring(7);

  // Vérifier si le token existe
  if (!token) {
    res.status(401).json({ message: "Token manquant" });
    return;
  }

  // Vérifier la validité du token
  jwt.verify(token, config.secretKey, (err, decoded) => {
    if (err) {
      console.error("Erreur lors de la vérification du token :", err);
      res.status(401).json({ message: "Token invalide" });
      return;
    }

    // Le token est valide, vous pouvez accéder aux informations contenues dans le token
    const userRole = decoded.role;

    if (userRole == 1) {
      res.json({ isAdmin: true, isPcs: true });
    } else if (userRole == 0) {
      res.json({ isAdmin: false, isPcs: true });
    } else {
      res.json({ isAdmin: false });
    }
  });
});

app.get("/show_all_presta_type", (req, res) => {
  connection.query(
    "SELECT * FROM paristakecare_type_presta",
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la récupération des prestations",
        });
        return;
      }
      res.json(results);
    }
  );
});

const calculateOrderAmount = (prix) => {
  return prix * 100;
};

app.post("/create-payment-intent", async (req, res) => {
  const { items } = req.body;

  prix = items[0].prix;

  const paymentIntent = await stripe.paymentIntents.create({
    amount: calculateOrderAmount(prix),
    currency: "eur",

    automatic_payment_methods: {
      enabled: true,
    },
  });

  res.send({
    clientSecret: paymentIntent.client_secret,
  });
});

app.post("/create-payment-intent-abo", async (req, res) => {
  const { items } = req.body;

  prix = items[0].prix;

  const paymentIntent = await stripe.paymentIntents.create({
    amount: calculateOrderAmount(prix),
    currency: "eur",

    automatic_payment_methods: {
      enabled: true,
    },
  });

  res.send({
    clientSecret: paymentIntent.client_secret,
  });
});

app.post("/checkout_abonnement", async (req, res) => {
  const data = req.body;

  const id = parseInt(data.id, 10);
  const subscription = data.subscription;
  let is_vip;
  let date = new Date();

  if (subscription === "basicAbonnement") {
    is_vip = 1;
  } else if (subscription === 'vip') {
    is_vip = 2;
  } else {
    res.status(400).json({ message: "Type d'abonnement invalide" });
    return;
  }

  connection.query(
    "UPDATE paristakecare_voyageur SET is_vip = ?, is_vip_date = ? WHERE id = ?",
    [is_vip, date, id],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.status(500).json({
          message: "Erreur serveur lors de la mise à jour de l'abonnement",
        });
        return;
      }

      res.status(200).json({ message: "Abonnement mis à jour avec succès" });
    }
  );
});



app.post("/add_user", async (req, res) => {
  const data = req.body;

  if (
    typeof data.interface === "undefined" ||
    typeof data.lastname === "undefined" ||
    typeof data.firstname === "undefined" ||
    typeof data.address === "undefined" ||
    typeof data.phone === "undefined" ||
    (data.interface === "bailleur" &&
      (typeof data.phoneWork === "undefined" || data.phoneWork === "")) ||
    (data.interface === "prestataire" &&
      (typeof data.type_presta === "undefined" || data.type_presta === "")) ||
    typeof data.email === "undefined" ||
    typeof data.password === "undefined" ||
    typeof data.passwordVerify === "undefined" ||
    data.interface === "" ||
    data.lastname === "" ||
    data.firstname === "" ||
    data.address === "" ||
    data.phone === "" ||
    data.email === "" ||
    data.password === "" ||
    data.passwordVerify === ""
  ) {
    return res.status(400).json({
      message:
        "Erreur : les paramètres lastname, firstname, address, phone, email, password sont requis",
    });
  }

  if (data.password !== data.passwordVerify) {
    return res.status(400).json({
      message: "Les mots de passe ne correspondent pas",
    });
  }

  const hashedPassword = await bcrypt.hash(data.password, saltRounds);

  connection.query(
    "SELECT * FROM paristakecare_user WHERE email = ?",
    [data.email],
    async (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        return res.status(500).json({
          message: "Erreur serveur lors de la vérification de l'utilisateur",
        });
      }

      if (results.length > 0) {
        const userId = results[0].id;
        if (data.interface === "prestataire") {
          connection.query(
            `SELECT * FROM paristakecare_prestataire WHERE id = ?`,
            [userId],
            (error, interfaceResults, _fields) => {
              if (error) {
                console.error(
                  "Erreur lors de la vérification de l'interface de l'utilisateur :",
                  error
                );
                return res.status(500).json({
                  message:
                    "Erreur serveur lors de la vérification de l'interface de l'utilisateur",
                });
              }
              if (interfaceResults.length > 0) {
                return res.status(400).json({
                  message: "Erreur : l'utilisateur est déjà un prestataire",
                });
              } else {
                connection.query(
                  "INSERT INTO paristakecare_prestataire (id, type_prestation) VALUES (?, ?)",
                  [userId, data.type_presta],
                  (error, _results, _fields) => {
                    if (error) {
                      console.error(
                        "Erreur lors de l'insertion du prestataire :",
                        error
                      );
                      return res.status(500).json({
                        message:
                          "Erreur serveur lors de l'insertion du prestataire",
                      });
                    }
                    res.status(200).json({
                      message: "Utilisateur prestataire ajouté avec succès",
                    });
                  }
                );
              }
            }
          );
        } else if (data.interface === "bailleur") {
          connection.query(
            `SELECT * FROM paristakecare_bailleur WHERE id = ?`,
            [userId],
            (error, interfaceResults, _fields) => {
              if (error) {
                console.error(
                  "Erreur lors de la vérification de l'interface de l'utilisateur :",
                  error
                );
                return res.status(500).json({
                  message:
                    "Erreur serveur lors de la vérification de l'interface de l'utilisateur",
                });
              }
              if (interfaceResults.length > 0) {
                return res.status(400).json({
                  message: "Erreur : l'utilisateur est déjà un bailleur",
                });
              } else {
                const isEnterprise = data.entreprise === "2" ? 1 : 0;
                connection.query(
                  "INSERT INTO paristakecare_bailleur (id, personnal, entreprise, phoneWork) VALUES (?, ?, ?, ?)",
                  [userId, 1 - isEnterprise, isEnterprise, data.phoneWork],
                  (error, _results, _fields) => {
                    if (error) {
                      console.error(
                        "Erreur lors de l'insertion du bailleur :",
                        error
                      );
                      return res.status(500).json({
                        message:
                          "Erreur serveur lors de l'insertion du bailleur",
                      });
                    }
                    res.status(200).json({
                      message: "Utilisateur bailleur ajouté avec succès",
                    });
                  }
                );
              }
            }
          );
        } else if (data.interface === "voyageur") {
          connection.query(
            `SELECT * FROM paristakecare_voyageur WHERE id = ?`,
            [userId],
            (error, interfaceResults, _fields) => {
              if (error) {
                console.error(
                  "Erreur lors de la vérification de l'interface de l'utilisateur :",
                  error
                );
                return res.status(500).json({
                  message:
                    "Erreur serveur lors de la vérification de l'interface de l'utilisateur",
                });
              }
              if (interfaceResults.length > 0) {
                return res.status(400).json({
                  message: "Erreur : l'utilisateur est déjà un voyageur",
                });
              } else {
                connection.query(
                  "INSERT INTO paristakecare_voyageur (id, is_vip) VALUES (?, ?)",
                  [userId, 0],
                  (error, _results, _fields) => {
                    if (error) {
                      console.error(
                        "Erreur lors de l'insertion du voyageur :",
                        error
                      );
                      return res.status(500).json({
                        message:
                          "Erreur serveur lors de l'insertion du voyageur",
                      });
                    }
                    res.status(200).json({
                      message: "Utilisateur voyageur ajouté avec succès",
                    });
                  }
                );
              }
            }
          );
        } else {
          // Si l'interface est inconnue, retourner une erreur
          return res.status(400).json({
            message: "Erreur : interface utilisateur non reconnue",
          });
        }
      } else {
        // L'utilisateur n'existe pas, nous pouvons l'ajouter directement
        connection.query(
          "INSERT INTO paristakecare_user (lastname, firstname, address, phone, email, password) VALUES (?, ?, ?, ?, ?, ?)",
          [
            data.lastname,
            data.firstname,
            data.address,
            data.phone,
            data.email,
            hashedPassword,
          ],
          async (error, results, _fields) => {
            if (error) {
              console.error("Erreur lors de la requête SQL :", error);
              return res.status(500).json({
                message: "Erreur serveur lors de l'ajout de l'utilisateur",
              });
            }

            const userId = results.insertId;

            if (data.interface === "prestataire") {
              connection.query(
                "INSERT INTO paristakecare_prestataire (id, type_prestation, price, duration) VALUES (?, ?, ?, ?)",
                [userId, data.type_presta, parseInt(data.price,10), parseInt(data.duration,10)],
                (error, _results, _fields) => {
                  if (error) {
                    console.error(
                      "Erreur lors de l'insertion du prestataire :",
                      error
                    );
                    return res.status(500).json({
                      message:
                        "Erreur serveur lors de l'insertion du prestataire",
                    });
                  }
                  res.status(200).json({
                    message: "Utilisateur prestataire ajouté avec succès",
                  });
                }
              );
            } else if (data.interface === "bailleur") {
              const isEnterprise = data.entreprise === "2" ? 1 : 0;
              connection.query(
                "INSERT INTO paristakecare_bailleur (id, personnal, entreprise, phoneWork) VALUES (?, ?, ?, ?)",
                [userId, 1 - isEnterprise, isEnterprise, data.phoneWork],
                (error, _results, _fields) => {
                  if (error) {
                    console.error(
                      "Erreur lors de l'insertion du bailleur :",
                      error
                    );
                    return res.status(500).json({
                      message: "Erreur serveur lors de l'insertion du bailleur",
                    });
                  }
                  res.status(200).json({
                    message: "Utilisateur bailleur ajouté avec succès",
                  });
                }
              );
            } else if (data.interface === "voyageur") {
              connection.query(
                "INSERT INTO paristakecare_voyageur (id, is_vip) VALUES (?, ?)",
                [userId, 0],
                (error, _results, _fields) => {
                  if (error) {
                    console.error(
                      "Erreur lors de l'insertion du voyageur :",
                      error
                    );
                    return res.status(500).json({
                      message: "Erreur serveur lors de l'insertion du voyageur",
                    });
                  }
                  res.status(200).json({
                    message: "Utilisateur voyageur ajouté avec succès",
                  });
                }
              );
            } else {
              return res.status(400).json({
                message: "Erreur : interface utilisateur non reconnue",
              });
            }
          }
        );
      }
    }
  );
});

app.post("/login_voyageur_android", (req, res) => {
  const data = req.body;
  const login = data.login;
  const password = data.password;

  connection.query(
    "SELECT * FROM paristakecare_user WHERE email = ?",
    [login],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.writeHead(302, {
          Location: "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
        });
        res.end();
        return;
      }
      console.log(results);
      const user = results[0];

      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          console.error("Erreur lors de la comparaison des mots de passe :", err);
          res.writeHead(302, {
            Location: "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
          });
          res.end();
          return;
        }

        if (!isMatch) {
          return 0; 
        }
        res.json({ id: user.id });
      });
    }
  );
});


app.post("/login", (req, res) => {
  const data = req.body;
  let dashboardURL = "";
  if (
    typeof data.email === "undefined" ||
    typeof data.password === "undefined" ||
    typeof data.interface === "undefined" ||
    data.email === "" ||
    data.password === "" ||
    data.interface === ""
  ) {
    res.writeHead(302, {
      Location:
        "http://localhost/2A3-EJH-PA/login.php?error=donnees_manquantes",
    });
    res.end();
    return;
  }

  if (data.email.indexOf("@") === -1) {
    res.writeHead(302, {
      Location: "http://localhost/2A3-EJH-PA/login.php?error=email_invalide",
    });
    res.end();
    return;
  }

  if (data.password.length < 8) {
    res.writeHead(302, {
      Location:
        "http://localhost/2A3-EJH-PA/login.php?error=mot_de_passe_trop_court",
    });
    res.end();
    return;
  }

  data.email = data.email.toLowerCase();

  connection.query(
    "SELECT * FROM paristakecare_user WHERE email = ?",
    [data.email],
    (error, results, _fields) => {
      if (error) {
        console.error("Erreur lors de la requête SQL :", error);
        res.writeHead(302, {
          Location:
            "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
        });
        res.end();
        return;
      }

      if (results.length > 0) {
        const user = results[0];
        bcrypt.compare(data.password, user.password, (err, bcryptResult) => {
          if (err) {
            console.error(
              "Erreur lors de la comparaison des mots de passe :",
              err
            );
            res.writeHead(302, {
              Location:
                "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
            });
            res.end();
            return;
          }
          if (bcryptResult) {
            if (data.interface === "bailleur") {
              connection.query(
                "SELECT * FROM paristakecare_bailleur WHERE id = ?",
                [user.id],
                (error, bailleurResults, _fields) => {
                  if (error) {
                    console.error(
                      "Erreur lors de la vérification de l'utilisateur bailleur :",
                      error
                    );
                    res.writeHead(302, {
                      Location:
                        "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
                    });
                    res.end();
                    return;
                  }

                  if (bailleurResults.length === 0) {
                    res.writeHead(302, {
                      Location:
                        "http://localhost/2A3-EJH-PA/login.php?error=pas_de_compte_sur_cet_interface",
                    });
                    res.end();
                    return;
                  } else {
                    // Génération du token
                    const token = generateToken(results, "bailleur");

                    // Mise à jour du token en base de données
                    connection.query(
                      "UPDATE paristakecare_user SET token = ? WHERE id = ?",
                      [token, user.id],
                      (updateError, _updateResults) => {
                        if (updateError) {
                          console.error(
                            "Erreur lors de la mise à jour du token en base de données :",
                            updateError
                          );
                          res.writeHead(302, {
                            Location:
                              "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
                          });
                          res.end();
                          return;
                        }

                        // Définition de l'URL du tableau de bord
                        dashboardURL = `http://localhost/2A3-EJH-PA/bailleur/dashboard_bailleur.php?token=${token}`;

                        // Redirection vers le tableau de bord
                        res.writeHead(302, { Location: dashboardURL });
                        res.end();
                      }
                    );
                  }
                }
              );
            } else if (data.interface === "voyageur") {
              connection.query(
                "SELECT * FROM paristakecare_voyageur WHERE id = ?",
                [user.id],
                (error, voyageurResults, _fields) => {
                  if (error) {
                    console.error(
                      "Erreur lors de la vérification de l'utilisateur voyageur :",
                      error
                    );
                    res.writeHead(302, {
                      Location:
                        "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
                    });
                    res.end();
                    return;
                  }

                  if (voyageurResults.length === 0) {
                    res.writeHead(302, {
                      Location:
                        "http://localhost/2A3-EJH-PA/login.php?error=pas_de_compte_sur_cet_interface",
                    });
                    res.end();
                    return;
                  } else {
                    // Génération du token
                    const token = generateToken(results, "voyageur");

                    // Mise à jour du token en base de données
                    connection.query(
                      "UPDATE paristakecare_user SET token = ? WHERE id = ?",
                      [token, user.id],
                      (updateError, _updateResults) => {
                        if (updateError) {
                          console.error(
                            "Erreur lors de la mise à jour du token en base de données :",
                            updateError
                          );
                          res.writeHead(302, {
                            Location:
                              "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
                          });
                          res.end();
                          return;
                        }

                        // Définition de l'URL du tableau de bord
                        dashboardURL = `http://localhost/2A3-EJH-PA/voyageur/dashboard_voyageur.php?token=${token}`;

                        // Redirection vers le tableau de bord
                        res.writeHead(302, { Location: dashboardURL });
                        res.end();
                      }
                    );
                  }
                }
              );
            } else if (data.interface === "prestataire") {
              console.log("presta");
              connection.query(
                "SELECT * FROM paristakecare_prestataire WHERE id = ?",
                [user.id],
                (error, prestataireResults, _fields) => {
                  if (error) {
                    console.error(
                      "Erreur lors de la vérification de l'utilisateur prestataire :",
                      error
                    );
                    res.writeHead(302, {
                      Location:
                        "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
                    });
                    res.end();
                    return;
                  }

                  if (prestataireResults.length === 0) {
                    res.writeHead(302, {
                      Location:
                        "http://localhost/2A3-EJH-PA/login.php?error=pas_de_compte_sur_cet_interface",
                    });
                    res.end();
                    return;
                  } else {
                    // Génération du token
                    const token = generateToken(results, "prestataire");

                    // Mise à jour du token en base de données
                    connection.query(
                      "UPDATE paristakecare_user SET token = ? WHERE id = ?",
                      [token, user.id],
                      (updateError, _updateResults) => {
                        if (updateError) {
                          console.error(
                            "Erreur lors de la mise à jour du token en base de données :",
                            updateError
                          );
                          res.writeHead(302, {
                            Location:
                              "http://localhost/2A3-EJH-PA/login.php?error=erreur_serveur",
                          });
                          res.end();
                          return;
                        }

                        // Définition de l'URL du tableau de bord
                        dashboardURL = `http://localhost/2A3-EJH-PA/dashboard_prestataire.php?token=${token}`;

                        // Redirection vers le tableau de bord
                        res.writeHead(302, { Location: dashboardURL });
                        res.end();
                      }
                    );
                  }
                }
              );
            }
          } else {
            res.writeHead(302, {
              Location:
                "http://localhost/2A3-EJH-PA/login.php?error=identifiants_incorrects",
            });
            res.end();
          }
        });
      } else {
        res.writeHead(302, {
          Location:
            "http://localhost/2A3-EJH-PA/login.php?error=identifiants_incorrects",
        });
        res.end();
      }
    }
  );
});




// Port sur lequel le serveur écoutera
const port = 3000;

// Démarrer le serveur
app.listen(port, () => {
  console.log(`Serveur démarré sur le port ${port}`);
});
